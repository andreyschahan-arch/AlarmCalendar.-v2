package com.aicalendar.v2;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MonthPagerAdapter extends RecyclerView.Adapter<MonthPagerAdapter.MonthViewHolder> {

    public static final int START_POSITION = 1000;
    private List<ProfileModel> profileList;

    // Один SimpleDateFormat на весь адаптер — не создаём его в цикле на каждую ячейку
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    // Цвета календаря
    private static final int COLOR_TODAY_RING = 0xFFFF3B6B; // розово-красный, тонкое кольцо
    private static final int COLOR_REMINDER_MARKER = 0xFF00E676; // зелёный маркер

    public MonthPagerAdapter(List<ProfileModel> profileList) {
        this.profileList = profileList;
    }

    public void updateProfiles(List<ProfileModel> profileList) {
        this.profileList = profileList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MonthViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.page_month, parent, false);
        return new MonthViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MonthViewHolder holder, int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - START_POSITION);

        List<DayModel> days = generateDaysForMonth(cal);
        fillGrid(holder, days);
    }

    @Override
    public void onBindViewHolder(@NonNull MonthViewHolder holder, int position, @NonNull List<Object> payloads) {
        if (!payloads.isEmpty()) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, position - START_POSITION);
            List<DayModel> days = generateDaysForMonth(cal);
            fillGrid(holder, days);
        } else {
            super.onBindViewHolder(holder, position, payloads);
        }
    }

    // Заполняем 6 строк по 7 ячеек
    private void fillGrid(MonthViewHolder holder, List<DayModel> days) {
        LinearLayout[] rows = holder.rows;
        Context context = holder.itemView.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        for (int r = 0; r < 6; r++) {
            LinearLayout row = rows[r];
            row.removeAllViews();

            for (int c = 0; c < 7; c++) {
                int index = r * 7 + c;
                if (index >= days.size()) {
                    View empty = new View(context);
                    LinearLayout.LayoutParams emptyParams = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
                    empty.setLayoutParams(emptyParams);
                    row.addView(empty);
                    continue;
                }

                DayModel day = days.get(index);
                View cell = inflater.inflate(R.layout.item_day, row, false);
                bindDayCell(cell, day);
                row.addView(cell);
            }
        }
    }

    private void bindDayCell(View cell, DayModel day) {
        TextView tvDayNumber = cell.findViewById(R.id.tvDayNumber);
        View reminderMarker = cell.findViewById(R.id.dayReminderMarker);

        tvDayNumber.setText(day.getDayNumber());

        float density = cell.getContext().getResources().getDisplayMetrics().density;

        // Цвет цифры для дней вне текущего месяца — серый
        if (!day.isCurrentMonth()) {
            tvDayNumber.setTextColor(Color.parseColor("#444444"));
        } else {
            tvDayNumber.setTextColor(Color.WHITE);
        }

        // ===== Кольцо вокруг сегодняшней даты =====
        boolean isToday = isToday(day.getDate());
        if (isToday) {
            GradientDrawable ring = new GradientDrawable();
            ring.setShape(GradientDrawable.OVAL);
            ring.setColor(Color.TRANSPARENT);
            ring.setStroke((int) (1.2f * density), COLOR_TODAY_RING);
            tvDayNumber.setBackground(ring);
            tvDayNumber.setTextColor(COLOR_TODAY_RING);
        } else {
            tvDayNumber.setBackground(null);
        }

        // ===== Рамка профиля =====
        int borderColor = Color.TRANSPARENT;
        if (day.isCurrentMonth() && day.getDate() != null
			&& profileList != null && !profileList.isEmpty()) {
            borderColor = findBorderColorForDate(day.getDate());
        }

        GradientDrawable cellBg = new GradientDrawable();
        cellBg.setShape(GradientDrawable.RECTANGLE);
        cellBg.setCornerRadius(10f * density);
        cellBg.setColor(Color.parseColor("#121212"));

        if (borderColor != Color.TRANSPARENT) {
			cellBg.setStroke((int) (1.2f * density), borderColor);
		}

        cell.setBackground(cellBg);

        // ===== Зелёная полоска — если на этот день активен профиль С напоминаниями =====
        boolean hasReminders = hasActiveRemindersForDate(day.getDate());
        if (hasReminders && day.isCurrentMonth()) {
            reminderMarker.setVisibility(View.VISIBLE);
        } else {
            reminderMarker.setVisibility(View.INVISIBLE);
        }

        // ===== Клик =====
        cell.setOnClickListener(v -> {
            Context context = v.getContext();
            if (day.getDate() != null && context instanceof MainActivity) {
                ((MainActivity) context).openDayDetails(day.getDate());
            }
        });
    }

    private boolean isToday(java.util.Date date) {
        if (date == null) return false;
        Calendar today = Calendar.getInstance();
        Calendar check = Calendar.getInstance();
        check.setTime(date);
        return today.get(Calendar.YEAR) == check.get(Calendar.YEAR)
            && today.get(Calendar.DAY_OF_YEAR) == check.get(Calendar.DAY_OF_YEAR);
    }

    private boolean hasActiveRemindersForDate(java.util.Date date) {
        if (date == null || profileList == null || profileList.isEmpty()) return false;

        Calendar dayCal = Calendar.getInstance();
        dayCal.setTime(date);
        dayCal.set(Calendar.HOUR_OF_DAY, 0);
        dayCal.set(Calendar.MINUTE, 0);
        dayCal.set(Calendar.SECOND, 0);
        dayCal.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profileList) {
            if (profile == null) continue;
            String startDateStr = profile.getStartDate();
            if (startDateStr == null || startDateStr.trim().isEmpty()) continue;

            List<ReminderModel> reminders = profile.getReminders();
            if (reminders == null || reminders.isEmpty()) continue;

            try {
                java.util.Date startDate = dateFormat.parse(startDateStr);
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffInMillis = dayCal.getTimeInMillis() - startCal.getTimeInMillis();
                long diffInDays = diffInMillis / (24 * 60 * 60 * 1000);

                int repeat = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffInDays >= 0 && (diffInDays % repeat == 0)) {
                    return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    private int findBorderColorForDate(java.util.Date date) {
        if (profileList == null) return Color.TRANSPARENT;

        Calendar dayCal = Calendar.getInstance();
        dayCal.setTime(date);
        dayCal.set(Calendar.HOUR_OF_DAY, 0);
        dayCal.set(Calendar.MINUTE, 0);
        dayCal.set(Calendar.SECOND, 0);
        dayCal.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profileList) {
            if (profile == null) continue;
            String startDateStr = profile.getStartDate();
            if (startDateStr == null || startDateStr.trim().isEmpty()) continue;

            try {
                java.util.Date startDate = dateFormat.parse(startDateStr);
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffInMillis = dayCal.getTimeInMillis() - startCal.getTimeInMillis();
                long diffInDays = diffInMillis / (24 * 60 * 60 * 1000);

                int repeat = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffInDays >= 0 && (diffInDays % repeat == 0)) {
                    String color = profile.getColor();
                    if (color != null && !color.isEmpty()) {
                        return Color.parseColor(color);
                    }
                }
            } catch (Exception ignored) {}
        }

        return Color.TRANSPARENT;
    }

    @Override
    public int getItemCount() {
        return START_POSITION * 2;
    }

    private List<DayModel> generateDaysForMonth(Calendar targetCal) {
        List<DayModel> daysList = new ArrayList<>();
        Calendar cal = (Calendar) targetCal.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
        if (firstDayOfWeek < 0) firstDayOfWeek += 7;

        Calendar prevCal = (Calendar) cal.clone();
        prevCal.add(Calendar.MONTH, -1);
        int maxDaysInPrevMonth = prevCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = firstDayOfWeek - 1; i >= 0; i--) {
            Calendar dayCal = (Calendar) prevCal.clone();
            int dayNum = maxDaysInPrevMonth - i;
            dayCal.set(Calendar.DAY_OF_MONTH, dayNum);
            daysList.add(new DayModel(String.valueOf(dayNum), false, dayCal.getTime()));
        }

        int maxDayInCurrent = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDayInCurrent; i++) {
            Calendar dayCal = (Calendar) cal.clone();
            dayCal.set(Calendar.DAY_OF_MONTH, i);
            daysList.add(new DayModel(String.valueOf(i), true, dayCal.getTime()));
        }

        Calendar nextCal = (Calendar) cal.clone();
        nextCal.add(Calendar.MONTH, 1);
        int nextDaysNeed = 42 - daysList.size();
        for (int i = 1; i <= nextDaysNeed; i++) {
            Calendar dayCal = (Calendar) nextCal.clone();
            dayCal.set(Calendar.DAY_OF_MONTH, i);
            daysList.add(new DayModel(String.valueOf(i), false, dayCal.getTime()));
        }

        return daysList;
    }

    static class MonthViewHolder extends RecyclerView.ViewHolder {
        final LinearLayout[] rows = new LinearLayout[6];

        public MonthViewHolder(@NonNull View itemView) {
            super(itemView);
            rows[0] = itemView.findViewById(R.id.monthRow1);
            rows[1] = itemView.findViewById(R.id.monthRow2);
            rows[2] = itemView.findViewById(R.id.monthRow3);
            rows[3] = itemView.findViewById(R.id.monthRow4);
            rows[4] = itemView.findViewById(R.id.monthRow5);
            rows[5] = itemView.findViewById(R.id.monthRow6);
        }
    }
}
