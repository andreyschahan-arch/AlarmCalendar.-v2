package com.aicalendar.v2;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Единая точка планирования будильников.
 *
 * Логика: у каждого профиля есть startDate и repeatDays. Профиль активен на день D,
 * если D >= startDate и (D - startDate) % repeatDays == 0. Для каждого активного
 * дня в окне [сегодня, сегодня+2] ставим все напоминания профиля (main и pre).
 *
 * Планировщик не хранит состояние — при каждом вызове пересчитывает всё с нуля:
 * сначала отменяет все существующие будильники профиля (или всех профилей),
 * потом ставит заново. Это надёжнее, чем инкрементальные правки.
 */
public class AlarmPlanner {

    // Сколько календарных дней вперёд планируем (сегодня + N-1 следующих)
    private static final int DAYS_AHEAD = 3;

    /**
     * Пересчитать все профили.
     * Используется при: полночи, перезагрузке, смене глобальных настроек,
     * окончании цепочки будильника.
     */
    public static void replanAll(Context context) {
        if (context == null) return;

        AlarmSettings settings = AlarmSettings.load(context);
        if (settings.isVacationNow()) {
            // Во время отпуска все будильники должны быть сняты —
            // значит отменяем всё и ничего не ставим.
            List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
            if (profiles != null) {
                for (ProfileModel p : profiles) {
                    cancelProfile(context, p);
                }
            }
            return;
        }

        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
        if (profiles == null || profiles.isEmpty()) return;

        for (ProfileModel p : profiles) {
            cancelProfile(context, p);
        }
        for (ProfileModel p : profiles) {
            scheduleProfile(context, p, settings);
        }
    }

    /**
     * Пересчитать один профиль.
     * Используется при: сохранении, удалении, клонировании, смене старта.
     */
    public static void replanProfile(Context context, ProfileModel profile) {
        if (context == null || profile == null) return;

        cancelProfile(context, profile);

        AlarmSettings settings = AlarmSettings.load(context);
        if (settings.isVacationNow()) return;

        scheduleProfile(context, profile, settings);
    }

    // ==================== ВНУТРЕННЕЕ ====================

    /**
     * Снимает все будильники (main и pre) всех напоминаний данного профиля
     * в окне планирования. Отменяет все циклы — на случай, если от прошлой
     * версии что-то висело.
     */
    private static void cancelProfile(Context context, ProfileModel profile) {
        if (profile == null || profile.getReminders() == null) return;

        for (ReminderModel reminder : profile.getReminders()) {
            if (reminder == null || reminder.getTime() == null) continue;

            int mainId = (profile.getId() + reminder.getTime() + "_main").hashCode();
            int preId = (profile.getId() + reminder.getTime() + "_pre").hashCode();

            AlarmScheduler.cancelAllCycles(context, mainId);
            AlarmScheduler.cancelAllCycles(context, preId);
        }
    }

    /**
     * Ставит будильники профиля на окно [сегодня, сегодня+2].
     */
    private static void scheduleProfile(Context context, ProfileModel profile, AlarmSettings settings) {
        if (profile == null || profile.getReminders() == null || profile.getReminders().isEmpty()) return;
        if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) return;

        Date startDate = parseDate(profile.getStartDate());
        if (startDate == null) return;

        Calendar startCal = atMidnight(startDate);
        int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

        Calendar now = Calendar.getInstance();

        // Проходим окно из DAYS_AHEAD календарных дней, начиная с сегодня
        for (int offset = 0; offset < DAYS_AHEAD; offset++) {
            Calendar dayCal = (Calendar) now.clone();
            dayCal.add(Calendar.DAY_OF_YEAR, offset);
            dayCal.set(Calendar.HOUR_OF_DAY, 0);
            dayCal.set(Calendar.MINUTE, 0);
            dayCal.set(Calendar.SECOND, 0);
            dayCal.set(Calendar.MILLISECOND, 0);

            long diffDays = (dayCal.getTimeInMillis() - startCal.getTimeInMillis())
                / (24 * 60 * 60 * 1000);

            if (diffDays < 0) continue;
            if (diffDays % repeatDays != 0) continue;

            scheduleProfileForDay(context, profile, dayCal, now, settings);
        }
    }

    /**
     * Для конкретного дня ставит все напоминания профиля.
     */
    private static void scheduleProfileForDay(Context context, ProfileModel profile,
                                              Calendar dayCal, Calendar now, AlarmSettings settings) {
        int preAlarmMinutes = settings.getPreAlarmMinutesBefore();

        for (ReminderModel reminder : profile.getReminders()) {
            if (reminder == null || reminder.getTime() == null) continue;

            String[] parts = reminder.getTime().split(":");
            if (parts.length < 2) continue;

            int hour, minute;
            try {
                hour = Integer.parseInt(parts[0]);
                minute = Integer.parseInt(parts[1]);
            } catch (Exception e) {
                continue;
            }

            // Main
            Calendar mainCal = (Calendar) dayCal.clone();
            mainCal.set(Calendar.HOUR_OF_DAY, hour);
            mainCal.set(Calendar.MINUTE, minute);
            mainCal.set(Calendar.SECOND, 0);
            mainCal.set(Calendar.MILLISECOND, 0);

            int mainAlarmId = (profile.getId() + reminder.getTime() + "_main").hashCode();

            // Main ставим, если его время ещё в будущем
            if (mainCal.getTimeInMillis() > now.getTimeInMillis() + 1_000L) {
                AlarmScheduler.scheduleAlarm(
                    context,
                    mainCal.getTimeInMillis(),
                    mainAlarmId,
                    profile.getName(),
                    reminder.getText(),
                    false,
                    settings.getMainRingtoneUri(),
                    0
                );
            }

            // Pre
            if (preAlarmMinutes > 0) {
                Calendar preCal = (Calendar) mainCal.clone();
                preCal.add(Calendar.MINUTE, -preAlarmMinutes);

                int preAlarmId = (profile.getId() + reminder.getTime() + "_pre").hashCode();

                if (preCal.getTimeInMillis() > now.getTimeInMillis() + 1_000L) {
                    String preTitle = "До " + profile.getName() + " осталось " + preAlarmMinutes + " мин";

                    AlarmScheduler.scheduleAlarm(
                        context,
                        preCal.getTimeInMillis(),
                        preAlarmId,
                        preTitle,
                        reminder.getText(),
                        true,
                        settings.getPreRingtoneUri(),
                        0
                    );
                }
            }
        }
    }

    private static Date parseDate(String s) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            sdf.setLenient(false);
            return sdf.parse(s);
        } catch (Exception e) {
            return null;
        }
    }

    private static Calendar atMidnight(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal;
    }
}
