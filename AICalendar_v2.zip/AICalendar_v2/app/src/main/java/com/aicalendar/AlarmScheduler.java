package com.aicalendar.v2;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmScheduler {

    // Соль в requestCode. Меняй при изменении схемы планирования —
    // это гарантирует, что старые PendingIntent'ы от предыдущих версий
    // не пересекутся с новыми.
    private static final int REQUEST_CODE_SALT = 700_000_000;

    // Сколько циклов максимум может быть у одного будильника.
    // Должно быть не меньше лимита repeatCount (20). Берём с запасом.
    private static final int MAX_CYCLES = 100;

    public static void scheduleAlarm(Context context, long triggerAtMillis, int alarmId,
                                     String title, String message, boolean isPreAlarm,
                                     String ringtoneUri, int cycleIndex) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("ALARM_ID", alarmId);
        intent.putExtra("TITLE", title);
        intent.putExtra("MESSAGE", message);
        intent.putExtra("IS_PRE_ALARM", isPreAlarm);
        intent.putExtra("RINGTONE_URI", ringtoneUri);
        intent.putExtra("CYCLE_INDEX", cycleIndex);

        int requestCode = makeRequestCode(alarmId, cycleIndex);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        }
    }

    // Отменяет конкретный цикл.
    public static void cancelCycle(Context context, int alarmId, int cycleIndex) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, AlarmReceiver.class);
        int requestCode = makeRequestCode(alarmId, cycleIndex);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );

        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
    }

    // Отменяет все циклы, начиная с указанного (включительно).
    // Используется, когда пользователь жмёт ВЫКЛ — чтобы убить
    // как текущий, так и все запланированные вперёд циклы.
    public static void cancelAllCyclesFrom(Context context, int alarmId, int fromCycleIndex) {
        int start = Math.max(0, fromCycleIndex);
        for (int cycle = start; cycle < MAX_CYCLES; cycle++) {
            cancelCycle(context, alarmId, cycle);
        }
    }

    // Отменяет все циклы для данного alarmId.
    public static void cancelAllCycles(Context context, int alarmId) {
        cancelAllCyclesFrom(context, alarmId, 0);
    }

    private static int makeRequestCode(int alarmId, int cycleIndex) {
        // alarmId может быть отрицательным (hashCode()).
        // Приводим к неотрицательному и вмещаем в int без переполнения.
        int safeAlarmId = alarmId & 0x00FFFFFF;
        int safeCycle = cycleIndex % MAX_CYCLES;
        return REQUEST_CODE_SALT + safeAlarmId * MAX_CYCLES + safeCycle;
    }
}
