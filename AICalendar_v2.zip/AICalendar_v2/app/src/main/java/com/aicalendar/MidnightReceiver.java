package com.aicalendar.v2;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public class MidnightReceiver extends BroadcastReceiver {

    public static final String ACTION_MIDNIGHT = "com.aicalendar.v2.ACTION_MIDNIGHT";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        if (!ACTION_MIDNIGHT.equals(intent.getAction())) return;

        // Пересчёт будильников на новое окно
        AlarmPlanner.replanAll(context);

        // Обновляем виджет
        WidgetProvider.refreshAll(context);

        // И ставим следующий на 00:00 завтра
        scheduleNextMidnight(context);
    }

    public static void scheduleNextMidnight(Context context) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) return;

            Calendar next = Calendar.getInstance();
            next.add(Calendar.DAY_OF_YEAR, 1);
            next.set(Calendar.HOUR_OF_DAY, 0);
            next.set(Calendar.MINUTE, 0);
            next.set(Calendar.SECOND, 5);
            next.set(Calendar.MILLISECOND, 0);

            Intent intent = new Intent(context, MidnightReceiver.class);
            intent.setAction(ACTION_MIDNIGHT);

            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, 999_001, intent, flags
            );

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pendingIntent
                );
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pendingIntent
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
