package com.aicalendar.v2;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class ProfileDialog extends Dialog {

    public interface OnProfileSaveListener {
        void onSave(ProfileModel profile);
        void onDelete(ProfileModel profile);
        void onClone(ProfileModel clonedProfile);
    }

    private EditText etProfileName;
    private EditText etRepeatDays;
    private LinearLayout colorContainer;
    private LinearLayout remindersLayout;

    private OnProfileSaveListener listener;
    private ProfileModel existingProfile;
    private boolean isClone;

    private final String[] colors = {
        "#FF5252", "#FF4081", "#E040FB", "#7C4DFF",
        "#536DFE", "#448AFF", "#1DE9B6", "#00E676",
        "#76FF03", "#FFEA00", "#FF9100", "#FF3D00"
    };

    private String selectedColor = colors[0];

    public ProfileDialog(@NonNull Context context, ProfileModel existingProfile, OnProfileSaveListener listener) {
        this(context, existingProfile, listener, false);
    }

    public ProfileDialog(@NonNull Context context, ProfileModel existingProfile, OnProfileSaveListener listener, boolean isClone) {
        super(context);
        this.existingProfile = existingProfile;
        this.listener = listener;
        this.isClone = isClone;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_profile);

        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        etProfileName = findViewById(R.id.etProfileName);
        etRepeatDays = findViewById(R.id.etRepeatDays);
        colorContainer = findViewById(R.id.colorContainer);
        remindersLayout = findViewById(R.id.remindersLayout);

        Button btnAddReminder = findViewById(R.id.btnAddReminder);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnClone = findViewById(R.id.btnClone);

        btnAddReminder.setOnClickListener(v -> showTimePickerAndAdd());

        if (existingProfile != null) {
            etProfileName.setText(existingProfile.getName());
            etRepeatDays.setText(String.valueOf(existingProfile.getRepeatDays()));
            selectedColor = existingProfile.getColor();

            if (existingProfile.getReminders() != null) {
                for (ReminderModel reminder : existingProfile.getReminders()) {
                    addReminderRow(reminder.getTime(), reminder.getText());
                }
            }
            sortReminders();

            if (isClone) {
                if (btnDelete != null) btnDelete.setVisibility(View.GONE);
                if (btnClone != null) btnClone.setVisibility(View.GONE);
            } else {
                if (btnDelete != null) btnDelete.setVisibility(View.VISIBLE);
                if (btnClone != null) btnClone.setVisibility(View.VISIBLE);
            }
        } else {
            etRepeatDays.setText("4");

            if (btnDelete != null) btnDelete.setVisibility(View.GONE);
            if (btnClone != null) btnClone.setVisibility(View.GONE);
        }

        setupColorCircles();

        btnCancel.setOnClickListener(v -> dismiss());

        if (btnDelete != null) {
            btnDelete.setOnClickListener(v -> {
                if (listener != null && existingProfile != null) {
                    listener.onDelete(existingProfile);
                }
                dismiss();
            });
        }

        if (btnClone != null) {
            btnClone.setOnClickListener(v -> {
                String name = etProfileName.getText().toString().trim() + " (копия)";
                String repeatStr = etRepeatDays.getText().toString().trim();

                int repeatDays = 1;
                if (!repeatStr.isEmpty()) {
                    try {
                        repeatDays = Integer.parseInt(repeatStr);
                    } catch (NumberFormatException e) {
                        repeatDays = 1;
                    }
                }

                List<ReminderModel> reminders = collectReminders();
                sortRemindersList(reminders);

                ProfileModel clonedProfile = new ProfileModel(
                    UUID.randomUUID().toString(), name, repeatDays, selectedColor, reminders);

                dismiss();
                if (listener != null) {
                    listener.onClone(clonedProfile);
                }
            });
        }

        btnSave.setOnClickListener(v -> {
            String name = etProfileName.getText().toString().trim();
            String repeatStr = etRepeatDays.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(getContext(), "Введите название профиля", Toast.LENGTH_SHORT).show();
                return;
            }

            int repeatDays = 1;
            if (!repeatStr.isEmpty()) {
                try {
                    repeatDays = Integer.parseInt(repeatStr);
                } catch (NumberFormatException e) {
                    repeatDays = 1;
                }
            }

            if (repeatDays < 1) {
                Toast.makeText(getContext(), "Повтор: минимум 1 день", Toast.LENGTH_SHORT).show();
                return;
            }

            List<ReminderModel> reminders = collectReminders();
            sortRemindersList(reminders);

            for (int i = 0; i < reminders.size(); i++) {
                for (int j = i + 1; j < reminders.size(); j++) {
                    String t1 = reminders.get(i).getTime();
                    String t2 = reminders.get(j).getTime();
                    if (t1 != null && t1.equals(t2)) {
                        Toast.makeText(getContext(),
                                       "Время " + t1 + " уже занято другим напоминанием",
                                       Toast.LENGTH_LONG).show();
                        return;
                    }
                }
            }

            String id = (existingProfile != null) ? existingProfile.getId() : UUID.randomUUID().toString();

            ProfileModel profile = new ProfileModel(id, name, repeatDays, selectedColor, reminders);

            if (existingProfile != null) {
                profile.setStartDate(existingProfile.getStartDate());
            }

            if (listener != null) {
                listener.onSave(profile);
            }
            dismiss();
        });
    }

    // ============ СБОР ДАННЫХ ИЗ UI ============

    private List<ReminderModel> collectReminders() {
        List<ReminderModel> reminders = new ArrayList<>();
        for (int i = 0; i < remindersLayout.getChildCount(); i++) {
            View row = remindersLayout.getChildAt(i);
            TextView tvTime = row.findViewById(R.id.tvReminderTime);
            EditText etText = row.findViewById(R.id.etReminderText);

            if (tvTime == null) continue;

            String time = tvTime.getText().toString();
            String text = etText != null ? etText.getText().toString().trim() : "";

            reminders.add(new ReminderModel(time, text));
        }
        return reminders;
    }

    private void sortRemindersList(List<ReminderModel> reminders) {
        Collections.sort(reminders, new Comparator<ReminderModel>() {
				@Override
				public int compare(ReminderModel a, ReminderModel b) {
					String ta = a.getTime() != null ? a.getTime() : "99:99";
					String tb = b.getTime() != null ? b.getTime() : "99:99";
					return ta.compareTo(tb);
				}
			});
    }

    // Пересобирает UI-строки в порядке возрастания времени.
    // Вызывается только при добавлении / удалении / смене времени,
    // а не при вводе текста. Фокус после пересборки восстанавливается
    // на строку с тем же временем.
    private void sortReminders() {
        List<ReminderModel> reminders = collectReminders();
        sortRemindersList(reminders);

        // Запоминаем время строки, в которой стоял фокус
        String focusedTime = null;
        View focused = getCurrentFocus();
        if (focused instanceof EditText) {
            View parent = (View) focused.getParent();
            if (parent != null) {
                TextView tvTime = parent.findViewById(R.id.tvReminderTime);
                if (tvTime != null) {
                    focusedTime = tvTime.getText().toString();
                }
            }
        }

        remindersLayout.removeAllViews();
        for (ReminderModel r : reminders) {
            addReminderRow(r.getTime(), r.getText());
        }

        // Возвращаем фокус на ту же строку, что была
        if (focusedTime != null) {
            focusReminderByTime(focusedTime);
        }
    }

    private void focusReminderByTime(String time) {
        if (time == null) return;
        for (int i = 0; i < remindersLayout.getChildCount(); i++) {
            View row = remindersLayout.getChildAt(i);
            TextView tvTime = row.findViewById(R.id.tvReminderTime);
            EditText etText = row.findViewById(R.id.etReminderText);
            if (tvTime != null && time.equals(tvTime.getText().toString()) && etText != null) {
                etText.requestFocus();
                etText.setSelection(etText.getText().length());
                return;
            }
        }
    }

    private void setupColorCircles() {
        colorContainer.removeAllViews();
        int density = (int) getContext().getResources().getDisplayMetrics().density;

        int size = 46 * density;
        int margin = 5 * density;

        for (String hexColor : colors) {
            View circle = new View(getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMargins(margin, 0, margin, 0);
            circle.setLayoutParams(params);

            boolean isSelected = hexColor.equalsIgnoreCase(selectedColor);

            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            drawable.setColor(Color.parseColor(hexColor));

            if (isSelected) {
                drawable.setStroke(3 * density, Color.WHITE);
            }

            circle.setBackground(drawable);

            circle.setOnClickListener(v -> {
                selectedColor = hexColor;
                setupColorCircles();
            });

            colorContainer.addView(circle);
        }
    }

    private void showTimePickerAndAdd() {
        Calendar cal = Calendar.getInstance();
        TimePickerDialog dialog = new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
            String time = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);

            if (isTimeAlreadyUsed(time)) {
                Toast.makeText(getContext(),
                               "Время " + time + " уже занято другим напоминанием",
                               Toast.LENGTH_LONG).show();
                return;
            }

            addReminderRow(time, "");
            sortReminders();
            focusReminderByTime(time);
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true);
        dialog.show();
    }

    private void addReminderRow(String time, String text) {
        View row = LayoutInflater.from(getContext()).inflate(R.layout.item_reminder, remindersLayout, false);

        TextView tvTime = row.findViewById(R.id.tvReminderTime);
        EditText etText = row.findViewById(R.id.etReminderText);
        TextView btnDelete = row.findViewById(R.id.btnDeleteReminder);

        tvTime.setText(time);
        etText.setText(text);

        tvTime.setOnClickListener(v -> {
            String[] parts = tvTime.getText().toString().split(":");
            int h = Integer.parseInt(parts[0]);
            int m = Integer.parseInt(parts[1]);
            TimePickerDialog dialog = new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
                String newTime = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);

                if (isTimeAlreadyUsedExcept(newTime, row)) {
                    Toast.makeText(getContext(),
                                   "Время " + newTime + " уже занято другим напоминанием",
                                   Toast.LENGTH_LONG).show();
                    return;
                }

                tvTime.setText(newTime);
                sortReminders();
            }, h, m, true);
            dialog.show();
        });

        btnDelete.setOnClickListener(v -> {
            remindersLayout.removeView(row);
            sortReminders();
        });

        remindersLayout.addView(row);
    }

    private boolean isTimeAlreadyUsed(String time) {
        for (int i = 0; i < remindersLayout.getChildCount(); i++) {
            View row = remindersLayout.getChildAt(i);
            TextView tvTime = row.findViewById(R.id.tvReminderTime);
            if (tvTime != null && time.equals(tvTime.getText().toString())) {
                return true;
            }
        }
        return false;
    }

    private boolean isTimeAlreadyUsedExcept(String time, View excludeRow) {
        for (int i = 0; i < remindersLayout.getChildCount(); i++) {
            View row = remindersLayout.getChildAt(i);
            if (row == excludeRow) continue;
            TextView tvTime = row.findViewById(R.id.tvReminderTime);
            if (tvTime != null && time.equals(tvTime.getText().toString())) {
                return true;
            }
        }
        return false;
    }
}
