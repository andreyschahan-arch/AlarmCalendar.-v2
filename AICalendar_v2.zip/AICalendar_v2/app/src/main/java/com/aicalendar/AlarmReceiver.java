package com.aicalendar.v2;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.util.Random;

public class AlarmReceiver extends BroadcastReceiver {

    // Шутливые фразы для шторки. Каждая срабатывание — случайная.
    // В окне будильника остаются настоящие TITLE и MESSAGE.
    private static final String[] SILLY_MAIN = {
        "Хочу тебя потревожить 😈",
        "Тук-тук. Это я, твой будильник.",
        "Просыпайся, соня ☀️",
        "Вставай, мир ждёт!",
        "Эй, ты там живой?",
        "Дзынь-дзынь! Хватит спать 🌞",
        "Утро добрым не бывает, но я стараюсь.",
        "Подъём! Кто рано встаёт, тому Бог подаёт.",
        "Я знаю, ты хотел поспать ещё. Не получится.",
        "Ты сильный. Ты встанешь. Наверное."
    };

    private static final String[] SILLY_PRE = {
        "Скоро-скоро ⏰",
        "Разминайся, через пару минут будет весело",
        "Лёгкое предупреждение: я уже близко",
        "Ты только не пугайся, ладно?",
        "Пять минут — и я за тобой",
        "Готовься, я на подходе",
        "Спокойно, это ещё не будильник. Но скоро."
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        AlarmSettings checkSettings = AlarmSettings.load(context);
        if (checkSettings.isVacationNow()) {
            return;
        }

        int alarmId = intent.getIntExtra("ALARM_ID", (int) System.currentTimeMillis());
        String title = intent.getStringExtra("TITLE");
        String message = intent.getStringExtra("MESSAGE");
        boolean isPreAlarm = intent.getBooleanExtra("IS_PRE_ALARM", false);
        String ringtoneUri = intent.getStringExtra("RINGTONE_URI");
        int cycleIndex = intent.getIntExtra("CYCLE_INDEX", 0);

        if (title == null) title = "Будильник";
        if (message == null) message = "Пора вставать!";

        if (ringtoneUri == null || ringtoneUri.isEmpty()) {
            Uri defaultUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (defaultUri != null) {
                ringtoneUri = defaultUri.toString();
            }
        }

        Intent alarmIntent = new Intent(context, AlarmActivity.class);
        alarmIntent.putExtra("TITLE", title);
        alarmIntent.putExtra("MESSAGE", message);
        alarmIntent.putExtra("ALARM_ID", alarmId);
        alarmIntent.putExtra("IS_PRE_ALARM", isPreAlarm);
        alarmIntent.putExtra("RINGTONE_URI", ringtoneUri);
        alarmIntent.putExtra("CYCLE_INDEX", cycleIndex);

        alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                             | Intent.FLAG_ACTIVITY_CLEAR_TOP
                             | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        try {
            context.startActivity(alarmIntent);
        } catch (Exception e) {
            e.printStackTrace();
        }

        NotificationManager notificationManager =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = isPreAlarm ? "pre_alarm_channel_v4" : "main_alarm_channel_v4";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                channelId,
                isPreAlarm ? "Пре-будильник" : "Основной будильник",
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            channel.setShowBadge(false);

            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            : PendingIntent.FLAG_UPDATE_CURRENT;

        int fsRequestCode = 900_000_000 + (alarmId & 0x00FFFFFF) * 100 + (cycleIndex % 100);

        PendingIntent fullScreenPendingIntent =
            PendingIntent.getActivity(context, fsRequestCode, alarmIntent, flags);

        // Случайная шутливая фраза вместо реального title/message
        String[] pool = isPreAlarm ? SILLY_PRE : SILLY_MAIN;
        String sillyText = pool[new Random().nextInt(pool.length)];

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("AlarmCalendar")
            .setContentText(sillyText)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(null)
            .setVibrate(null)
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false);

        if (notificationManager != null) {
            notificationManager.notify(alarmId, builder.build());
        }

        WidgetProvider.refreshAll(context);
    }
}
