package com.aicalendar.v2;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.viewpager2.widget.ViewPager2;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TextView tvMonthYear;

    private List<ProfileModel> profileList = new ArrayList<>();
    private ProfilesListDialog profilesListDialog;
    private MonthPagerAdapter adapter;

    private AlarmSettingsDialog settingsDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ставим обновление виджета и пересчёт будильников в полночь
        MidnightReceiver.scheduleNextMidnight(this);

        // Сразу обновляем виджет при входе
        WidgetProvider.refreshAll(this);

        List<ProfileModel> loadedProfiles = ProfileStorage.loadProfiles(this);
        if (loadedProfiles != null && !loadedProfiles.isEmpty()) {
            profileList.clear();
            profileList.addAll(loadedProfiles);
        }

        tvMonthYear = findViewById(R.id.tvMonthYear);
        viewPager = findViewById(R.id.viewPager);

        TextView btnMenu = findViewById(R.id.btnMenu);
        if (btnMenu != null) {
            btnMenu.setOnClickListener(this::showPopupMenu);
        }

        adapter = new MonthPagerAdapter(profileList);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(MonthPagerAdapter.START_POSITION, false);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
				@Override
				public void onPageSelected(int position) {
					super.onPageSelected(position);
					updateTitle(position);
				}
			});

        findViewById(R.id.btnPrevMonth).setOnClickListener(v ->
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true)
        );

        findViewById(R.id.btnNextMonth).setOnClickListener(v ->
            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true)
        );

        updateTitle(MonthPagerAdapter.START_POSITION);
    }

    @Override
    protected void onResume() {
        super.onResume();
        WidgetProvider.refreshAll(this);
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);

        popup.getMenu().add("Управление профилями");
        popup.getMenu().add("Настройки будильника");
        popup.getMenu().add("🏖️ Режим отпуска");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.contains("Управление профилями")) {
                showProfilesListDialog();
                return true;
            } else if (title.contains("Настройки будильника")) {
                showAlarmSettingsDialog();
                return true;
            } else if (title.contains("Режим отпуска")) {
                showVacationDialog();
                return true;
            }
            return false;
        });

        popup.show();
    }

    private void showVacationDialog() {
        VacationDialog dialog = new VacationDialog(this, () -> {
            // Глобальная настройка — пересчитываем все профили
            AlarmPlanner.replanAll(MainActivity.this);

            if (adapter != null) {
                adapter.notifyItemRangeChanged(0, adapter.getItemCount(), "REFRESH");
            }

            WidgetProvider.refreshAll(MainActivity.this);

            AlarmSettings s = AlarmSettings.load(MainActivity.this);

            if (!s.isVacationActive()) {
                Toast.makeText(MainActivity.this,
                               "Режим отпуска выключен",
                               Toast.LENGTH_SHORT).show();
            } else if (s.isVacationNow()) {
                Toast.makeText(MainActivity.this,
                               "🏖️ Режим отпуска активен прямо сейчас",
                               Toast.LENGTH_SHORT).show();
            } else {
                String start = s.getVacationStart();
                String end = s.getVacationEnd();
                Toast.makeText(MainActivity.this,
                               "🏖️ Отпуск запланирован с " + start + " по " + end,
                               Toast.LENGTH_LONG).show();
            }
        });
        dialog.show();
    }

    private void showAlarmSettingsDialog() {
        settingsDialog = new AlarmSettingsDialog(this);
        settingsDialog.setOnDismissListener(d -> {
            // Глобальные настройки (пре-минуты, повторы) — пересчитываем все
            AlarmPlanner.replanAll(MainActivity.this);
            WidgetProvider.refreshAll(MainActivity.this);
        });
        settingsDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            boolean isMain = (requestCode == AlarmSettingsDialog.REQUEST_CODE_PICK_FILE_MAIN);
            boolean isPre = (requestCode == AlarmSettingsDialog.REQUEST_CODE_PICK_FILE_PRE);

            if (isMain || isPre) {
                Uri audioUri = data.getData();

                try {
                    getContentResolver().takePersistableUriPermission(
                        audioUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                String fileName = "Своя мелодия";
                Cursor cursor = getContentResolver().query(audioUri, null, null, null, null);
                if (cursor != null) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        fileName = cursor.getString(nameIndex);
                    }
                    cursor.close();
                }

                AlarmSettings settings = AlarmSettings.load(this);
                if (isPre) {
                    settings.setPreRingtoneTitle(fileName);
                    settings.setPreRingtoneUri(audioUri.toString());
                } else {
                    settings.setMainRingtoneTitle(fileName);
                    settings.setMainRingtoneUri(audioUri.toString());
                }
                settings.save(this);

                if (settingsDialog != null && settingsDialog.isShowing()) {
                    settingsDialog.refreshRingtoneTitles();
                }
            }
        }
    }

    private void showProfilesListDialog() {
        profilesListDialog = new ProfilesListDialog(this, profileList, new ProfilesListDialog.OnProfileListActionListener() {
                @Override
                public void onCreateNewProfile() {
                    showProfileEditDialog(null);
                }

                @Override
                public void onEditProfile(ProfileModel profile) {
                    showProfileEditDialog(profile);
                }

                @Override
                public void onDeleteProfile(ProfileModel profile) {
                    // Снимаем будильники профиля перед удалением
                    AlarmPlanner.replanProfile(MainActivity.this, profile);

                    profileList.remove(profile);
                    ProfileStorage.saveProfiles(MainActivity.this, profileList);

                    if (profilesListDialog != null) {
                        profilesListDialog.updateProfiles(profileList);
                    }
                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }

                    WidgetProvider.refreshAll(MainActivity.this);

                    Toast.makeText(MainActivity.this, "Профиль удалён", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onSelectProfile(ProfileModel profile) {
                    Toast.makeText(MainActivity.this, "Выбран профиль: " + profile.getName(), Toast.LENGTH_SHORT).show();
                }
            });

        profilesListDialog.show();
    }

    public void showProfileEditDialog(ProfileModel profileToEdit) {
        showProfileEditDialog(profileToEdit, false);
    }

    public void showProfileEditDialog(ProfileModel profileToEdit, boolean isClone) {
        ProfileDialog dialog = new ProfileDialog(this, profileToEdit, new ProfileDialog.OnProfileSaveListener() {
                @Override
                public void onSave(ProfileModel savedProfile) {
                    boolean found = false;
                    for (int i = 0; i < profileList.size(); i++) {
                        ProfileModel old = profileList.get(i);
                        if (old.getId().equals(savedProfile.getId())) {
                            if (savedProfile.getStartDate() == null) {
                                savedProfile.setStartDate(old.getStartDate());
                            }
                            profileList.set(i, savedProfile);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        profileList.add(savedProfile);
                    }

                    ProfileStorage.saveProfiles(MainActivity.this, profileList);

                    // Пересчёт одного профиля — только его будильники
                    AlarmPlanner.replanProfile(MainActivity.this, savedProfile);

                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }

                    WidgetProvider.refreshAll(MainActivity.this);

                    Toast.makeText(MainActivity.this, "Сохранено: " + savedProfile.getName(), Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onDelete(ProfileModel profileToDelete) {
                    AlarmPlanner.replanProfile(MainActivity.this, profileToDelete);

                    profileList.removeIf(p -> p.getId().equals(profileToDelete.getId()));
                    ProfileStorage.saveProfiles(MainActivity.this, profileList);

                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }

                    WidgetProvider.refreshAll(MainActivity.this);

                    Toast.makeText(MainActivity.this, "Удалено: " + profileToDelete.getName(), Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onClone(ProfileModel clonedProfile) {
                    showProfileEditDialog(clonedProfile, true);
                }
            }, isClone);
        dialog.show();
    }

    public void openDayDetails(Date date) {
        DayDetailsDialog dialog = new DayDetailsDialog(this, date, profileList, new DayDetailsDialog.OnStartCycleSelectListener() {
                @Override
                public void onSetStartCycle(ProfileModel profile, String dateStr) {
                    if (dateStr == null || dateStr.isEmpty()) {
                        profile.setStartDate("");
                        ProfileStorage.saveProfiles(MainActivity.this, profileList);
                        AlarmPlanner.replanProfile(MainActivity.this, profile);

                        if (adapter != null) {
                            adapter.notifyItemRangeChanged(0, adapter.getItemCount(), "REFRESH");
                        }

                        WidgetProvider.refreshAll(MainActivity.this);

                        Toast.makeText(MainActivity.this,
                                       "Старт у профиля \"" + profile.getName() + "\" сброшен",
                                       Toast.LENGTH_SHORT).show();
                        return;
                    }

                    profile.setStartDate(dateStr);
                    ProfileStorage.saveProfiles(MainActivity.this, profileList);
                    AlarmPlanner.replanProfile(MainActivity.this, profile);

                    if (adapter != null) {
                        adapter.notifyItemRangeChanged(0, adapter.getItemCount(), "REFRESH");
                    }

                    WidgetProvider.refreshAll(MainActivity.this);

                    Toast.makeText(MainActivity.this,
                                   "Профиль \"" + profile.getName() + "\" установлен стартом для " + dateStr,
                                   Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onEditProfileRequested(ProfileModel profile) {
                    showProfileEditDialog(profile);
                }
            });
        dialog.show();
    }

    private void updateTitle(int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - MonthPagerAdapter.START_POSITION);

        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(cal.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);
    }
}
