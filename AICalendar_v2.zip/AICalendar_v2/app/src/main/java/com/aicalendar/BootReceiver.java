package com.aicalendar.v2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
            && !"android.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())
            && !"com.htc.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())) {
            return;
        }

        // После перезагрузки AlarmManager пуст — пересчитываем всё заново
        AlarmPlanner.replanAll(context);
    }
}
