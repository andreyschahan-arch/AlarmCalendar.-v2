package com.aicalendar.v2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
            && !"android.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())
            && !"com.htc.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())) {
            return;
        }

        // Если идёт отпуск — не восстанавливаем будильники
        AlarmSettings checkSettings = AlarmSettings.load(context);
        if (checkSettings.isVacationNow()) return;

        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
        if (profiles == null || profiles.isEmpty()) return;

        AlarmSettings alarmSettings = AlarmSettings.load(context);
        int preAlarmMinutes = alarmSettings.getPreAlarmMinutesBefore();

        Calendar now = Calendar.getInstance();

        for (ProfileModel profile : profiles) {
            if (profile == null || profile.getStartDate() == null) continue;
            if (profile.getReminders() == null || profile.getReminders().isEmpty()) continue;

            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date startDate = sdf.parse(profile.getStartDate());
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                Calendar todayCal = (Calendar) now.clone();
                todayCal.set(Calendar.HOUR_OF_DAY, 0);
                todayCal.set(Calendar.MINUTE, 0);
                todayCal.set(Calendar.SECOND, 0);
                todayCal.set(Calendar.MILLISECOND, 0);

                long diffDays = (todayCal.getTimeInMillis() - startCal.getTimeInMillis()) / (24 * 60 * 60 * 1000);
                int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffDays < 0 || (diffDays % repeatDays != 0)) continue;

                for (ReminderModel reminder : profile.getReminders()) {
                    if (reminder == null || reminder.getTime() == null) continue;

                    String[] timeParts = reminder.getTime().split(":");
                    if (timeParts.length < 2) continue;

                    int hour = Integer.parseInt(timeParts[0]);
                    int minute = Integer.parseInt(timeParts[1]);

                    Calendar mainAlarmCal = Calendar.getInstance();
                    mainAlarmCal.set(Calendar.HOUR_OF_DAY, hour);
                    mainAlarmCal.set(Calendar.MINUTE, minute);
                    mainAlarmCal.set(Calendar.SECOND, 0);
                    mainAlarmCal.set(Calendar.MILLISECOND, 0);

                    if (mainAlarmCal.before(now)) {
                        mainAlarmCal.add(Calendar.DAY_OF_YEAR, repeatDays);
                    }

                    int mainAlarmId = (profile.getId() + reminder.getTime() + "_main").hashCode();

                    AlarmScheduler.scheduleAlarm(
                        context,
                        mainAlarmCal.getTimeInMillis(),
                        mainAlarmId,
                        profile.getName(),
                        reminder.getText(),
                        false,
                        alarmSettings.getMainRingtoneUri()
                    );

                    if (preAlarmMinutes > 0) {
                        Calendar preAlarmCal = (Calendar) mainAlarmCal.clone();
                        preAlarmCal.add(Calendar.MINUTE, -preAlarmMinutes);

                        if (preAlarmCal.after(now)) {
                            int preAlarmId = (profile.getId() + reminder.getTime() + "_pre").hashCode();
                            String preTitle = "До " + profile.getName() + " осталось " + preAlarmMinutes + " мин";

                            AlarmScheduler.scheduleAlarm(
                                context,
                                preAlarmCal.getTimeInMillis(),
                                preAlarmId,
                                preTitle,
                                reminder.getText(),
                                true,
                                alarmSettings.getPreRingtoneUri()
                            );
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
