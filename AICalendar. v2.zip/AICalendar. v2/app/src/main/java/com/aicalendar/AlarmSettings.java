package com.aicalendar.v2;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AlarmSettings {
    private static final String PREF_NAME = "alarm_settings";

    private int volume = 80;
    private int repeatCount = 5;
    private int repeatIntervalMinutes = 5;
    private String mainRingtoneUri = "";
    private String mainRingtoneTitle = "Стандартный сигнал";
    private int preAlarmMinutesBefore = 5;
    private String preRingtoneUri = "";
    private String preRingtoneTitle = "Стандартный сигнал";

    // Отпуск
    private boolean vacationActive = false;
    private String vacationStart = ""; // yyyy-MM-dd
    private String vacationEnd = "";   // yyyy-MM-dd

    public AlarmSettings() {}

    public static AlarmSettings load(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        AlarmSettings settings = new AlarmSettings();

        Uri defaultUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        String defaultUriStr = defaultUri != null ? defaultUri.toString() : "";

        settings.volume = prefs.getInt("volume", 80);
        settings.repeatCount = prefs.getInt("repeatCount", 5);
        settings.repeatIntervalMinutes = prefs.getInt("repeatIntervalMinutes", 5);

        settings.mainRingtoneUri = prefs.getString("mainRingtoneUri", defaultUriStr);
        settings.mainRingtoneTitle = prefs.getString("mainRingtoneTitle", "Стандартный сигнал");

        settings.preAlarmMinutesBefore = prefs.getInt("preAlarmMinutesBefore", 5);
        settings.preRingtoneUri = prefs.getString("preRingtoneUri", defaultUriStr);
        settings.preRingtoneTitle = prefs.getString("preRingtoneTitle", "Стандартный сигнал");

        settings.vacationActive = prefs.getBoolean("vacationActive", false);
        settings.vacationStart = prefs.getString("vacationStart", "");
        settings.vacationEnd = prefs.getString("vacationEnd", "");

        return settings;
    }

    public void save(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit()
            .putInt("volume", volume)
            .putInt("repeatCount", repeatCount)
            .putInt("repeatIntervalMinutes", repeatIntervalMinutes)
            .putString("mainRingtoneUri", mainRingtoneUri)
            .putString("mainRingtoneTitle", mainRingtoneTitle)
            .putInt("preAlarmMinutesBefore", preAlarmMinutesBefore)
            .putString("preRingtoneUri", preRingtoneUri)
            .putString("preRingtoneTitle", preRingtoneTitle)
            .putBoolean("vacationActive", vacationActive)
            .putString("vacationStart", vacationStart)
            .putString("vacationEnd", vacationEnd)
            .apply();
    }

    // ===== Логика отпуска =====
    public boolean isVacationNow() {
        if (!vacationActive) return false;
        if (vacationStart == null || vacationStart.isEmpty()) return false;
        if (vacationEnd == null || vacationEnd.isEmpty()) return false;

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            Date start = sdf.parse(vacationStart);
            Date end = sdf.parse(vacationEnd);
            if (start == null || end == null) return false;

            Calendar startCal = Calendar.getInstance();
            startCal.setTime(start);
            startCal.set(Calendar.HOUR_OF_DAY, 0);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
            startCal.set(Calendar.MILLISECOND, 0);

            Calendar endCal = Calendar.getInstance();
            endCal.setTime(end);
            endCal.set(Calendar.HOUR_OF_DAY, 23);
            endCal.set(Calendar.MINUTE, 59);
            endCal.set(Calendar.SECOND, 59);
            endCal.set(Calendar.MILLISECOND, 999);

            Calendar now = Calendar.getInstance();
            long t = now.getTimeInMillis();
            return t >= startCal.getTimeInMillis() && t <= endCal.getTimeInMillis();
        } catch (Exception e) {
            return false;
        }
    }

    public int getVolume() { return volume; }
    public void setVolume(int volume) { this.volume = volume; }

    public int getRepeatCount() { return repeatCount; }
    public void setRepeatCount(int repeatCount) { this.repeatCount = repeatCount; }

    public int getRepeatIntervalMinutes() { return repeatIntervalMinutes; }
    public void setRepeatIntervalMinutes(int repeatIntervalMinutes) { this.repeatIntervalMinutes = repeatIntervalMinutes; }

    public String getMainRingtoneUri() { return mainRingtoneUri; }
    public void setMainRingtoneUri(String mainRingtoneUri) { this.mainRingtoneUri = mainRingtoneUri; }

    public String getMainRingtoneTitle() { return mainRingtoneTitle; }
    public void setMainRingtoneTitle(String mainRingtoneTitle) { this.mainRingtoneTitle = mainRingtoneTitle; }

    public int getPreAlarmMinutesBefore() { return preAlarmMinutesBefore; }
    public void setPreAlarmMinutesBefore(int preAlarmMinutesBefore) { this.preAlarmMinutesBefore = preAlarmMinutesBefore; }

    public String getPreRingtoneUri() { return preRingtoneUri; }
    public void setPreRingtoneUri(String preRingtoneUri) { this.preRingtoneUri = preRingtoneUri; }

    public String getPreRingtoneTitle() { return preRingtoneTitle; }
    public void setPreRingtoneTitle(String preRingtoneTitle) { this.preRingtoneTitle = preRingtoneTitle; }

    public boolean isVacationActive() { return vacationActive; }
    public void setVacationActive(boolean vacationActive) { this.vacationActive = vacationActive; }

    public String getVacationStart() { return vacationStart; }
    public void setVacationStart(String vacationStart) { this.vacationStart = vacationStart; }

    public String getVacationEnd() { return vacationEnd; }
    public void setVacationEnd(String vacationEnd) { this.vacationEnd = vacationEnd; }
}
