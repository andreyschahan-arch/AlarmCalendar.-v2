package com.aicalendar.v2;

import android.content.Context;
import android.content.SharedPreferences;

public class AlarmSettings {

    private static final String PREF_NAME = "alarm_settings";

    private int volume = 80;
    private int repeatCount = 5;
    private int repeatIntervalMinutes = 5;
    private String mainRingtoneUri = "";
    private String mainRingtoneTitle = "Ripple";

    private int preAlarmMinutesBefore = 5;
    private String preRingtoneUri = "";
    private String preRingtoneTitle = "Tik_tik3";

    public AlarmSettings() {}

    public static AlarmSettings load(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        AlarmSettings settings = new AlarmSettings();
        settings.volume = prefs.getInt("volume", 80);
        settings.repeatCount = prefs.getInt("repeatCount", 5);
        settings.repeatIntervalMinutes = prefs.getInt("repeatIntervalMinutes", 5);
        settings.mainRingtoneUri = prefs.getString("mainRingtoneUri", "");
        settings.mainRingtoneTitle = prefs.getString("mainRingtoneTitle", "Ripple");
        settings.preAlarmMinutesBefore = prefs.getInt("preAlarmMinutesBefore", 5);
        settings.preRingtoneUri = prefs.getString("preRingtoneUri", "");
        settings.preRingtoneTitle = prefs.getString("preRingtoneTitle", "Tik_tik3");
        return settings;
    }

    public void save(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit()
			.putInt("volume", volume)
			.putInt("repeatCount", repeatCount)
			.putInt("repeatIntervalMinutes", repeatIntervalMinutes)
			.putString("mainRingtoneUri", mainRingtoneUri)
			.putString("mainRingtoneTitle", mainRingtoneTitle)
			.putInt("preAlarmMinutesBefore", preAlarmMinutesBefore)
			.putString("preRingtoneUri", preRingtoneUri)
			.putString("preRingtoneTitle", preRingtoneTitle)
			.apply();
    }

    // Геттеры и сеттеры
    public int getVolume() { return volume; }
    public void setVolume(int volume) { this.volume = volume; }

    public int getRepeatCount() { return repeatCount; }
    public void setRepeatCount(int repeatCount) { this.repeatCount = repeatCount; }

    public int getRepeatIntervalMinutes() { return repeatIntervalMinutes; }
    public void setRepeatIntervalMinutes(int repeatIntervalMinutes) { this.repeatIntervalMinutes = repeatIntervalMinutes; }

    public String getMainRingtoneUri() { return mainRingtoneUri; }
    public void setMainRingtoneUri(String mainRingtoneUri) { this.mainRingtoneUri = mainRingtoneUri; }

    public String getMainRingtoneTitle() { return mainRingtoneTitle; }
    public void setMainRingtoneTitle(String mainRingtoneTitle) { this.mainRingtoneTitle = mainRingtoneTitle; }

    public int getPreAlarmMinutesBefore() { return preAlarmMinutesBefore; }
    public void setPreAlarmMinutesBefore(int preAlarmMinutesBefore) { this.preAlarmMinutesBefore = preAlarmMinutesBefore; }

    public String getPreRingtoneUri() { return preRingtoneUri; }
    public void setPreRingtoneUri(String preRingtoneUri) { this.preRingtoneUri = preRingtoneUri; }

    public String getPreRingtoneTitle() { return preRingtoneTitle; }
    public void setPreRingtoneTitle(String preRingtoneTitle) { this.preRingtoneTitle = preRingtoneTitle; }
}

