package com.aicalendar.v2;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class AlarmScheduler {

    public static void scheduleAlarm(Context context, long triggerAtMillis, int alarmId, String title, String message, boolean isPreAlarm) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        SharedPreferences prefs = context.getSharedPreferences("ai_calendar_prefs", Context.MODE_PRIVATE);
        String ringtoneUri = isPreAlarm 
			? prefs.getString("pre_alarm_ringtone", "") 
			: prefs.getString("main_alarm_ringtone", "");

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("ALARM_ID", alarmId);
        intent.putExtra("TITLE", title);
        intent.putExtra("MESSAGE", message);
        intent.putExtra("IS_PRE_ALARM", isPreAlarm);
        intent.putExtra("RINGTONE_URI", ringtoneUri);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
			context,
			alarmId,
			intent,
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        }
    }
}

