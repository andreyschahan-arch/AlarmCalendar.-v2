package com.aicalendar.v2;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public class AlarmScheduler {

    // Отмена будильника по его ID (полностью стирает "призрак" из системного AlarmManager)
    public static void cancelAlarm(Context context, int alarmId) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, AlarmReceiver.class);

        // requestCode ДОЛЖЕН совпадать с тем, с которым регистрировали!
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
			context,
			alarmId,
			intent,
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel();
    }
}

