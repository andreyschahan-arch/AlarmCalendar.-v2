package com.aicalendar.v2;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class DayAdapter extends RecyclerView.Adapter<DayAdapter.DayViewHolder> {

    public interface OnDayClickListener {
        void onDayClick(DayModel day);
    }

    private final List<DayModel> days = new ArrayList<>();
    private List<ProfileModel> profileList;
    private final OnDayClickListener listener;
    private int cellHeight;

    public DayAdapter(List<DayModel> days, List<ProfileModel> profileList, int cellHeight, OnDayClickListener listener) {
        if (days != null) this.days.addAll(days);
        this.profileList = profileList;
        this.cellHeight = cellHeight;
        this.listener = listener;
    }

    public void updateData(List<DayModel> newDays, List<ProfileModel> newProfiles) {
        this.days.clear();
        if (newDays != null) this.days.addAll(newDays);
        this.profileList = newProfiles;
        notifyDataSetChanged();
    }

    public void setCellHeight(int newHeight) {
        if (newHeight > 0 && newHeight != this.cellHeight) {
            this.cellHeight = newHeight;
            notifyDataSetChanged();
        }
    }

    @NonNull
    @Override
    public DayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_day, parent, false);

        if (cellHeight > 0) {
            ViewGroup.LayoutParams params = view.getLayoutParams();
            if (params != null) {
                params.height = cellHeight;
                view.setLayoutParams(params);
            }
        } else {
            // Если высота ещё не вычислена — ставим дефолт, чтобы ячейка не схлопнулась
            int density = (int) parent.getContext().getResources().getDisplayMetrics().density;
            ViewGroup.LayoutParams params = view.getLayoutParams();
            if (params != null) {
                params.height = 60 * density;
                view.setLayoutParams(params);
            }
        }

        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DayViewHolder holder, int position) {
        DayModel day = days.get(position);
        holder.tvDayNumber.setText(day.getDayNumber());

        int borderColor = Color.TRANSPARENT;
        int borderWidthDp = 1;

        if (day.isCurrentMonth()) {
            holder.tvDayNumber.setTextColor(Color.WHITE);
            borderColor = Color.parseColor("#333333");
        } else {
            holder.tvDayNumber.setTextColor(Color.parseColor("#444444"));
        }

        if (day.isCurrentMonth() && day.getDate() != null && profileList != null && !profileList.isEmpty()) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

            for (ProfileModel profile : profileList) {
                if (profile.getStartDate() == null || profile.getStartDate().trim().isEmpty()) {
                    continue;
                }

                try {
                    Calendar startCal = Calendar.getInstance();
                    startCal.setTime(sdf.parse(profile.getStartDate()));

                    Calendar dayCal = Calendar.getInstance();
                    dayCal.setTime(day.getDate());

                    startCal.set(Calendar.HOUR_OF_DAY, 0);
                    startCal.set(Calendar.MINUTE, 0);
                    startCal.set(Calendar.SECOND, 0);
                    startCal.set(Calendar.MILLISECOND, 0);

                    dayCal.set(Calendar.HOUR_OF_DAY, 0);
                    dayCal.set(Calendar.MINUTE, 0);
                    dayCal.set(Calendar.SECOND, 0);
                    dayCal.set(Calendar.MILLISECOND, 0);

                    long diffInMillis = dayCal.getTimeInMillis() - startCal.getTimeInMillis();
                    long diffInDays = diffInMillis / (24 * 60 * 60 * 1000);

                    int repeat = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                    if (diffInDays >= 0 && (diffInDays % repeat == 0)) {
                        if (profile.getColor() != null && !profile.getColor().isEmpty()) {
                            borderColor = Color.parseColor(profile.getColor());
                            borderWidthDp = 3;
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);

        float density = holder.itemView.getContext().getResources().getDisplayMetrics().density;
        shape.setCornerRadius(10f * density);
        shape.setColor(Color.parseColor("#121212"));

        if (borderColor != Color.TRANSPARENT) {
            shape.setStroke((int) (2 * density), borderColor);
        }

        holder.container.setBackground(shape);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDayClick(day);
            }
        });
    }

    @Override
    public int getItemCount() {
        return days.size();
    }

    static class DayViewHolder extends RecyclerView.ViewHolder {
        TextView tvDayNumber;
        View container;

        public DayViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDayNumber = itemView.findViewById(R.id.tvDayNumber);
            container = itemView.findViewById(R.id.dayCellContainer);
            if (container == null) {
                container = itemView;
            }
        }
    }
}
