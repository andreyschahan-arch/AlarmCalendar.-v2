package com.aicalendar.v2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DayAdapter extends RecyclerView.Adapter<DayAdapter.DayViewHolder> {

    public interface OnDayClickListener {
        void onDayClick(DayModel day);
    }

    private final List<DayModel> days;
    private final OnDayClickListener listener;

    public DayAdapter(List<DayModel> days, OnDayClickListener listener) {
        this.days = days;
        this.listener = listener;
    }

    @NonNull
    @Override
    public DayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_day, parent, false);

        parent.post(() -> {
            int parentHeight = parent.getHeight();
            if (parentHeight > 0) {
                ViewGroup.LayoutParams params = view.getLayoutParams();
                int density = (int) parent.getContext().getResources().getDisplayMetrics().density;
                int bottomMargin = 16 * density;

                params.height = (parentHeight - bottomMargin) / 6;
                view.setLayoutParams(params);
            }
        });

        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DayViewHolder holder, int position) {
        DayModel day = days.get(position);
        holder.tvDayNumber.setText(day.getDayNumber());

        if (day.isCurrentMonth()) {
            holder.container.setBackgroundResource(R.drawable.cell_border);
            holder.tvDayNumber.setTextColor(Color.WHITE);
        } else {
            holder.container.setBackgroundColor(Color.TRANSPARENT);
            holder.tvDayNumber.setTextColor(Color.parseColor("#444444"));
        }

        // Клик по ячейке дня
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDayClick(day);
            }
        });
    }

    @Override
    public int getItemCount() {
        return days.size();
    }

    static class DayViewHolder extends RecyclerView.ViewHolder {
        TextView tvDayNumber;
        View container;

        public DayViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDayNumber = itemView.findViewById(R.id.tvDayNumber);
            container = itemView.findViewById(R.id.dayCellContainer);
        }
    }
}

