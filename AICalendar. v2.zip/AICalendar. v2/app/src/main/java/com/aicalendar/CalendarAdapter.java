package com.aicalendar.v2;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class CalendarAdapter extends BaseAdapter {

    private final Context context;
    private final List<String> days = new ArrayList<>();

    public CalendarAdapter(Context context, List<String> days) {
        this.context = context;
        this.days.addAll(days);
    }

    @Override
    public int getCount() {
        return days.size();
    }

    @Override
    public Object getItem(int position) {
        return days.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_day, parent, false);
        }

        TextView tvDayNumber = convertView.findViewById(R.id.tvDayNumber);
        TextView tvShiftName = convertView.findViewById(R.id.tvShiftName);
        View container = convertView.findViewById(R.id.dayCellContainer);

        String dayText = days.get(position);
        tvDayNumber.setText(dayText);

        // Если ячейка пустая (сдвиг начала месяца) — скрываем границы
        if (dayText.isEmpty()) {
            container.setBackgroundColor(Color.TRANSPARENT);
            tvShiftName.setText("");
        } else {
            container.setBackgroundResource(R.drawable.cell_border);
            // Тут позже подключим вывод названия смены
            tvShiftName.setText(""); 
        }

        return convertView;
    }
}

