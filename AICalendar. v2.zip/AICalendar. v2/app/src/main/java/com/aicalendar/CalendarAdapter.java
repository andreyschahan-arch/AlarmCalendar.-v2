package com.aicalendar.v2;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class CalendarAdapter extends BaseAdapter {

    private final Context context;
    private final List<DayModel> days = new ArrayList<>();

    public CalendarAdapter(Context context, List<DayModel> days) {
        this.context = context;
        this.days.addAll(days);
    }

    @Override
    public int getCount() {
        return days.size();
    }

    @Override
    public Object getItem(int position) {
        return days.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_day, parent, false);
        }

        TextView tvDayNumber = convertView.findViewById(R.id.tvDayNumber);
        View container = convertView.findViewById(R.id.dayCellContainer);

        DayModel day = days.get(position);
        tvDayNumber.setText(day.getDayNumber());

        if (day.isCurrentMonth()) {
            // Дни текущего месяца: темная карточка с рамкой
            container.setBackgroundResource(R.drawable.cell_border);
            tvDayNumber.setTextColor(Color.parseColor("#FFFFFF"));
        } else {
            // Дни соседних месяцев: без карточки, серый полупрозрачный текст
            container.setBackgroundColor(Color.TRANSPARENT);
            tvDayNumber.setTextColor(Color.parseColor("#444444"));
        }

        return convertView;
    }
}

