package com.aicalendar.v2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DayDetailsDialog extends Dialog {

    private final Date selectedDate;
    private final String selectedDateStr; // "yyyy-MM-dd"
    private final List<ProfileModel> profileList;
    private final OnStartCycleSelectListener listener;

    public interface OnStartCycleSelectListener {
        void onSetStartCycle(ProfileModel profile, String dateStr);
    }

    public DayDetailsDialog(@NonNull Context context, Date selectedDate, List<ProfileModel> profileList, OnStartCycleSelectListener listener) {
        super(context);
        this.selectedDate = selectedDate;
        this.profileList = profileList;
        this.listener = listener;

        SimpleDateFormat sdfFull = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        this.selectedDateStr = sdfFull.format(selectedDate);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_day_details);

        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        TextView tvSelectedDateTitle = findViewById(R.id.tvSelectedDateTitle);
        LinearLayout startCyclesContainer = findViewById(R.id.startCyclesContainer);

        // Устанавливаем заголовок "26 сентября 2026"
        SimpleDateFormat sdfDisplay = new SimpleDateFormat("d MMMM yyyy", new Locale("ru"));
        tvSelectedDateTitle.setText(sdfDisplay.format(selectedDate));

        // Динамически заполняем список старта для каждого профиля
        buildStartCycleOptions(startCyclesContainer);
    }

    private void buildStartCycleOptions(LinearLayout container) {
        container.removeAllViews();

        if (profileList == null || profileList.isEmpty()) {
            TextView emptyTv = new TextView(getContext());
            emptyTv.setText("Нет доступных профилей. Создайте их в меню.");
            emptyTv.setTextColor(Color.GRAY);
            emptyTv.setPadding(16, 16, 16, 16);
            container.addView(emptyTv);
            return;
        }

        for (ProfileModel profile : profileList) {
            TextView tvOption = new TextView(getContext());
            tvOption.setText("📅 Сделать стартом для: " + profile.getName());
            tvOption.setTextColor(Color.parseColor("#E0E0E0"));
            tvOption.setTextSize(15);
            tvOption.setPadding(16, 20, 16, 20);

            tvOption.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onSetStartCycle(profile, selectedDateStr);
                }
                dismiss();
            });

            container.addView(tvOption);
        }
    }
}

