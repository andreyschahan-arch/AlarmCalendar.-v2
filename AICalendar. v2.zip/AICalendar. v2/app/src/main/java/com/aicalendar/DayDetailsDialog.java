package com.aicalendar.v2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DayDetailsDialog extends Dialog {

    public interface OnStartCycleSelectListener {
        void onSetStartCycle(ProfileModel profile, String dateStr);
    }

    private final Date selectedDate;
    private final List<ProfileModel> profileList;
    private final OnStartCycleSelectListener listener;
    private boolean isSpoilerExpanded = false;

    public DayDetailsDialog(@NonNull Context context, Date selectedDate, List<ProfileModel> profileList, OnStartCycleSelectListener listener) {
        super(context);
        this.selectedDate = selectedDate;
        this.profileList = profileList;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_day_details);

        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        SimpleDateFormat titleSdf = new SimpleDateFormat("d MMMM yyyy", new Locale("ru"));
        SimpleDateFormat dbSdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        String formattedTitleDate = titleSdf.format(selectedDate);
        String formattedDbDate = dbSdf.format(selectedDate);

        TextView tvDialogDate = findViewById(R.id.tvDialogDate);
        tvDialogDate.setText(formattedTitleDate);

        LinearLayout containerAlarms = findViewById(R.id.containerAlarms);
        TextView btnEditCurrentProfile = findViewById(R.id.btnEditCurrentProfile);
        TextView btnToggleStartOptions = findViewById(R.id.btnToggleStartOptions);
        LinearLayout containerStartOptions = findViewById(R.id.containerStartOptions);

        ProfileModel activeProfile = findActiveProfileForDate(selectedDate);

        // 1. Отображение списка будильников (время + текст из ReminderModel)
        containerAlarms.removeAllViews();
        if (activeProfile != null && activeProfile.getReminders() != null && !activeProfile.getReminders().isEmpty()) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            for (ReminderModel reminder : activeProfile.getReminders()) {
                View alarmView = inflater.inflate(android.R.layout.simple_list_item_2, containerAlarms, false);

                TextView text1 = alarmView.findViewById(android.R.id.text1);
                TextView text2 = alarmView.findViewById(android.R.id.text2);

                String text = reminder.getText();
                String time = reminder.getTime();

                text1.setText(time + (text != null && !text.isEmpty() ? " — " + text : ""));
                text1.setTextColor(Color.WHITE);
                text1.setTextSize(18);

                if (text2 != null) {
                    text2.setVisibility(View.GONE);
                }

                SwitchCompat switchCompat = new SwitchCompat(getContext());
                switchCompat.setChecked(true); // Включатель по умолчанию

                LinearLayout rowLayout = new LinearLayout(getContext());
                rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                rowLayout.setPadding(0, 12, 0, 12);

                LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                rowLayout.addView(text1, textParams);
                rowLayout.addView(switchCompat);

                containerAlarms.addView(rowLayout);
            }
        } else {
            TextView tvEmpty = new TextView(getContext());
            tvEmpty.setText("Нет активных будильников");
            tvEmpty.setTextColor(Color.parseColor("#666666"));
            tvEmpty.setPadding(0, 8, 0, 8);
            containerAlarms.addView(tvEmpty);
        }

        // 2. Кнопка редактирования текущего профиля
        if (activeProfile != null) {
            btnEditCurrentProfile.setVisibility(View.VISIBLE);
            btnEditCurrentProfile.setText("✏️ Редактировать день (" + activeProfile.getName() + ")");
            btnEditCurrentProfile.setOnClickListener(v -> {
                dismiss();
                if (getContext() instanceof MainActivity) {
                    ((MainActivity) getContext()).showProfileEditDialog(activeProfile);
                }
            });
        } else {
            btnEditCurrentProfile.setVisibility(View.GONE);
        }

        // 3. Переключатель спойлера параметров старта
        btnToggleStartOptions.setOnClickListener(v -> {
            isSpoilerExpanded = !isSpoilerExpanded;
            if (isSpoilerExpanded) {
                btnToggleStartOptions.setText("⚙ Параметры старта циклов ▴");
                containerStartOptions.setVisibility(View.VISIBLE);
            } else {
                btnToggleStartOptions.setText("⚙ Параметры старта циклов ▾");
                containerStartOptions.setVisibility(View.GONE);
            }
        });

        // 4. Список кнопок с подлинным подтверждением
        containerStartOptions.removeAllViews();
        if (profileList != null) {
            for (ProfileModel profile : profileList) {
                TextView btnStart = new TextView(getContext());
                btnStart.setText("🗓 Сделать стартом для: " + profile.getName());
                btnStart.setTextColor(Color.parseColor("#64D2FF"));
                btnStart.setTextSize(16);
                btnStart.setPadding(0, 16, 0, 16);
                btnStart.setClickable(true);
                btnStart.setFocusable(true);

                btnStart.setOnClickListener(v -> {
                    new AlertDialog.Builder(getContext(), android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Подтверждение")
                        .setMessage("Установить дату " + formattedTitleDate + " как старт цикла для профиля \"" + profile.getName() + "\"?")
                        .setPositiveButton("Да", (dialog, which) -> {
						if (listener != null) {
							listener.onSetStartCycle(profile, formattedDbDate);
						}
						dismiss();
					})
					.setNegativeButton("Отмена", null)
                        .show();
                });

                containerStartOptions.addView(btnStart);
            }
        }
    }

    private ProfileModel findActiveProfileForDate(Date date) {
        if (profileList == null || date == null) return null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        for (ProfileModel profile : profileList) {
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;
            try {
                Calendar startCal = Calendar.getInstance();
                startCal.setTime(sdf.parse(profile.getStartDate()));

                Calendar dayCal = Calendar.getInstance();
                dayCal.setTime(date);

                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                dayCal.set(Calendar.HOUR_OF_DAY, 0);
                dayCal.set(Calendar.MINUTE, 0);
                dayCal.set(Calendar.SECOND, 0);
                dayCal.set(Calendar.MILLISECOND, 0);

                long diffInMillis = dayCal.getTimeInMillis() - startCal.getTimeInMillis();
                long diffInDays = diffInMillis / (24 * 60 * 60 * 1000);
                int repeat = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffInDays >= 0 && (diffInDays % repeat == 0)) {
                    return profile;
                }
            } catch (Exception ignored) {}
        }
        return null;
    }
}

