package com.aicalendar.v2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DayDetailsDialog extends Dialog {

    public interface OnStartCycleSelectListener {
        void onSetStartCycle(ProfileModel profile, String dateStr);
    }

    private final Date selectedDate;
    private final List<ProfileModel> profileList;
    private final OnStartCycleSelectListener listener;
    private boolean isSpoilerExpanded = false;

    public DayDetailsDialog(@NonNull Context context, Date selectedDate, List<ProfileModel> profileList, OnStartCycleSelectListener listener) {
        super(context);
        this.selectedDate = selectedDate;
        this.profileList = profileList;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_day_details);

        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        SimpleDateFormat titleSdf = new SimpleDateFormat("d MMMM yyyy", new Locale("ru"));
        SimpleDateFormat dbSdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        String formattedTitleDate = titleSdf.format(selectedDate);
        String formattedDbDate = dbSdf.format(selectedDate);

        TextView tvDialogDate = findViewById(R.id.tvDialogDate);
        if (tvDialogDate != null) {
            tvDialogDate.setText(formattedTitleDate);
        }

        LinearLayout containerAlarms = findViewById(R.id.containerAlarms);
        TextView btnEditCurrentProfile = findViewById(R.id.btnEditCurrentProfile);
        TextView btnToggleStartOptions = findViewById(R.id.btnToggleStartOptions);
        LinearLayout containerStartOptions = findViewById(R.id.containerStartOptions);

        ProfileModel activeProfile = findActiveProfileForDate(selectedDate);

        // 1. Отображение списка будильников (безопасное создание элементов)
        if (containerAlarms != null) {
            containerAlarms.removeAllViews();
            List<ReminderModel> reminders = (activeProfile != null) ? activeProfile.getReminders() : null;

            if (reminders != null && !reminders.isEmpty()) {
                for (ReminderModel reminder : reminders) {
                    LinearLayout rowLayout = new LinearLayout(getContext());
                    rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                    rowLayout.setPadding(0, 12, 0, 12);
                    rowLayout.setLayoutParams(new LinearLayout.LayoutParams(
												  LinearLayout.LayoutParams.MATCH_PARENT,
												  LinearLayout.LayoutParams.WRAP_CONTENT
											  ));

                    TextView tvAlarmInfo = new TextView(getContext());
                    String time = (reminder.getTime() != null) ? reminder.getTime() : "00:00";
                    String text = (reminder.getText() != null) ? reminder.getText() : "";
                    tvAlarmInfo.setText(time + (text.isEmpty() ? "" : " — " + text));
                    tvAlarmInfo.setTextColor(Color.WHITE);
                    tvAlarmInfo.setTextSize(18);

                    LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
						0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                    );
                    tvAlarmInfo.setLayoutParams(textParams);

                    SwitchCompat switchCompat = new SwitchCompat(getContext());
                    switchCompat.setChecked(true);

                    rowLayout.addView(tvAlarmInfo);
                    rowLayout.addView(switchCompat);
                    containerAlarms.addView(rowLayout);
                }
            } else {
                TextView tvEmpty = new TextView(getContext());
                tvEmpty.setText("Нет активных будильников");
                tvEmpty.setTextColor(Color.parseColor("#666666"));
                tvEmpty.setPadding(0, 8, 0, 8);
                containerAlarms.addView(tvEmpty);
            }
        }

		// 2. Кнопка редактирования текущего профиля
		// 2. Кнопка редактирования текущего профиля
        if (btnEditCurrentProfile != null) {
            if (activeProfile != null) {
                btnEditCurrentProfile.setVisibility(View.VISIBLE);
                btnEditCurrentProfile.setText("Редактировать профиль (" + activeProfile.getName() + ")");

                final ProfileModel profileToEdit = activeProfile;
                btnEditCurrentProfile.setOnClickListener(v -> {
                    dismiss();

                    // Безопасное получение MainActivity с учетом ContextThemeWrapper
                    Context context = getContext();
                    if (context instanceof androidx.appcompat.view.ContextThemeWrapper) {
                        context = ((androidx.appcompat.view.ContextThemeWrapper) context).getBaseContext();
                    }
                    if (context instanceof MainActivity) {
                        ((MainActivity) context).showProfileEditDialog(profileToEdit);
                    } else if (getOwnerActivity() instanceof MainActivity) {
                        ((MainActivity) getOwnerActivity()).showProfileEditDialog(profileToEdit);
                    }
                });
            } else {
                btnEditCurrentProfile.setVisibility(View.GONE);
            }
        }
		
		

        // 3. Переключатель спойлера параметров старта
        if (btnToggleStartOptions != null && containerStartOptions != null) {
            btnToggleStartOptions.setOnClickListener(v -> {
                isSpoilerExpanded = !isSpoilerExpanded;
                if (isSpoilerExpanded) {
                    btnToggleStartOptions.setText("⚙ Параметры старта циклов ▴");
                    containerStartOptions.setVisibility(View.VISIBLE);
                } else {
                    btnToggleStartOptions.setText("⚙ Параметры старта циклов ▾");
                    containerStartOptions.setVisibility(View.GONE);
                }
            });

            // 4. Заполнение кнопок стартов профилей внутри спойлера
            containerStartOptions.removeAllViews();
            if (profileList != null) {
                for (ProfileModel profile : profileList) {
                    TextView btnStart = new TextView(getContext());
                    btnStart.setText("🗓 Сделать стартом для: " + profile.getName());
                    btnStart.setTextColor(Color.parseColor("#64D2FF"));
                    btnStart.setTextSize(16);
                    btnStart.setPadding(0, 16, 0, 16);
                    btnStart.setClickable(true);
                    btnStart.setFocusable(true);

                    btnStart.setOnClickListener(v -> {
                        new AlertDialog.Builder(getContext(), android.R.style.Theme_DeviceDefault_Dialog_Alert)
                            .setTitle("Подтверждение")
                            .setMessage("Установить дату " + formattedTitleDate + " как старт цикла для профиля \"" + profile.getName() + "\"?")
                            .setPositiveButton("Да", (dialog, which) -> {
							if (listener != null) {
								listener.onSetStartCycle(profile, formattedDbDate);
							}
							dismiss();
						})
						.setNegativeButton("Отмена", null)
                            .show();
                    });

                    containerStartOptions.addView(btnStart);
                }
            }
        }
    }

    private ProfileModel findActiveProfileForDate(Date date) {
        if (profileList == null || date == null) return null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        for (ProfileModel profile : profileList) {
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;
            try {
                Calendar startCal = Calendar.getInstance();
                startCal.setTime(sdf.parse(profile.getStartDate()));

                Calendar dayCal = Calendar.getInstance();
                dayCal.setTime(date);

                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                dayCal.set(Calendar.HOUR_OF_DAY, 0);
                dayCal.set(Calendar.MINUTE, 0);
                dayCal.set(Calendar.SECOND, 0);
                dayCal.set(Calendar.MILLISECOND, 0);

                long diffInMillis = dayCal.getTimeInMillis() - startCal.getTimeInMillis();
                long diffInDays = diffInMillis / (24 * 60 * 60 * 1000);
                int repeat = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffInDays >= 0 && (diffInDays % repeat == 0)) {
                    return profile;
                }
            } catch (Exception ignored) {}
        }
        return null;
    }
}

