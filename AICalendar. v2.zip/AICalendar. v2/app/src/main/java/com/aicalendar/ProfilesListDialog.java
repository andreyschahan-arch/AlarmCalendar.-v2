package com.aicalendar.v2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class ProfilesListDialog extends Dialog {

    public interface OnProfileListActionListener {
        void onCreateNewProfile();
        void onEditProfile(ProfileModel profile);
        void onDeleteProfile(ProfileModel profile);
        void onSelectProfile(ProfileModel profile);
    }

    private List<ProfileModel> profiles;
    private OnProfileListActionListener listener;
    private LinearLayout containerProfilesList;

    public ProfilesListDialog(@NonNull Context context, List<ProfileModel> profiles, OnProfileListActionListener listener) {
        super(context);
        this.profiles = profiles;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_profiles_list);

        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        containerProfilesList = findViewById(R.id.containerProfilesList);
        Button btnAddNewProfile = findViewById(R.id.btnAddNewProfile);
        Button btnCloseProfilesList = findViewById(R.id.btnCloseProfilesList);

        renderProfiles();

        btnAddNewProfile.setOnClickListener(v -> {
            dismiss();
            if (listener != null) {
                listener.onCreateNewProfile();
            }
        });

        btnCloseProfilesList.setOnClickListener(v -> dismiss());
    }

    public void updateProfiles(List<ProfileModel> newProfiles) {
        this.profiles = newProfiles;
        renderProfiles();
    }

    private void renderProfiles() {
        if (containerProfilesList == null) return;
        containerProfilesList.removeAllViews();

        if (profiles == null || profiles.isEmpty()) {
            TextView emptyTv = new TextView(getContext());
            emptyTv.setText("У вас пока нет сохраненных типов дней");
            emptyTv.setTextColor(Color.GRAY);
            emptyTv.setPadding(0, 20, 0, 20);
            emptyTv.setGravity(android.view.Gravity.CENTER);
            containerProfilesList.addView(emptyTv);
            return;
        }

        LayoutInflater inflater = LayoutInflater.from(getContext());

        for (ProfileModel profile : profiles) {
            View itemView = inflater.inflate(R.layout.item_profile_list, containerProfilesList, false);

            View vColor = itemView.findViewById(R.id.vProfileColor);
            TextView tvName = itemView.findViewById(R.id.tvProfileName);
            TextView tvRepeat = itemView.findViewById(R.id.tvProfileRepeat);
            TextView btnEdit = itemView.findViewById(R.id.btnEditProfile);
            TextView btnDelete = itemView.findViewById(R.id.btnDeleteProfile);

            // Круглый индикатор цвета
            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            try {
                drawable.setColor(Color.parseColor(profile.getColor()));
            } catch (Exception e) {
                drawable.setColor(Color.BLUE);
            }
            vColor.setBackground(drawable);

            tvName.setText(profile.getName());
            tvRepeat.setText("Повтор каждые " + profile.getRepeatDays() + " дн.");

            // Нажатие на весь элемент — выбор профиля
            itemView.setOnClickListener(v -> {
                dismiss();
                if (listener != null) {
                    listener.onSelectProfile(profile);
                }
            });

            // Нажатие на карандаш — редактирование
            btnEdit.setOnClickListener(v -> {
                dismiss();
                if (listener != null) {
                    listener.onEditProfile(profile);
                }
            });

            // Нажатие на корзину — удаление
            btnDelete.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeleteProfile(profile);
                }
            });

            containerProfilesList.addView(itemView);
        }
    }
}

