package com.aicalendar.v2;

import android.content.Context;
import android.content.SharedPreferences;

public class WidgetStorage {

    private static final String PREF_NAME = "widget_settings";

    // Ключи по appWidgetId
    private static String keyBgIndex(int widgetId) { return "widget_" + widgetId + "_bg_index"; }
    private static String keyAlpha(int widgetId) { return "widget_" + widgetId + "_alpha"; }
    private static String keyTextColor(int widgetId) { return "widget_" + widgetId + "_text_color"; }

    // Значения по умолчанию
    // BG_NONE = -1 → фон берётся из XML (widget_layout.xml), а не из градиентов
    public static final int BG_NONE = -1;
    public static final int DEFAULT_BG_INDEX = BG_NONE;
    public static final int DEFAULT_ALPHA = 255;   // 0..255
    public static final int TEXT_COLOR_WHITE = 0;
    public static final int TEXT_COLOR_BLACK = 1;

    public static int getBgIndex(Context context, int widgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(keyBgIndex(widgetId), DEFAULT_BG_INDEX);
    }

    public static int getAlpha(Context context, int widgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(keyAlpha(widgetId), DEFAULT_ALPHA);
    }

    public static int getTextColor(Context context, int widgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(keyTextColor(widgetId), TEXT_COLOR_WHITE);
    }

    public static void saveBgIndex(Context context, int widgetId, int index) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(keyBgIndex(widgetId), index).apply();
    }

    public static void saveAlpha(Context context, int widgetId, int alpha) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(keyAlpha(widgetId), alpha).apply();
    }

    public static void saveTextColor(Context context, int widgetId, int colorMode) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(keyTextColor(widgetId), colorMode).apply();
    }

    // Массив drawable-фонов, в том же порядке, что widget_bg_1..12
    public static int getBgDrawableRes(int index) {
        switch (index) {
            case 0: return R.drawable.widget_bg_1;
            case 1: return R.drawable.widget_bg_2;
            case 2: return R.drawable.widget_bg_3;
            case 3: return R.drawable.widget_bg_4;
            case 4: return R.drawable.widget_bg_5;
            case 5: return R.drawable.widget_bg_6;
            case 6: return R.drawable.widget_bg_7;
            case 7: return R.drawable.widget_bg_8;
            case 8: return R.drawable.widget_bg_9;
            case 9: return R.drawable.widget_bg_10;
            case 10: return R.drawable.widget_bg_11;
            case 11: return R.drawable.widget_bg_12;
            default: return 0; // BG_NONE или неизвестный индекс — фона нет
        }
    }
}
