package com.aicalendar;

import java.util.ArrayList;
import java.util.List;

public class ProfileModel {
    private String id;
    private String name;
    private String color;
    private List<ReminderModel> reminders;

    public ProfileModel() {
        this.reminders = new ArrayList<>();
    }

    public ProfileModel(String id, String name, String color, List<ReminderModel> reminders) {
        this.id = id;
        this.name = name;
        this.color = color;
        this.reminders = (reminders != null) ? reminders : new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public List<ReminderModel> getReminders() {
        if (reminders == null) {
            reminders = new ArrayList<>();
        }
        return reminders;
    }

    public void setReminders(List<ReminderModel> reminders) {
        this.reminders = reminders;
    }
}

