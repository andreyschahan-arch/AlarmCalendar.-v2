package com.aicalendar.v2;

import java.io.Serializable;

public class ProfileModel implements Serializable {
    private String id;
    private String name;        // Название, которое вы введёте сами
    private String color;       // Цвет профиля в HEX (например, #FF5722)
    private boolean alarmEnabled;
    private int alarmHour;
    private int alarmMinute;

    public ProfileModel(String id, String name, String color, boolean alarmEnabled, int alarmHour, int alarmMinute) {
        this.id = id;
        this.name = name;
        this.color = color;
        this.alarmEnabled = alarmEnabled;
        this.alarmHour = alarmHour;
        this.alarmMinute = alarmMinute;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public boolean isAlarmEnabled() { return alarmEnabled; }
    public void setAlarmEnabled(boolean alarmEnabled) { this.alarmEnabled = alarmEnabled; }

    public int getAlarmHour() { return alarmHour; }
    public void setAlarmHour(int alarmHour) { this.alarmHour = alarmHour; }

    public int getAlarmMinute() { return alarmMinute; }
    public void setAlarmMinute(int alarmMinute) { this.alarmMinute = alarmMinute; }
}

