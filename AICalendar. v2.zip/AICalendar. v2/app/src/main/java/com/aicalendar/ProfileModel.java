package com.aicalendar.v2;

import java.util.ArrayList;
import java.util.List;

public class ProfileModel {
    private String id;
    private String name;
    private int repeatDays; // Повторять каждые N дней
    private String color;
    private List<ReminderModel> reminders;
    private String startDate; // Дата старта в формате "yyyy-MM-dd" (например, "2026-09-01")

    public ProfileModel() {
        this.repeatDays = 1;
        this.reminders = new ArrayList<>();
        this.startDate = "";
    }

    public ProfileModel(String id, String name, int repeatDays, String color, List<ReminderModel> reminders) {
        this.id = id;
        this.name = name;
        this.repeatDays = repeatDays;
        this.color = color;
        this.reminders = (reminders != null) ? reminders : new ArrayList<>();
        this.startDate = "";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRepeatDays() {
        return repeatDays;
    }

    public void setRepeatDays(int repeatDays) {
        this.repeatDays = repeatDays;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public List<ReminderModel> getReminders() {
        if (reminders == null) {
            reminders = new ArrayList<>();
        }
        return reminders;
    }

    public void setReminders(List<ReminderModel> reminders) {
        this.reminders = reminders;
    }

    // --- Добавленные методы для работы с датой старта ---

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
}

