package com.aicalendar.v2;

import java.util.ArrayList;
import java.util.List;

public class ProfileModel {
    private String id;
    private String name;
    private int repeatDays; // Повторять каждые N дней
    private String color;
    private List<ReminderModel> reminders;

    public ProfileModel() {
        this.repeatDays = 1;
        this.reminders = new ArrayList<>();
    }

    public ProfileModel(String id, String name, int repeatDays, String color, List<ReminderModel> reminders) {
        this.id = id;
        this.name = name;
        this.repeatDays = repeatDays;
        this.color = color;
        this.reminders = (reminders != null) ? reminders : new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRepeatDays() {
        return repeatDays;
    }

    public void setRepeatDays(int repeatDays) {
        this.repeatDays = repeatDays;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public List<ReminderModel> getReminders() {
        if (reminders == null) {
            reminders = new ArrayList<>();
        }
        return reminders;
    }

    public void setReminders(List<ReminderModel> reminders) {
        this.reminders = reminders;
    }
}

