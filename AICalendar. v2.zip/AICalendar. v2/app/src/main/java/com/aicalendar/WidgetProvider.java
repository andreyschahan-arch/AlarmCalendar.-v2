package com.aicalendar.v2;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private void updateWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        // ===== 1. Дата =====
        views.setTextViewText(R.id.widgetDate, formatToday());

        // ===== 2. Активный профиль =====
        ProfileModel activeProfile = findActiveProfileForToday(context);

        if (activeProfile == null) {
            views.setTextViewText(R.id.widgetProfileName, "Не задан");
            views.setTextColor(R.id.widgetProfileName, 0xFF888888);
            views.setTextViewText(R.id.widgetReminderText, "");
            views.setTextViewText(R.id.widgetReminderTime, "");
            appWidgetManager.updateAppWidget(appWidgetId, views);
            return;
        }

        views.setTextViewText(R.id.widgetProfileName, activeProfile.getName());
        views.setTextColor(R.id.widgetProfileName, 0xFFFFFFFF);

        // ===== 3. Ближайшее напоминание =====
        ReminderModel nearest = findNearestReminder(activeProfile);

        if (nearest == null) {
            // Все напоминания прошли
            views.setTextViewText(R.id.widgetReminderText, "");
            views.setTextViewText(R.id.widgetReminderTime, "Всё выполнено ✓");
            views.setTextColor(R.id.widgetReminderTime, 0xFF64D2FF);
        } else {
            views.setTextViewText(R.id.widgetReminderText, nearest.getText() != null ? nearest.getText() : "");
            views.setTextColor(R.id.widgetReminderText, 0xFFFFFFFF);

            String countdown = formatCountdown(nearest.getTime());
            views.setTextViewText(R.id.widgetReminderTime, countdown);
            views.setTextColor(R.id.widgetReminderTime, 0xFFFF9500);
        }

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    // ===== "Сегодня, 11 октября" =====
    private String formatToday() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("d MMMM", new Locale("ru"));
        return "Сегодня, " + sdf.format(cal.getTime());
    }

    // ===== Поиск активного профиля на сегодня =====
    private ProfileModel findActiveProfileForToday(Context context) {
        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
        if (profiles == null || profiles.isEmpty()) return null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        Calendar todayCal = Calendar.getInstance();
        todayCal.set(Calendar.HOUR_OF_DAY, 0);
        todayCal.set(Calendar.MINUTE, 0);
        todayCal.set(Calendar.SECOND, 0);
        todayCal.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profiles) {
            if (profile == null) continue;
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;

            try {
                Date startDate = sdf.parse(profile.getStartDate());
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffDays = (todayCal.getTimeInMillis() - startCal.getTimeInMillis())
					/ (24 * 60 * 60 * 1000);

                int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffDays >= 0 && (diffDays % repeatDays == 0)) {
                    return profile;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    // ===== Поиск ближайшего напоминания в профиле =====
    private ReminderModel findNearestReminder(ProfileModel profile) {
        if (profile == null || profile.getReminders() == null || profile.getReminders().isEmpty()) {
            return null;
        }

        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);

        ReminderModel nearest = null;
        int nearestMinutes = Integer.MAX_VALUE;

        for (ReminderModel reminder : profile.getReminders()) {
            if (reminder == null || reminder.getTime() == null) continue;

            String[] parts = reminder.getTime().split(":");
            if (parts.length < 2) continue;

            int h, m;
            try {
                h = Integer.parseInt(parts[0]);
                m = Integer.parseInt(parts[1]);
            } catch (Exception e) {
                continue;
            }

            int reminderMinutes = h * 60 + m;
            if (reminderMinutes > nowMinutes && reminderMinutes < nearestMinutes) {
                nearestMinutes = reminderMinutes;
                nearest = reminder;
            }
        }
        return nearest;
    }

    // ===== Обратный отсчёт =====
    private String formatCountdown(String time) {
        if (time == null) return "";
        String[] parts = time.split(":");
        if (parts.length < 2) return "";

        int h, m;
        try {
            h = Integer.parseInt(parts[0]);
            m = Integer.parseInt(parts[1]);
        } catch (Exception e) {
            return "";
        }

        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int targetMinutes = h * 60 + m;
        int diff = targetMinutes - nowMinutes;

        if (diff <= 0) return "";

        int hours = diff / 60;
        int minutes = diff % 60;

        if (hours > 0) {
            return "через " + hours + "ч " + minutes + "м";
        } else {
            return "через " + minutes + "м";
        }
    }
}
