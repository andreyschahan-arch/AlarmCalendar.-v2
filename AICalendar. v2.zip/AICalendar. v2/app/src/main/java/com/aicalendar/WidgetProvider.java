package com.aicalendar.v2;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private void updateWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        // 1. Дата сверху
        String dateText = formatToday(context);
        views.setTextViewText(R.id.widgetDate, dateText);

        // 2. Активный профиль на сегодня
        ProfileModel activeProfile = findActiveProfileForToday(context);

        if (activeProfile != null) {
            views.setTextViewText(R.id.widgetProfileName, activeProfile.getName());
            views.setTextColor(R.id.widgetProfileName, 0xFFFFFFFF); // белый
        } else {
            views.setTextViewText(R.id.widgetProfileName, "Не задан");
            views.setTextColor(R.id.widgetProfileName, 0xFF888888); // серый
        }

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    // "Сегодня, 11 октября"
    private String formatToday(Context context) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("d MMMM", new Locale("ru"));
        String datePart = sdf.format(cal.getTime());
        return "Сегодня, " + datePart;
    }

    // Поиск активного профиля на сегодня
    private ProfileModel findActiveProfileForToday(Context context) {
        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
        if (profiles == null || profiles.isEmpty()) return null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        Calendar todayCal = Calendar.getInstance();
        todayCal.set(Calendar.HOUR_OF_DAY, 0);
        todayCal.set(Calendar.MINUTE, 0);
        todayCal.set(Calendar.SECOND, 0);
        todayCal.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profiles) {
            if (profile == null) continue;
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;

            try {
                Date startDate = sdf.parse(profile.getStartDate());
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffDays = (todayCal.getTimeInMillis() - startCal.getTimeInMillis())
					/ (24 * 60 * 60 * 1000);

                int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffDays >= 0 && (diffDays % repeatDays == 0)) {
                    return profile;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
