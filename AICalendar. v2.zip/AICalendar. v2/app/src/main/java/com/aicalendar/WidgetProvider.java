package com.aicalendar.v2;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WidgetProvider extends AppWidgetProvider {

    private static final String[] PROFILE_COLORS = {
        "#FF5252", "#FF4081", "#E040FB", "#7C4DFF",
        "#536DFE", "#448AFF", "#1DE9B6", "#00E676",
        "#76FF03", "#FFEA00", "#FF9100", "#FF3D00"
    };

    private static final int[] DAY_BORDER_RES = {
        R.drawable.day_border_1,
        R.drawable.day_border_2,
        R.drawable.day_border_3,
        R.drawable.day_border_4,
        R.drawable.day_border_5,
        R.drawable.day_border_6,
        R.drawable.day_border_7,
        R.drawable.day_border_8,
        R.drawable.day_border_9,
        R.drawable.day_border_10,
        R.drawable.day_border_11,
        R.drawable.day_border_12
    };

    public static final String ACTION_SETTINGS_CLICK = "com.aicalendar.v2.ACTION_SETTINGS_CLICK";

    public static void refreshAll(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName widget = new ComponentName(context, WidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(widget);

            if (ids == null || ids.length == 0) return;

            Intent intent = new Intent(context, WidgetProvider.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            context.sendBroadcast(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
    }

	private void updateWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

		// ===== Фон виджета (отдельный слой, чтобы alpha не гасила контент) =====
        int bgIndex = WidgetStorage.getBgIndex(context, appWidgetId);
        int bgRes = WidgetStorage.getBgDrawableRes(bgIndex);
        views.setInt(R.id.widgetBackground, "setBackgroundResource", bgRes);

        // Прозрачность — всегда на фон, независимо от того, BG_NONE или градиент
        int alpha = WidgetStorage.getAlpha(context, appWidgetId);
        float alphaFloat = Math.max(0f, Math.min(1f, alpha / 255f));
        views.setFloat(R.id.widgetBackground, "setAlpha", alphaFloat);

        // ===== Цвета текста =====
        int textColor;
        if (WidgetStorage.getTextColor(context, appWidgetId) == WidgetStorage.TEXT_COLOR_BLACK) {
            textColor = 0xFF000000;
        } else {
            textColor = 0xFFFFFFFF;
        }
		
		views.setTextColor(R.id.widgetDateLabel, textColor);

        // ===== Активный профиль =====
        ProfileModel activeProfile = findActiveProfileForToday(context);

        if (activeProfile == null) {
			views.setTextViewText(R.id.widgetProfileName, "не задан");
            views.setTextColor(R.id.widgetProfileName, textColor);
            views.setTextViewText(R.id.widgetReminderText, "");
            views.setTextViewText(R.id.widgetReminderTime, "");
        } else {
			views.setTextViewText(R.id.widgetProfileName, activeProfile.getName());
            views.setTextColor(R.id.widgetProfileName, textColor);

            ReminderModel nearest = findNearestReminder(activeProfile);

            if (nearest == null) {
                boolean hasReminders = activeProfile.getReminders() != null
					&& !activeProfile.getReminders().isEmpty();

                if (hasReminders) {
                    views.setTextViewText(R.id.widgetReminderText, "");
                    views.setTextViewText(R.id.widgetReminderTime, "Всё выполнено ✓");
                    views.setTextColor(R.id.widgetReminderTime, textColor);
                } else {
                    views.setTextViewText(R.id.widgetReminderText, "");
                    views.setTextViewText(R.id.widgetReminderTime, "");
                }
            } else {
                views.setTextViewText(R.id.widgetReminderText,
									  nearest.getText() != null ? nearest.getText() : "");
                views.setTextColor(R.id.widgetReminderText, textColor);

                views.setTextViewText(R.id.widgetReminderTime, formatCountdown(nearest.getTime()));
                views.setTextColor(R.id.widgetReminderTime, textColor);
            }
        }

        // ===== Кубики =====
        buildDaysRow(context, views, textColor);

        // ===== Тап по виджету — открывает приложение =====
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            : PendingIntent.FLAG_UPDATE_CURRENT;

        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, openApp, flags);
        views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent);

        // ===== Тап по "=" — открывает настройки виджета =====
        Intent settingsIntent = new Intent(context, WidgetProvider.class);
        settingsIntent.setAction(ACTION_SETTINGS_CLICK);
        settingsIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);

        PendingIntent settingsPending = PendingIntent.getBroadcast(
            context, appWidgetId + 10_000, settingsIntent, flags
        );
        views.setOnClickPendingIntent(R.id.widgetSettingsBtn, settingsPending);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

	@Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if (intent != null && ACTION_SETTINGS_CLICK.equals(intent.getAction())) {
            int widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
											  AppWidgetManager.INVALID_APPWIDGET_ID);
            if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;

			Intent openSettings = new Intent(context, WidgetSettingsActivity.class);
            openSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            openSettings.putExtra("WIDGET_ID", widgetId);
            context.startActivity(openSettings);
        }
    }

	private void buildDaysRow(Context context, RemoteViews views, int textColor) {
        views.removeAllViews(R.id.widgetDaysRow);

        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);

        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        for (int offset = -2; offset <= 2; offset++) {
            Calendar dayCal = (Calendar) today.clone();
            dayCal.add(Calendar.DAY_OF_YEAR, offset);

			int cellLayout = (offset == 0)
                ? R.layout.widget_day_cell_today
                : R.layout.widget_day_cell;
            RemoteViews cell = new RemoteViews(context.getPackageName(), cellLayout);
			
            int dayOfMonth = dayCal.get(Calendar.DAY_OF_MONTH);
            cell.setTextViewText(R.id.dayCellNumber, String.valueOf(dayOfMonth));

            SimpleDateFormat wdSdf = new SimpleDateFormat("EE", new Locale("ru"));
            String wd = wdSdf.format(dayCal.getTime());
            if (wd.length() > 0) {
                wd = wd.substring(0, 1).toUpperCase() + wd.substring(1).toLowerCase();
            }
            wd = wd.replace(".", "");
            cell.setTextViewText(R.id.dayCellWeekday, wd);

            // Единый цвет текста
            cell.setTextColor(R.id.dayCellNumber, textColor);
            cell.setTextColor(R.id.dayCellWeekday, textColor);

            Integer borderRes = findBorderForDay(profiles, dayCal);
            if (borderRes != null) {
                cell.setInt(R.id.dayCellRoot, "setBackgroundResource", borderRes);
            } else {
                cell.setInt(R.id.dayCellRoot, "setBackgroundResource", R.drawable.day_border_default);
            }

            views.addView(R.id.widgetDaysRow, cell);
        }
    }

    private Integer findBorderForDay(List<ProfileModel> profiles, Calendar dayCal) {
        if (profiles == null || profiles.isEmpty()) return null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        Calendar dayMidnight = (Calendar) dayCal.clone();
        dayMidnight.set(Calendar.HOUR_OF_DAY, 0);
        dayMidnight.set(Calendar.MINUTE, 0);
        dayMidnight.set(Calendar.SECOND, 0);
        dayMidnight.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profiles) {
            if (profile == null) continue;
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;

            try {
                Date startDate = sdf.parse(profile.getStartDate());
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffDays = (dayMidnight.getTimeInMillis() - startCal.getTimeInMillis())
					/ (24 * 60 * 60 * 1000);

                int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffDays >= 0 && (diffDays % repeatDays == 0)) {
                    String profileColor = profile.getColor();
                    if (profileColor == null) return R.drawable.day_border_default;

                    int index = colorIndex(profileColor);
                    if (index < 0) return R.drawable.day_border_default;

                    return DAY_BORDER_RES[index];
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private int colorIndex(String hexColor) {
        if (hexColor == null) return -1;
        String normalized = hexColor.trim().toUpperCase(Locale.US);
        for (int i = 0; i < PROFILE_COLORS.length; i++) {
            if (PROFILE_COLORS[i].equalsIgnoreCase(normalized)) {
                return i;
            }
        }
        return -1;
    }


    private ProfileModel findActiveProfileForToday(Context context) {
        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
        if (profiles == null || profiles.isEmpty()) return null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        Calendar todayCal = Calendar.getInstance();
        todayCal.set(Calendar.HOUR_OF_DAY, 0);
        todayCal.set(Calendar.MINUTE, 0);
        todayCal.set(Calendar.SECOND, 0);
        todayCal.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profiles) {
            if (profile == null) continue;
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;

            try {
                Date startDate = sdf.parse(profile.getStartDate());
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffDays = (todayCal.getTimeInMillis() - startCal.getTimeInMillis())
					/ (24 * 60 * 60 * 1000);

                int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffDays >= 0 && (diffDays % repeatDays == 0)) {
                    return profile;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private ReminderModel findNearestReminder(ProfileModel profile) {
        if (profile == null || profile.getReminders() == null || profile.getReminders().isEmpty()) {
            return null;
        }

        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);

        ReminderModel nearest = null;
        int nearestMinutes = Integer.MAX_VALUE;

        for (ReminderModel reminder : profile.getReminders()) {
            if (reminder == null || reminder.getTime() == null) continue;

            String[] parts = reminder.getTime().split(":");
            if (parts.length < 2) continue;

            int h, m;
            try {
                h = Integer.parseInt(parts[0]);
                m = Integer.parseInt(parts[1]);
            } catch (Exception e) {
                continue;
            }

            int reminderMinutes = h * 60 + m;
            if (reminderMinutes > nowMinutes && reminderMinutes < nearestMinutes) {
                nearestMinutes = reminderMinutes;
                nearest = reminder;
            }
        }
        return nearest;
    }

    private String formatCountdown(String time) {
        if (time == null) return "";
        String[] parts = time.split(":");
        if (parts.length < 2) return "";

        int h, m;
        try {
            h = Integer.parseInt(parts[0]);
            m = Integer.parseInt(parts[1]);
        } catch (Exception e) {
            return "";
        }

        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int targetMinutes = h * 60 + m;
        int diff = targetMinutes - nowMinutes;

        if (diff <= 0) return "";

        int hours = diff / 60;
        int minutes = diff % 60;

        if (hours > 0) {
            return "через " + hours + "ч " + minutes + "м";
        } else {
            return "через " + minutes + "м";
        }
    }
}
