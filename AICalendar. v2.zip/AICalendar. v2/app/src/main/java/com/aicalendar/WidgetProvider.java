package com.aicalendar.v2;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.view.View;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WidgetProvider extends AppWidgetProvider {

    // Палитра цветов профилей — в том же порядке, что в ProfileDialog
    private static final String[] PROFILE_COLORS = {
        "#FF5252", "#FF4081", "#E040FB", "#7C4DFF",
        "#536DFE", "#448AFF", "#1DE9B6", "#00E676",
        "#76FF03", "#FFEA00", "#FF9100", "#FF3D00"
    };

    // ID drawable-рамок для каждого цвета
    private static final int[] DAY_BORDER_RES = {
        R.drawable.day_border_1,
        R.drawable.day_border_2,
        R.drawable.day_border_3,
        R.drawable.day_border_4,
        R.drawable.day_border_5,
        R.drawable.day_border_6,
        R.drawable.day_border_7,
        R.drawable.day_border_8,
        R.drawable.day_border_9,
        R.drawable.day_border_10,
        R.drawable.day_border_11,
        R.drawable.day_border_12
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private void updateWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        // ===== 1. Дата =====
        views.setTextViewText(R.id.widgetDate, formatToday());

        // ===== 2. Активный профиль =====
        ProfileModel activeProfile = findActiveProfileForToday(context);

        if (activeProfile == null) {
            views.setTextViewText(R.id.widgetProfileName, "Не задан");
            views.setTextColor(R.id.widgetProfileName, 0xFF888888);
            views.setTextViewText(R.id.widgetReminderText, "");
            views.setTextViewText(R.id.widgetReminderTime, "");
        } else {
            views.setTextViewText(R.id.widgetProfileName, activeProfile.getName());
            views.setTextColor(R.id.widgetProfileName, 0xFFFFFFFF);

            // ===== 3. Ближайшее напоминание =====
            ReminderModel nearest = findNearestReminder(activeProfile);

            if (nearest == null) {
                boolean hasReminders = activeProfile.getReminders() != null
					&& !activeProfile.getReminders().isEmpty();

                if (hasReminders) {
                    views.setTextViewText(R.id.widgetReminderText, "");
                    views.setTextViewText(R.id.widgetReminderTime, "Всё выполнено ✓");
                    views.setTextColor(R.id.widgetReminderTime, 0xFF64D2FF);
                } else {
                    views.setTextViewText(R.id.widgetReminderText, "");
                    views.setTextViewText(R.id.widgetReminderTime, "");
                }
            } else {
                views.setTextViewText(R.id.widgetReminderText,
									  nearest.getText() != null ? nearest.getText() : "");
                views.setTextColor(R.id.widgetReminderText, 0xFFFFFFFF);

                views.setTextViewText(R.id.widgetReminderTime, formatCountdown(nearest.getTime()));
                views.setTextColor(R.id.widgetReminderTime, 0xFFFF9500);
            }
        }

        // ===== 4. Кубики дней =====
        buildDaysRow(context, views);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    // ===== Кубики дней: -2, -1, сегодня, +1, +2 =====
    private void buildDaysRow(Context context, RemoteViews views) {
        views.removeAllViews(R.id.widgetDaysRow);

        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);

        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        for (int offset = -2; offset <= 2; offset++) {
            Calendar dayCal = (Calendar) today.clone();
            dayCal.add(Calendar.DAY_OF_YEAR, offset);

            RemoteViews cell = new RemoteViews(context.getPackageName(), R.layout.widget_day_cell);

            // Номер дня и день недели
            int dayOfMonth = dayCal.get(Calendar.DAY_OF_MONTH);
            cell.setTextViewText(R.id.dayCellNumber, String.valueOf(dayOfMonth));

            SimpleDateFormat wdSdf = new SimpleDateFormat("EE", new Locale("ru"));
            String wd = wdSdf.format(dayCal.getTime());
            if (wd.length() > 0) {
                wd = wd.substring(0, 1).toUpperCase() + wd.substring(1).toLowerCase();
            }
            // Убираем точку на конце (бывает у некоторых локалей)
            wd = wd.replace(".", "");
            cell.setTextViewText(R.id.dayCellWeekday, wd);

            // «Сегодня» — цвет числа белый, остальные — тоже белые
            cell.setTextColor(R.id.dayCellNumber, 0xFFFFFFFF);

            // Рамка по цвету активного профиля
            Integer borderRes = findBorderForDay(profiles, dayCal);
            if (borderRes != null) {
                cell.setInt(R.id.dayCellRoot, "setBackgroundResource", borderRes);
            } else {
                cell.setInt(R.id.dayCellRoot, "setBackgroundResource", R.drawable.day_border_default);
            }

            views.addView(R.id.widgetDaysRow, cell);
        }
    }

    // ===== Поиск цвета рамки для конкретного дня =====
    private Integer findBorderForDay(List<ProfileModel> profiles, Calendar dayCal) {
        if (profiles == null || profiles.isEmpty()) return null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        Calendar dayMidnight = (Calendar) dayCal.clone();
        dayMidnight.set(Calendar.HOUR_OF_DAY, 0);
        dayMidnight.set(Calendar.MINUTE, 0);
        dayMidnight.set(Calendar.SECOND, 0);
        dayMidnight.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profiles) {
            if (profile == null) continue;
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;

            try {
                Date startDate = sdf.parse(profile.getStartDate());
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffDays = (dayMidnight.getTimeInMillis() - startCal.getTimeInMillis())
					/ (24 * 60 * 60 * 1000);

                int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffDays >= 0 && (diffDays % repeatDays == 0)) {
                    String profileColor = profile.getColor();
                    if (profileColor == null) return R.drawable.day_border_default;

                    int index = colorIndex(profileColor);
                    if (index < 0) return R.drawable.day_border_default;

                    return DAY_BORDER_RES[index];
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    // ===== Индекс цвета в палитре =====
    private int colorIndex(String hexColor) {
        if (hexColor == null) return -1;
        String normalized = hexColor.trim().toUpperCase(Locale.US);
        for (int i = 0; i < PROFILE_COLORS.length; i++) {
            if (PROFILE_COLORS[i].equalsIgnoreCase(normalized)) {
                return i;
            }
        }
        return -1;
    }

    // ===== "Сегодня, 11 октября" =====
    private String formatToday() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("d MMMM", new Locale("ru"));
        return "Сегодня, " + sdf.format(cal.getTime());
    }

    // ===== Поиск активного профиля на сегодня =====
    private ProfileModel findActiveProfileForToday(Context context) {
        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
        if (profiles == null || profiles.isEmpty()) return null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        Calendar todayCal = Calendar.getInstance();
        todayCal.set(Calendar.HOUR_OF_DAY, 0);
        todayCal.set(Calendar.MINUTE, 0);
        todayCal.set(Calendar.SECOND, 0);
        todayCal.set(Calendar.MILLISECOND, 0);

        for (ProfileModel profile : profiles) {
            if (profile == null) continue;
            if (profile.getStartDate() == null || profile.getStartDate().isEmpty()) continue;

            try {
                Date startDate = sdf.parse(profile.getStartDate());
                if (startDate == null) continue;

                Calendar startCal = Calendar.getInstance();
                startCal.setTime(startDate);
                startCal.set(Calendar.HOUR_OF_DAY, 0);
                startCal.set(Calendar.MINUTE, 0);
                startCal.set(Calendar.SECOND, 0);
                startCal.set(Calendar.MILLISECOND, 0);

                long diffDays = (todayCal.getTimeInMillis() - startCal.getTimeInMillis())
					/ (24 * 60 * 60 * 1000);

                int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;

                if (diffDays >= 0 && (diffDays % repeatDays == 0)) {
                    return profile;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    // ===== Поиск ближайшего напоминания =====
    private ReminderModel findNearestReminder(ProfileModel profile) {
        if (profile == null || profile.getReminders() == null || profile.getReminders().isEmpty()) {
            return null;
        }

        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);

        ReminderModel nearest = null;
        int nearestMinutes = Integer.MAX_VALUE;

        for (ReminderModel reminder : profile.getReminders()) {
            if (reminder == null || reminder.getTime() == null) continue;

            String[] parts = reminder.getTime().split(":");
            if (parts.length < 2) continue;

            int h, m;
            try {
                h = Integer.parseInt(parts[0]);
                m = Integer.parseInt(parts[1]);
            } catch (Exception e) {
                continue;
            }

            int reminderMinutes = h * 60 + m;
            if (reminderMinutes > nowMinutes && reminderMinutes < nearestMinutes) {
                nearestMinutes = reminderMinutes;
                nearest = reminder;
            }
        }
        return nearest;
    }

    // ===== Обратный отсчёт =====
    private String formatCountdown(String time) {
        if (time == null) return "";
        String[] parts = time.split(":");
        if (parts.length < 2) return "";

        int h, m;
        try {
            h = Integer.parseInt(parts[0]);
            m = Integer.parseInt(parts[1]);
        } catch (Exception e) {
            return "";
        }

        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int targetMinutes = h * 60 + m;
        int diff = targetMinutes - nowMinutes;

        if (diff <= 0) return "";

        int hours = diff / 60;
        int minutes = diff % 60;

        if (hours > 0) {
            return "через " + hours + "ч " + minutes + "м";
        } else {
            return "через " + minutes + "м";
        }
    }
}
