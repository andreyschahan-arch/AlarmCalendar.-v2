package com.aicalendar.v2;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class VacationDialog extends Dialog {

    public interface OnVacationSaveListener {
        void onSaved();
    }

    private SwitchCompat swVacationActive;
    private LinearLayout containerDates;
    private TextView tvVacationStart;
    private TextView tvVacationEnd;

    private final OnVacationSaveListener listener;
    private AlarmSettings settings;

    private Calendar startCal = null;
    private Calendar endCal = null;

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private final SimpleDateFormat displaySdf = new SimpleDateFormat("d MMMM yyyy", new Locale("ru"));

    public VacationDialog(@NonNull Context context, OnVacationSaveListener listener) {
        super(context);
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_vacation);

        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        settings = AlarmSettings.load(getContext());

        swVacationActive = findViewById(R.id.swVacationActive);
        containerDates = findViewById(R.id.containerDates);
        tvVacationStart = findViewById(R.id.tvVacationStart);
        tvVacationEnd = findViewById(R.id.tvVacationEnd);
        Button btnCancel = findViewById(R.id.btnVacationCancel);
        Button btnSave = findViewById(R.id.btnVacationSave);

        // Загружаем сохранённые значения
        swVacationActive.setChecked(settings.isVacationActive());

        if (settings.getVacationStart() != null && !settings.getVacationStart().isEmpty()) {
            try {
                startCal = Calendar.getInstance();
                startCal.setTime(sdf.parse(settings.getVacationStart()));
                tvVacationStart.setText(displaySdf.format(startCal.getTime()));
            } catch (Exception ignored) {}
        }
        if (settings.getVacationEnd() != null && !settings.getVacationEnd().isEmpty()) {
            try {
                endCal = Calendar.getInstance();
                endCal.setTime(sdf.parse(settings.getVacationEnd()));
                tvVacationEnd.setText(displaySdf.format(endCal.getTime()));
            } catch (Exception ignored) {}
        }

        // Видимость дат
        containerDates.setVisibility(swVacationActive.isChecked() ? View.VISIBLE : View.GONE);

        swVacationActive.setOnCheckedChangeListener((v, checked) -> {
            containerDates.setVisibility(checked ? View.VISIBLE : View.GONE);
        });

        tvVacationStart.setOnClickListener(v -> showDatePicker(true));
        tvVacationEnd.setOnClickListener(v -> showDatePicker(false));

        btnCancel.setOnClickListener(v -> dismiss());

        btnSave.setOnClickListener(v -> {
            boolean active = swVacationActive.isChecked();

            if (active) {
                if (startCal == null) {
                    Toast.makeText(getContext(), "Выберите дату начала", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (endCal == null) {
                    Toast.makeText(getContext(), "Выберите дату окончания", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (endCal.getTimeInMillis() < startCal.getTimeInMillis()) {
                    Toast.makeText(getContext(), "Дата окончания раньше начала", Toast.LENGTH_SHORT).show();
                    return;
                }

                settings.setVacationStart(sdf.format(startCal.getTime()));
                settings.setVacationEnd(sdf.format(endCal.getTime()));
            }

            settings.setVacationActive(active);
            settings.save(getContext());

            if (listener != null) listener.onSaved();
            dismiss();
        });
    }

    private void showDatePicker(boolean isStart) {
        Calendar base = isStart ? startCal : endCal;
        if (base == null) base = Calendar.getInstance();

        DatePickerDialog picker = new DatePickerDialog(
		getContext(),
		(view, year, month, dayOfMonth) -> {
			Calendar picked = Calendar.getInstance();
			picked.set(year, month, dayOfMonth, 0, 0, 0);
			picked.set(Calendar.MILLISECOND, 0);

			if (isStart) {
				startCal = picked;
				tvVacationStart.setText(displaySdf.format(picked.getTime()));
			} else {
				endCal = picked;
				tvVacationEnd.setText(displaySdf.format(picked.getTime()));
			}
		},
		base.get(Calendar.YEAR),
		base.get(Calendar.MONTH),
		base.get(Calendar.DAY_OF_MONTH)
        );
        picker.show();
    }
}
