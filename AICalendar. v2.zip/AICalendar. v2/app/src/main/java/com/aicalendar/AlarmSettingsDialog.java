package com.aicalendar.v2;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

public class AlarmSettingsDialog extends Dialog {

    private final AlarmSettings settings;
    private SeekBar sbVolume;
    private EditText etRepeatCount, etRepeatInterval, etPreAlarmMinutes;
    private TextView tvMainRingtoneName, tvPreRingtoneName;

    public AlarmSettingsDialog(@NonNull Context context) {
        super(context);
        this.settings = AlarmSettings.load(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_alarm_settings);

        sbVolume = findViewById(R.id.sbVolume);
        etRepeatCount = findViewById(R.id.etRepeatCount);
        etRepeatInterval = findViewById(R.id.etRepeatInterval);
        etPreAlarmMinutes = findViewById(R.id.etPreAlarmMinutes);
        tvMainRingtoneName = findViewById(R.id.tvMainRingtoneName);
        tvPreRingtoneName = findViewById(R.id.tvPreRingtoneName);

        if (sbVolume != null) sbVolume.setProgress(settings.getVolume());
        if (etRepeatCount != null) etRepeatCount.setText(String.valueOf(settings.getRepeatCount()));
        if (etRepeatInterval != null) etRepeatInterval.setText(String.valueOf(settings.getRepeatIntervalMinutes()));
        if (etPreAlarmMinutes != null) etPreAlarmMinutes.setText(String.valueOf(settings.getPreAlarmMinutesBefore()));

        refreshRingtoneTitles();

        // Выбор основной мелодии
        findViewById(R.id.btnSelectMainRingtone).setOnClickListener(v -> showRingtoneSelectionDialog(false));

        // Выбор пре-будильника
        findViewById(R.id.btnSelectPreRingtone).setOnClickListener(v -> showRingtoneSelectionDialog(true));

        findViewById(R.id.btnCancelSettings).setOnClickListener(v -> dismiss());

        findViewById(R.id.btnSaveSettings).setOnClickListener(v -> {
            if (sbVolume != null) settings.setVolume(sbVolume.getProgress());

            try {
                if (etRepeatCount != null) settings.setRepeatCount(Integer.parseInt(etRepeatCount.getText().toString().trim()));
                if (etRepeatInterval != null) settings.setRepeatIntervalMinutes(Integer.parseInt(etRepeatInterval.getText().toString().trim()));
                if (etPreAlarmMinutes != null) settings.setPreAlarmMinutesBefore(Integer.parseInt(etPreAlarmMinutes.getText().toString().trim()));
            } catch (Exception ignored) {}

            settings.save(getContext());
            dismiss();
        });
    }

    private void showRingtoneSelectionDialog(boolean isPreAlarm) {
        RingtoneManager ringtoneManager = new RingtoneManager(getContext());
        ringtoneManager.setType(RingtoneManager.TYPE_ALARM);
        Cursor cursor = ringtoneManager.getCursor();

        List<String> titles = new ArrayList<>();
        List<Uri> uris = new ArrayList<>();

        // Дефолтный пункт
        titles.add("Стандартный сигнал");
        uris.add(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));

        while (cursor.moveToNext()) {
            String title = cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX);
            Uri uri = ringtoneManager.getRingtoneUri(cursor.getPosition());
            titles.add(title);
            uris.add(uri);
        }

        CharSequence[] items = titles.toArray(new CharSequence[0]);

        new AlertDialog.Builder(getContext())
			.setTitle(isPreAlarm ? "Выбор пре-будильника" : "Выбор основного будильника")
			.setItems(items, (dialog, which) -> {
			String selectedTitle = titles.get(which);
			Uri selectedUri = uris.get(which);
			String uriStr = selectedUri != null ? selectedUri.toString() : "";

			if (isPreAlarm) {
				settings.setPreRingtoneTitle(selectedTitle);
				settings.setPreRingtoneUri(uriStr);
			} else {
				settings.setMainRingtoneTitle(selectedTitle);
				settings.setMainRingtoneUri(uriStr);
			}
			settings.save(getContext());
			refreshRingtoneTitles();
		})
		.setNegativeButton("Отмена", null)
			.show();
    }

    public void refreshRingtoneTitles() {
        if (tvMainRingtoneName != null) {
            String title = settings.getMainRingtoneTitle();
            tvMainRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
        if (tvPreRingtoneName != null) {
            String title = settings.getPreRingtoneTitle();
            tvPreRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
    }
}

