package com.aicalendar.v2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

public class AlarmSettingsDialog extends Dialog {

    public static final int REQUEST_CODE_PICK_FILE_MAIN = 2001;
    public static final int REQUEST_CODE_PICK_FILE_PRE = 2002;

    private AlarmSettings settings;
    private final Activity activity;

    private SeekBar sbVolume;
    private EditText etRepeatCount, etRepeatInterval, etPreAlarmMinutes;
    private TextView tvMainRingtoneName, tvPreRingtoneName;

    public AlarmSettingsDialog(@NonNull Activity activity) {
        super(activity);
        this.activity = activity;
        this.settings = AlarmSettings.load(activity);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_alarm_settings);

        sbVolume = findViewById(R.id.sbVolume);
        etRepeatCount = findViewById(R.id.etRepeatCount);
        etRepeatInterval = findViewById(R.id.etRepeatInterval);
        etPreAlarmMinutes = findViewById(R.id.etPreAlarmMinutes);
        tvMainRingtoneName = findViewById(R.id.tvMainRingtoneName);
        tvPreRingtoneName = findViewById(R.id.tvPreRingtoneName);

        if (sbVolume != null) sbVolume.setProgress(settings.getVolume());
        if (etRepeatCount != null) etRepeatCount.setText(String.valueOf(settings.getRepeatCount()));
        if (etRepeatInterval != null) etRepeatInterval.setText(String.valueOf(settings.getRepeatIntervalMinutes()));
        if (etPreAlarmMinutes != null) etPreAlarmMinutes.setText(String.valueOf(settings.getPreAlarmMinutesBefore()));

        refreshRingtoneTitles();
		
		etPreAlarmMinutes.setOnFocusChangeListener((v, hasFocus) -> {
			if (!hasFocus) {
				validatePreAlarmField(false);
			}
		});

		etRepeatCount.setOnFocusChangeListener((v, hasFocus) -> {
			if (!hasFocus) {
				validateRepeatCountField(false);
			}
		});

		etRepeatInterval.setOnFocusChangeListener((v, hasFocus) -> {
			if (!hasFocus) {
				validateRepeatIntervalField(false);
			}
		});

        findViewById(R.id.btnSelectMainRingtone).setOnClickListener(v -> showRingtoneSelectionDialog(false));
        findViewById(R.id.btnSelectPreRingtone).setOnClickListener(v -> showRingtoneSelectionDialog(true));

        findViewById(R.id.btnCancelSettings).setOnClickListener(v -> dismiss());

        findViewById(R.id.btnSaveSettings).setOnClickListener(v -> {
            settings = AlarmSettings.load(getContext());

            if (sbVolume != null) settings.setVolume(sbVolume.getProgress());

            int repeatCount = 5;
            int repeatInterval = 5;
            int preAlarmMinutes = 5;

            try {
                if (etRepeatCount != null) {
                    repeatCount = Integer.parseInt(etRepeatCount.getText().toString().trim());
                }
            } catch (Exception ignored) {}

            try {
                if (etRepeatInterval != null) {
                    repeatInterval = Integer.parseInt(etRepeatInterval.getText().toString().trim());
                }
            } catch (Exception ignored) {}

            try {
                if (etPreAlarmMinutes != null) {
                    preAlarmMinutes = Integer.parseInt(etPreAlarmMinutes.getText().toString().trim());
                }
            } catch (Exception ignored) {}

            // Пре-будильник: строго от 5 до 20 минут
            if (preAlarmMinutes < 5) {
                android.widget.Toast.makeText(getContext(),
											  "Пред-будильник: минимум 5 минут",
											  android.widget.Toast.LENGTH_SHORT).show();
                if (etPreAlarmMinutes != null) etPreAlarmMinutes.setText("5");
                return;
            }

            if (preAlarmMinutes > 20) {
                android.widget.Toast.makeText(getContext(),
											  "Пред-будильник: максимум 20 минут. Поставьте отдельный будильник.",
											  android.widget.Toast.LENGTH_LONG).show();
                if (etPreAlarmMinutes != null) etPreAlarmMinutes.setText("20");
                return;
            }

            if (repeatCount < 1) repeatCount = 1;
            if (repeatCount > 20) repeatCount = 20;
            if (repeatInterval < 1) repeatInterval = 1;
            if (repeatInterval > 60) repeatInterval = 60;

            settings.setRepeatCount(repeatCount);
            settings.setRepeatIntervalMinutes(repeatInterval);
            settings.setPreAlarmMinutesBefore(preAlarmMinutes);

            settings.save(getContext());
            dismiss();
        });
    }

	private void validatePreAlarmField(boolean silent) {
		if (etPreAlarmMinutes == null) return;
		int value;
		try {
			value = Integer.parseInt(etPreAlarmMinutes.getText().toString().trim());
		} catch (Exception e) {
			value = 5;
		}

		if (value < 5) {
			if (!silent) {
				android.widget.Toast.makeText(getContext(),
											  "Минимум 5 минут", android.widget.Toast.LENGTH_SHORT).show();
			}
			etPreAlarmMinutes.setText("5");
			etPreAlarmMinutes.setSelection(etPreAlarmMinutes.getText().length());
			return;
		}

		if (value > 20) {
			if (!silent) {
				android.widget.Toast.makeText(getContext(),
											  "Максимум 20 минут", android.widget.Toast.LENGTH_SHORT).show();
			}
			etPreAlarmMinutes.setText("20");
			etPreAlarmMinutes.setSelection(etPreAlarmMinutes.getText().length());
		}
	}

	private void validateRepeatCountField(boolean silent) {
		if (etRepeatCount == null) return;
		int value;
		try {
			value = Integer.parseInt(etRepeatCount.getText().toString().trim());
		} catch (Exception e) {
			value = 5;
		}

		if (value < 1) {
			if (!silent) {
				android.widget.Toast.makeText(getContext(),
											  "Минимум 1", android.widget.Toast.LENGTH_SHORT).show();
			}
			etRepeatCount.setText("1");
			etRepeatCount.setSelection(etRepeatCount.getText().length());
			return;
		}

		if (value > 20) {
			if (!silent) {
				android.widget.Toast.makeText(getContext(),
											  "Максимум 20", android.widget.Toast.LENGTH_SHORT).show();
			}
			etRepeatCount.setText("20");
			etRepeatCount.setSelection(etRepeatCount.getText().length());
		}
	}

	private void validateRepeatIntervalField(boolean silent) {
		if (etRepeatInterval == null) return;
		int value;
		try {
			value = Integer.parseInt(etRepeatInterval.getText().toString().trim());
		} catch (Exception e) {
			value = 5;
		}

		if (value < 1) {
			if (!silent) {
				android.widget.Toast.makeText(getContext(),
											  "Минимум 1 минута", android.widget.Toast.LENGTH_SHORT).show();
			}
			etRepeatInterval.setText("1");
			etRepeatInterval.setSelection(etRepeatInterval.getText().length());
			return;
		}

		if (value > 60) {
			if (!silent) {
				android.widget.Toast.makeText(getContext(),
											  "Максимум 60 минут", android.widget.Toast.LENGTH_SHORT).show();
			}
			etRepeatInterval.setText("60");
			etRepeatInterval.setSelection(etRepeatInterval.getText().length());
		}
	}
	
	
	
    private void showRingtoneSelectionDialog(boolean isPreAlarm) {
        RingtoneManager ringtoneManager = new RingtoneManager(getContext());
        ringtoneManager.setType(RingtoneManager.TYPE_ALARM);
        Cursor cursor = ringtoneManager.getCursor();

        List<String> titles = new ArrayList<>();
        List<Uri> uris = new ArrayList<>();

        titles.add("📁 Выбрать свой файл...");
        uris.add(null);

        titles.add("Стандартный сигнал");
        uris.add(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));

        while (cursor.moveToNext()) {
            String title = cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX);
            Uri uri = ringtoneManager.getRingtoneUri(cursor.getPosition());
            titles.add(title);
            uris.add(uri);
        }

        CharSequence[] items = titles.toArray(new CharSequence[0]);

        new AlertDialog.Builder(getContext())
            .setTitle(isPreAlarm ? "Выбор пре-будильника" : "Выбор основного будильника")
            .setItems(items, (dialog, which) -> {
			if (which == 0) {
				Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
				intent.addCategory(Intent.CATEGORY_OPENABLE);
				intent.setType("audio/*");
				intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

				int requestCode = isPreAlarm ? REQUEST_CODE_PICK_FILE_PRE : REQUEST_CODE_PICK_FILE_MAIN;
				activity.startActivityForResult(intent, requestCode);
			} else {
				settings = AlarmSettings.load(getContext());
				String selectedTitle = titles.get(which);
				Uri selectedUri = uris.get(which);
				String uriStr = selectedUri != null ? selectedUri.toString() : "";

				if (isPreAlarm) {
					settings.setPreRingtoneTitle(selectedTitle);
					settings.setPreRingtoneUri(uriStr);
				} else {
					settings.setMainRingtoneTitle(selectedTitle);
					settings.setMainRingtoneUri(uriStr);
				}
				settings.save(getContext());
				refreshRingtoneTitles();
			}
		})
		.setNegativeButton("Отмена", null)
            .show();
    }

    public void refreshRingtoneTitles() {
        settings = AlarmSettings.load(getContext());
        if (tvMainRingtoneName != null) {
            String title = settings.getMainRingtoneTitle();
            tvMainRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
        if (tvPreRingtoneName != null) {
            String title = settings.getPreRingtoneTitle();
            tvPreRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
    }
}

