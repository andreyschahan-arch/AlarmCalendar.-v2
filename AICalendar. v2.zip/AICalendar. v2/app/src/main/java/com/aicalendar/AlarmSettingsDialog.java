package com.aicalendar.v2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Window;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

public class AlarmSettingsDialog extends Dialog {

    public static final int REQUEST_CODE_PICK_FILE_MAIN = 2001;
    public static final int REQUEST_CODE_PICK_FILE_PRE = 2002;

    private final AlarmSettings settings;
    private final Activity activity;

    private SeekBar sbVolume;
    private EditText etRepeatCount, etRepeatInterval, etPreAlarmMinutes;
    private TextView tvMainRingtoneName, tvPreRingtoneName;

    public AlarmSettingsDialog(@NonNull Activity activity) {
        super(activity);
        this.activity = activity;
        this.settings = AlarmSettings.load(activity);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_alarm_settings);

        sbVolume = findViewById(R.id.sbVolume);
        etRepeatCount = findViewById(R.id.etRepeatCount);
        etRepeatInterval = findViewById(R.id.etRepeatInterval);
        etPreAlarmMinutes = findViewById(R.id.etPreAlarmMinutes);
        tvMainRingtoneName = findViewById(R.id.tvMainRingtoneName);
        tvPreRingtoneName = findViewById(R.id.tvPreRingtoneName);

        if (sbVolume != null) sbVolume.setProgress(settings.getVolume());
        if (etRepeatCount != null) etRepeatCount.setText(String.valueOf(settings.getRepeatCount()));
        if (etRepeatInterval != null) etRepeatInterval.setText(String.valueOf(settings.getRepeatIntervalMinutes()));
        if (etPreAlarmMinutes != null) etPreAlarmMinutes.setText(String.valueOf(settings.getPreAlarmMinutesBefore()));

        refreshRingtoneTitles();

        findViewById(R.id.btnSelectMainRingtone).setOnClickListener(v -> showRingtoneSelectionDialog(false));
        findViewById(R.id.btnSelectPreRingtone).setOnClickListener(v -> showRingtoneSelectionDialog(true));

        findViewById(R.id.btnCancelSettings).setOnClickListener(v -> dismiss());

        findViewById(R.id.btnSaveSettings).setOnClickListener(v -> {
            if (sbVolume != null) settings.setVolume(sbVolume.getProgress());

            try {
                if (etRepeatCount != null) settings.setRepeatCount(Integer.parseInt(etRepeatCount.getText().toString().trim()));
                if (etRepeatInterval != null) settings.setRepeatIntervalMinutes(Integer.parseInt(etRepeatInterval.getText().toString().trim()));
                if (etPreAlarmMinutes != null) settings.setPreAlarmMinutesBefore(Integer.parseInt(etPreAlarmMinutes.getText().toString().trim()));
            } catch (Exception ignored) {}

            settings.save(getContext());
            dismiss();
        });
    }

    private void showRingtoneSelectionDialog(boolean isPreAlarm) {
        RingtoneManager ringtoneManager = new RingtoneManager(getContext());
        ringtoneManager.setType(RingtoneManager.TYPE_ALARM);
        Cursor cursor = ringtoneManager.getCursor();

        List<String> titles = new ArrayList<>();
        List<Uri> uris = new ArrayList<>();

        // 1. Пункт для выбора своего файла MP3
        titles.add("📁 Выбрать свой файл...");
        uris.add(null);

        // 2. Стандартный сигнал
        titles.add("Стандартный сигнал");
        uris.add(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));

        // 3. Системные мелодии
        while (cursor.moveToNext()) {
            String title = cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX);
            Uri uri = ringtoneManager.getRingtoneUri(cursor.getPosition());
            titles.add(title);
            uris.add(uri);
        }

        CharSequence[] items = titles.toArray(new CharSequence[0]);

        new AlertDialog.Builder(getContext())
			.setTitle(isPreAlarm ? "Выбор пре-будильника" : "Выбор основного будильника")
			.setItems(items, (dialog, which) -> {
			if (which == 0) {
				// Открываем системный проводник для выбора MP3/аудио
				Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
				intent.addCategory(Intent.CATEGORY_OPENABLE);
				intent.setType("audio/*");
				intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

				int requestCode = isPreAlarm ? REQUEST_CODE_PICK_FILE_PRE : REQUEST_CODE_PICK_FILE_MAIN;
				activity.startActivityForResult(intent, requestCode);
			} else {
				String selectedTitle = titles.get(which);
				Uri selectedUri = uris.get(which);
				String uriStr = selectedUri != null ? selectedUri.toString() : "";

				if (isPreAlarm) {
					settings.setPreRingtoneTitle(selectedTitle);
					settings.setPreRingtoneUri(uriStr);
				} else {
					settings.setMainRingtoneTitle(selectedTitle);
					settings.setMainRingtoneUri(uriStr);
				}
				settings.save(getContext());
				refreshRingtoneTitles();
			}
		})
		.setNegativeButton("Отмена", null)
			.show();
    }

    public void refreshRingtoneTitles() {
        AlarmSettings current = AlarmSettings.load(getContext());
        if (tvMainRingtoneName != null) {
            String title = current.getMainRingtoneTitle();
            tvMainRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
        if (tvPreRingtoneName != null) {
            String title = current.getPreRingtoneTitle();
            tvPreRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
    }
}

