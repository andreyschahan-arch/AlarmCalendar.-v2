package com.aicalendar.v2;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;

public class AlarmSettingsDialog extends Dialog {

    private final AlarmSettings settings;
    private SeekBar sbVolume;
    private EditText etRepeatCount, etRepeatInterval, etPreAlarmMinutes;
    private TextView tvMainRingtoneName, tvPreRingtoneName;

    public AlarmSettingsDialog(@NonNull Context context) {
        super(context);
        this.settings = AlarmSettings.load(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_alarm_settings);

        sbVolume = findViewById(R.id.sbVolume);
        etRepeatCount = findViewById(R.id.etRepeatCount);
        etRepeatInterval = findViewById(R.id.etRepeatInterval);
        etPreAlarmMinutes = findViewById(R.id.etPreAlarmMinutes);
        tvMainRingtoneName = findViewById(R.id.tvMainRingtoneName);
        tvPreRingtoneName = findViewById(R.id.tvPreRingtoneName);

        if (sbVolume != null) sbVolume.setProgress(settings.getVolume());
        if (etRepeatCount != null) etRepeatCount.setText(String.valueOf(settings.getRepeatCount()));
        if (etRepeatInterval != null) etRepeatInterval.setText(String.valueOf(settings.getRepeatIntervalMinutes()));
        if (etPreAlarmMinutes != null) etPreAlarmMinutes.setText(String.valueOf(settings.getPreAlarmMinutesBefore()));

        refreshRingtoneTitles();

        findViewById(R.id.btnSelectMainRingtone).setOnClickListener(v -> openRingtonePicker(false));
        findViewById(R.id.btnSelectPreRingtone).setOnClickListener(v -> openRingtonePicker(true));

        findViewById(R.id.btnCancelSettings).setOnClickListener(v -> dismiss());

        findViewById(R.id.btnSaveSettings).setOnClickListener(v -> {
            if (sbVolume != null) settings.setVolume(sbVolume.getProgress());

            try {
                if (etRepeatCount != null) {
                    settings.setRepeatCount(Integer.parseInt(etRepeatCount.getText().toString().trim()));
                }
                if (etRepeatInterval != null) {
                    settings.setRepeatIntervalMinutes(Integer.parseInt(etRepeatInterval.getText().toString().trim()));
                }
                if (etPreAlarmMinutes != null) {
                    settings.setPreAlarmMinutesBefore(Integer.parseInt(etPreAlarmMinutes.getText().toString().trim()));
                }
            } catch (Exception ignored) {}

            settings.save(getContext());
            dismiss();
        });
    }

    private void openRingtonePicker(boolean isPreAlarm) {
        if (!(getContext() instanceof Activity)) return;
        Activity activity = (Activity) getContext();

        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, isPreAlarm ? "Мелодия пре-будильника" : "Основная мелодия");
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);

        activity.startActivityForResult(intent, isPreAlarm ? 1002 : 1001);
    }

    public void refreshRingtoneTitles() {
        AlarmSettings currentSettings = AlarmSettings.load(getContext());

        this.settings.setMainRingtoneTitle(currentSettings.getMainRingtoneTitle());
        this.settings.setMainRingtoneUri(currentSettings.getMainRingtoneUri());
        this.settings.setPreRingtoneTitle(currentSettings.getPreRingtoneTitle());
        this.settings.setPreRingtoneUri(currentSettings.getPreRingtoneUri());

        if (tvMainRingtoneName != null) {
            String title = settings.getMainRingtoneTitle();
            tvMainRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
        if (tvPreRingtoneName != null) {
            String title = settings.getPreRingtoneTitle();
            tvPreRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
        }
    }

    public void updateRingtone(boolean isPreAlarm, String title, String uriStr) {
        if (isPreAlarm) {
            settings.setPreRingtoneTitle(title);
            settings.setPreRingtoneUri(uriStr);
            if (tvPreRingtoneName != null) {
                tvPreRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
            }
        } else {
            settings.setMainRingtoneTitle(title);
            settings.setMainRingtoneUri(uriStr);
            if (tvMainRingtoneName != null) {
                tvMainRingtoneName.setText(title != null && !title.isEmpty() ? title : "Стандартный сигнал");
            }
        }
        settings.save(getContext());
    }
}

