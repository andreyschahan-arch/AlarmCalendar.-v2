package com.aicalendar.v2;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;

public class AlarmSettingsDialog extends Dialog {

    public interface OnRingtonePickerRequestListener {
        void onRequestRingtonePick(boolean isPreAlarm);
    }

    private final AlarmSettings settings;
    private final OnRingtonePickerRequestListener pickerListener;

    private SeekBar sbVolume;
    private EditText etRepeatCount, etRepeatInterval, etPreAlarmMinutes;
    private TextView tvMainRingtoneName, tvPreRingtoneName;

    public AlarmSettingsDialog(@NonNull Context context, OnRingtonePickerRequestListener pickerListener) {
        super(context);
        this.settings = AlarmSettings.load(context);
        this.pickerListener = pickerListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_alarm_settings);

        sbVolume = findViewById(R.id.sbVolume);
        etRepeatCount = findViewById(R.id.etRepeatCount);
        etRepeatInterval = findViewById(R.id.etRepeatInterval);
        etPreAlarmMinutes = findViewById(R.id.etPreAlarmMinutes);
        tvMainRingtoneName = findViewById(R.id.tvMainRingtoneName);
        tvPreRingtoneName = findViewById(R.id.tvPreRingtoneName);

        // Заполняем сохраненные значения
        if (sbVolume != null) sbVolume.setProgress(settings.getVolume());
        if (etRepeatCount != null) etRepeatCount.setText(String.valueOf(settings.getRepeatCount()));
        if (etRepeatInterval != null) etRepeatInterval.setText(String.valueOf(settings.getRepeatIntervalMinutes()));
        if (etPreAlarmMinutes != null) etPreAlarmMinutes.setText(String.valueOf(settings.getPreAlarmMinutesBefore()));
        if (tvMainRingtoneName != null) tvMainRingtoneName.setText(settings.getMainRingtoneTitle());
        if (tvPreRingtoneName != null) tvPreRingtoneName.setText(settings.getPreRingtoneTitle());

        findViewById(R.id.btnSelectMainRingtone).setOnClickListener(v -> {
            if (pickerListener != null) pickerListener.onRequestRingtonePick(false);
        });

        findViewById(R.id.btnSelectPreRingtone).setOnClickListener(v -> {
            if (pickerListener != null) pickerListener.onRequestRingtonePick(true);
        });

        findViewById(R.id.btnCancelSettings).setOnClickListener(v -> dismiss());

        findViewById(R.id.btnSaveSettings).setOnClickListener(v -> {
            if (sbVolume != null) settings.setVolume(sbVolume.getProgress());

            try {
                if (etRepeatCount != null) {
                    settings.setRepeatCount(Integer.parseInt(etRepeatCount.getText().toString().trim()));
                }
                if (etRepeatInterval != null) {
                    settings.setRepeatIntervalMinutes(Integer.parseInt(etRepeatInterval.getText().toString().trim()));
                }
                if (etPreAlarmMinutes != null) {
                    settings.setPreAlarmMinutesBefore(Integer.parseInt(etPreAlarmMinutes.getText().toString().trim()));
                }
            } catch (Exception ignored) {}

            settings.save(getContext());
            dismiss();
        });
    }

    public void updateRingtone(boolean isPreAlarm, String title, String uriStr) {
        if (uriStr != null && !uriStr.isEmpty()) {
            try {
                Uri uri = Uri.parse(uriStr);
                getContext().getContentResolver().takePersistableUriPermission(
					uri,
					Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (Exception ignored) {}
        }

        if (isPreAlarm) {
            settings.setPreRingtoneTitle(title);
            settings.setPreRingtoneUri(uriStr);
            if (tvPreRingtoneName != null) tvPreRingtoneName.setText(title);
        } else {
            settings.setMainRingtoneTitle(title);
            settings.setMainRingtoneUri(uriStr);
            if (tvMainRingtoneName != null) tvMainRingtoneName.setText(title);
        }
    }
}

