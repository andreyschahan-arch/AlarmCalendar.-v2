package com.aicalendar.v2;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;

public class AlarmSettingsDialog extends Dialog {

    public interface OnRingtonePickerRequestListener {
        void onRequestRingtonePick(boolean isPreAlarm);
    }

    private final AlarmSettings settings;
    private final OnRingtonePickerRequestListener pickerListener;

    private SeekBar sbVolume;
    private EditText etRepeatCount, etRepeatInterval, etPreAlarmMinutes;
    private TextView tvMainRingtoneName, tvPreRingtoneName;

    public AlarmSettingsDialog(@NonNull Context context, OnRingtonePickerRequestListener pickerListener) {
        super(context);
        this.settings = AlarmSettings.load(context);
        this.pickerListener = pickerListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_alarm_settings);

        sbVolume = findViewById(R.id.sbVolume);
        etRepeatCount = findViewById(R.id.etRepeatCount);
        etRepeatInterval = findViewById(R.id.etRepeatInterval);
        etPreAlarmMinutes = findViewById(R.id.etPreAlarmMinutes);
        tvMainRingtoneName = findViewById(R.id.tvMainRingtoneName);
        tvPreRingtoneName = findViewById(R.id.tvPreRingtoneName);

        // Заполняем сохраненные значения
        sbVolume.setProgress(settings.getVolume());
        etRepeatCount.setText(String.valueOf(settings.getRepeatCount()));
        etRepeatInterval.setText(String.valueOf(settings.getRepeatIntervalMinutes()));
        etPreAlarmMinutes.setText(String.valueOf(settings.getPreAlarmMinutesBefore()));
        tvMainRingtoneName.setText(settings.getMainRingtoneTitle());
        tvPreRingtoneName.setText(settings.getPreRingtoneTitle());

        findViewById(R.id.btnSelectMainRingtone).setOnClickListener(v -> {
            if (pickerListener != null) pickerListener.onRequestRingtonePick(false);
        });

        findViewById(R.id.btnSelectPreRingtone).setOnClickListener(v -> {
            if (pickerListener != null) pickerListener.onRequestRingtonePick(true);
        });

        findViewById(R.id.btnCancelSettings).setOnClickListener(v -> dismiss());

        findViewById(R.id.btnSaveSettings).setOnClickListener(v -> {
            settings.setVolume(sbVolume.getProgress());
            try {
                settings.setRepeatCount(Integer.parseInt(etRepeatCount.getText().toString().trim()));
                settings.setRepeatIntervalMinutes(Integer.parseInt(etRepeatInterval.getText().toString().trim()));
                settings.setPreAlarmMinutesBefore(Integer.parseInt(etPreAlarmMinutes.getText().toString().trim()));
            } catch (Exception ignored) {}

            settings.save(getContext());
            dismiss();
        });
    }

    public void updateRingtone(boolean isPreAlarm, String title, String uriStr) {
        if (isPreAlarm) {
            settings.setPreRingtoneTitle(title);
            settings.setPreRingtoneUri(uriStr);
            if (tvPreRingtoneName != null) tvPreRingtoneName.setText(title);
        } else {
            settings.setMainRingtoneTitle(title);
            settings.setMainRingtoneUri(uriStr);
            if (tvMainRingtoneName != null) tvMainRingtoneName.setText(title);
        }
    }
}

