package com.aicalendar.v2;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class ProfileDialog extends Dialog {

    public interface OnProfileSaveListener {
        void onSave(ProfileModel profile);
    }

    private EditText etProfileName;
    private LinearLayout colorContainer;
    private LinearLayout remindersLayout;

    private OnProfileSaveListener listener;
    private ProfileModel existingProfile;

    // Круглая палитра
    private final String[] colors = {
		"#FF5252", "#FF4081", "#E040FB", "#7C4DFF",
		"#536DFE", "#448AFF", "#1DE9B6", "#00E676",
		"#76FF03", "#FFEA00", "#FF9100", "#FF3D00"
    };

    private String selectedColor = colors[0];

    public ProfileDialog(@NonNull Context context, ProfileModel existingProfile, OnProfileSaveListener listener) {
        super(context);
        this.existingProfile = existingProfile;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_profile);

        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        etProfileName = findViewById(R.id.etProfileName);
        colorContainer = findViewById(R.id.colorContainer);
        remindersLayout = findViewById(R.id.remindersLayout);

        Button btnAddReminder = findViewById(R.id.btnAddReminder);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        setupColorCircles();

        btnAddReminder.setOnClickListener(v -> showTimePickerAndAdd("06:00", ""));

        if (existingProfile != null) {
            etProfileName.setText(existingProfile.getName());
            selectedColor = existingProfile.getColor();

            // Если есть сохраненные напоминания — восстанавливаем их
            if (existingProfile.getReminders() != null) {
                for (ReminderModel reminder : existingProfile.getReminders()) {
                    addReminderRow(reminder.getTime(), reminder.getText());
                }
            }
        }

        btnCancel.setOnClickListener(v -> dismiss());

        btnSave.setOnClickListener(v -> {
            String name = etProfileName.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(getContext(), "Введите название профиля", Toast.LENGTH_SHORT).show();
                return;
            }

            // Собираем все добавленные напоминания из списка
            List<ReminderModel> reminders = new ArrayList<>();
            for (int i = 0; i < remindersLayout.getChildCount(); i++) {
                View row = remindersLayout.getChildAt(i);
                TextView tvTime = row.findViewById(R.id.tvReminderTime);
                EditText etText = row.findViewById(R.id.etReminderText);

                String time = tvTime.getText().toString();
                String text = etText.getText().toString().trim();

                reminders.add(new ReminderModel(time, text));
            }

            String id = (existingProfile != null) ? existingProfile.getId() : UUID.randomUUID().toString();

            ProfileModel profile = new ProfileModel(id, name, selectedColor, reminders);
            if (listener != null) {
                listener.onSave(profile);
            }
            dismiss();
        });
    }

    private void setupColorCircles() {
        colorContainer.removeAllViews();
        int density = (int) getContext().getResources().getDisplayMetrics().density;

        // Крупный круглый размер 46dp
        int size = 46 * density;
        int margin = 5 * density;

        for (String hexColor : colors) {
            View circle = new View(getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMargins(margin, 0, margin, 0);
            circle.setLayoutParams(params);

            boolean isSelected = hexColor.equalsIgnoreCase(selectedColor);

            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            drawable.setColor(Color.parseColor(hexColor));

            // Белая ободка вокруг выбранного кругляша
            if (isSelected) {
                drawable.setStroke(3 * density, Color.WHITE);
            }

            circle.setBackground(drawable);

            circle.setOnClickListener(v -> {
                selectedColor = hexColor;
                setupColorCircles();
            });

            colorContainer.addView(circle);
        }
    }

    private void showTimePickerAndAdd(String defaultTime, String defaultText) {
        Calendar cal = Calendar.getInstance();
        TimePickerDialog dialog = new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
            String time = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
            addReminderRow(time, defaultText);
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true);
        dialog.show();
    }

    private void addReminderRow(String time, String text) {
        View row = LayoutInflater.from(getContext()).inflate(R.layout.item_reminder, remindersLayout, false);

        TextView tvTime = row.findViewById(R.id.tvReminderTime);
        EditText etText = row.findViewById(R.id.etReminderText);
        TextView btnDelete = row.findViewById(R.id.btnDeleteReminder);

        tvTime.setText(time);
        etText.setText(text);

        // Нажатие на время открывает изменение времени
        tvTime.setOnClickListener(v -> {
            String[] parts = tvTime.getText().toString().split(":");
            int h = Integer.parseInt(parts[0]);
            int m = Integer.parseInt(parts[1]);
            TimePickerDialog dialog = new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
                tvTime.setText(String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute));
            }, h, m, true);
            dialog.show();
        });

        // Удаление строчки
        btnDelete.setOnClickListener(v -> remindersLayout.removeView(row));

        remindersLayout.addView(row);
    }
}

