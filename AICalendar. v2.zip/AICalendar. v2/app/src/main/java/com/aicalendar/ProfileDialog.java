package com.aicalendar.v2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.UUID;

public class ProfileDialog extends Dialog {

    public interface OnProfileSaveListener {
        void onSave(ProfileModel profile);
    }

    private EditText etProfileName;
    private Switch switchAlarm;
    private TimePicker timePicker;
    private GridLayout colorGrid;

    private OnProfileSaveListener listener;
    private ProfileModel existingProfile;

    // Палитра из 12 ярких цветов (получится 2 ряда по 6 кругляшей)
    private final String[] colors = {
		"#FF5252", "#FF4081", "#E040FB", "#7C4DFF", "#536DFE", "#448AFF",
		"#1DE9B6", "#00E676", "#76FF03", "#FFEA00", "#FF9100", "#FF3D00"
    };

    private String selectedColor = colors[0];

    public ProfileDialog(@NonNull Context context, ProfileModel existingProfile, OnProfileSaveListener listener) {
        super(context);
        this.existingProfile = existingProfile;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_profile);

        // Растягиваем окно по ширине экрана
        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        etProfileName = findViewById(R.id.etProfileName);
        switchAlarm = findViewById(R.id.switchAlarm);
        timePicker = findViewById(R.id.timePicker);
        colorGrid = findViewById(R.id.colorGrid);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        timePicker.setIs24HourView(true);

        setupColorCircles();

        switchAlarm.setOnCheckedChangeListener((buttonView, isChecked) -> {
            timePicker.setVisibility(isChecked ? View.VISIBLE : View.GONE);
        });

        if (existingProfile != null) {
            etProfileName.setText(existingProfile.getName());
            selectedColor = existingProfile.getColor();
            switchAlarm.setChecked(existingProfile.isAlarmEnabled());
            timePicker.setVisibility(existingProfile.isAlarmEnabled() ? View.VISIBLE : View.GONE);
            timePicker.setHour(existingProfile.getAlarmHour());
            timePicker.setMinute(existingProfile.getAlarmMinute());
        }

        btnCancel.setOnClickListener(v -> dismiss());

        btnSave.setOnClickListener(v -> {
            String name = etProfileName.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(getContext(), "Введите название профиля", Toast.LENGTH_SHORT).show();
                return;
            }

            String id = (existingProfile != null) ? existingProfile.getId() : UUID.randomUUID().toString();
            boolean alarmEnabled = switchAlarm.isChecked();
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            ProfileModel profile = new ProfileModel(id, name, selectedColor, alarmEnabled, hour, minute);
            if (listener != null) {
                listener.onSave(profile);
            }
            dismiss();
        });
    }

    private void setupColorCircles() {
        colorGrid.removeAllViews();
        int density = (int) getContext().getResources().getDisplayMetrics().density;

        // Размер круглишка 44dp
        int size = 44 * density;
        int margin = 6 * density;

        for (String hexColor : colors) {
            View circle = new View(getContext());
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = size;
            params.height = size;
            params.setMargins(margin, margin, margin, margin);
            circle.setLayoutParams(params);

            boolean isSelected = hexColor.equalsIgnoreCase(selectedColor);

            // Создаем кружок OVP (OVAL)
            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            drawable.setColor(Color.parseColor(hexColor));

            // Белая обводка у активного цвета
            if (isSelected) {
                drawable.setStroke(3 * density, Color.WHITE);
            }

            circle.setBackground(drawable);

            circle.setOnClickListener(v -> {
                selectedColor = hexColor;
                setupColorCircles();
            });

            colorGrid.addView(circle);
        }
    }
}

