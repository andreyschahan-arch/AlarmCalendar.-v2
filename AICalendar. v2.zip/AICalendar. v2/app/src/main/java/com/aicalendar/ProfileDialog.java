package com.aicalendar.v2;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class ProfileDialog extends Dialog {

	public interface OnProfileSaveListener {
        void onSave(ProfileModel profile);
        void onDelete(ProfileModel profile); // Новое событие для удаления
    }
	

    private EditText etProfileName;
    private EditText etRepeatDays;
    private LinearLayout colorContainer;
    private LinearLayout remindersLayout;

    private OnProfileSaveListener listener;
    private ProfileModel existingProfile;

    private final String[] colors = {
		"#FF5252", "#FF4081", "#E040FB", "#7C4DFF",
		"#536DFE", "#448AFF", "#1DE9B6", "#00E676",
		"#76FF03", "#FFEA00", "#FF9100", "#FF3D00"
    };

    private String selectedColor = colors[0];

    public ProfileDialog(@NonNull Context context, ProfileModel existingProfile, OnProfileSaveListener listener) {
        super(context);
        this.existingProfile = existingProfile;
        this.listener = listener;
    }

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_profile);

        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
            // Подстраиваем окно при открытии клавиатуры
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        etProfileName = findViewById(R.id.etProfileName);
        etRepeatDays = findViewById(R.id.etRepeatDays);
        colorContainer = findViewById(R.id.colorContainer);
        remindersLayout = findViewById(R.id.remindersLayout);

        Button btnAddReminder = findViewById(R.id.btnAddReminder);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnClone = findViewById(R.id.btnClone);

        btnAddReminder.setOnClickListener(v -> showTimePickerAndAdd("06:00", ""));

        // 1. Сначала считываем данные сохраненного профиля
        if (existingProfile != null) {
            etProfileName.setText(existingProfile.getName());
            etRepeatDays.setText(String.valueOf(existingProfile.getRepeatDays()));
            selectedColor = existingProfile.getColor(); // Считываем сохраненный цвет

            if (existingProfile.getReminders() != null) {
                for (ReminderModel reminder : existingProfile.getReminders()) {
                    addReminderRow(reminder.getTime(), reminder.getText());
                }
            }

            // При редактировании показываем кнопки УДАЛИТЬ и КЛОНИРОВАТЬ
            if (btnDelete != null) btnDelete.setVisibility(View.VISIBLE);
            if (btnClone != null) btnClone.setVisibility(View.VISIBLE);
        } else {
            etRepeatDays.setText("4"); // Значение по умолчанию

            // При создании нового профиля прячем их
            if (btnDelete != null) btnDelete.setVisibility(View.GONE);
            if (btnClone != null) btnClone.setVisibility(View.GONE);
        }

        // 2. И только теперь отрисовываем палитру (рамка встанет на сохраненный цвет)
        setupColorCircles();

        // Кнопка ОТМЕНА
        btnCancel.setOnClickListener(v -> dismiss());

        // Кнопка УДАЛИТЬ
        if (btnDelete != null) {
            btnDelete.setOnClickListener(v -> {
                if (listener != null && existingProfile != null) {
                    listener.onDelete(existingProfile);
                }
                dismiss();
            });
        }

        // Кнопка КЛОНИРОВАТЬ
        if (btnClone != null) {
            btnClone.setOnClickListener(v -> {
                String name = etProfileName.getText().toString().trim() + " (копия)";
                String repeatStr = etRepeatDays.getText().toString().trim();

                int repeatDays = 1;
                if (!repeatStr.isEmpty()) {
                    try {
                        repeatDays = Integer.parseInt(repeatStr);
                    } catch (NumberFormatException e) {
                        repeatDays = 1;
                    }
                }

                List<ReminderModel> reminders = new ArrayList<>();
                for (int i = 0; i < remindersLayout.getChildCount(); i++) {
                    View row = remindersLayout.getChildAt(i);
                    TextView tvTime = row.findViewById(R.id.tvReminderTime);
                    EditText etText = row.findViewById(R.id.etReminderText);

                    String time = tvTime.getText().toString();
                    String text = etText.getText().toString().trim();

                    reminders.add(new ReminderModel(time, text));
                }

                // Генерируем новый уникальный ID для копии
                ProfileModel clonedProfile = new ProfileModel(UUID.randomUUID().toString(), name, repeatDays, selectedColor, reminders);
                if (listener != null) {
                    listener.onSave(clonedProfile);
                }
                dismiss();
            });
        }

        // Кнопка СОХРАНИТЬ
        // Кнопка СОХРАНИТЬ
		btnSave.setOnClickListener(v -> {
			String name = etProfileName.getText().toString().trim();
			String repeatStr = etRepeatDays.getText().toString().trim();

			if (name.isEmpty()) {
				Toast.makeText(getContext(), "Введите название профиля", Toast.LENGTH_SHORT).show();
				return;
			}

			int repeatDays = 1;
			if (!repeatStr.isEmpty()) {
				try {
					repeatDays = Integer.parseInt(repeatStr);
				} catch (NumberFormatException e) {
					repeatDays = 1;
				}
			}

			List<ReminderModel> reminders = new ArrayList<>();
			for (int i = 0; i < remindersLayout.getChildCount(); i++) {
				View row = remindersLayout.getChildAt(i);
				TextView tvTime = row.findViewById(R.id.tvReminderTime);
				EditText etText = row.findViewById(R.id.etReminderText);

				String time = tvTime.getText().toString();
				String text = etText.getText().toString().trim();

				reminders.add(new ReminderModel(time, text));
			}

			String id = (existingProfile != null) ? existingProfile.getId() : UUID.randomUUID().toString();

			ProfileModel profile = new ProfileModel(id, name, repeatDays, selectedColor, reminders);

			// --- ВОТ ЭТА СТРОЧКА СПАСАЕТ ДАТЫ СТАРТА ЦИКЛА ---
			if (existingProfile != null) {
				profile.setStartDate(existingProfile.getStartDate());
			}

			if (listener != null) {
				listener.onSave(profile);
			}
			dismiss();
		});
		
    }
	
	

    private void setupColorCircles() {
        colorContainer.removeAllViews();
        int density = (int) getContext().getResources().getDisplayMetrics().density;

        int size = 46 * density;
        int margin = 5 * density;

        for (String hexColor : colors) {
            View circle = new View(getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMargins(margin, 0, margin, 0);
            circle.setLayoutParams(params);

            boolean isSelected = hexColor.equalsIgnoreCase(selectedColor);

            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            drawable.setColor(Color.parseColor(hexColor));

            if (isSelected) {
                drawable.setStroke(3 * density, Color.WHITE);
            }

            circle.setBackground(drawable);

            circle.setOnClickListener(v -> {
                selectedColor = hexColor;
                setupColorCircles();
            });

            colorContainer.addView(circle);
        }
    }

    private void showTimePickerAndAdd(String defaultTime, String defaultText) {
        Calendar cal = Calendar.getInstance();
        TimePickerDialog dialog = new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
            String time = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
            addReminderRow(time, defaultText);
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true);
        dialog.show();
    }

    private void addReminderRow(String time, String text) {
        View row = LayoutInflater.from(getContext()).inflate(R.layout.item_reminder, remindersLayout, false);

        TextView tvTime = row.findViewById(R.id.tvReminderTime);
        EditText etText = row.findViewById(R.id.etReminderText);
        TextView btnDelete = row.findViewById(R.id.btnDeleteReminder);

        tvTime.setText(time);
        etText.setText(text);

        tvTime.setOnClickListener(v -> {
            String[] parts = tvTime.getText().toString().split(":");
            int h = Integer.parseInt(parts[0]);
            int m = Integer.parseInt(parts[1]);
            TimePickerDialog dialog = new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
                tvTime.setText(String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute));
            }, h, m, true);
            dialog.show();
        });

        btnDelete.setOnClickListener(v -> remindersLayout.removeView(row));

        remindersLayout.addView(row);
    }
}

