package com.aicalendar.v2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.UUID;

public class ProfileDialog extends Dialog {

    public interface OnProfileSaveListener {
        void onSave(ProfileModel profile);
    }

    private EditText etProfileName;
    private Switch switchAlarm;
    private TimePicker timePicker;
    private LinearLayout colorContainer;

    private OnProfileSaveListener listener;
    private ProfileModel existingProfile;

    // Палитра доступных цветов для профилей
    private final String[] colors = {
		"#FF5252", "#FF4081", "#E040FB", "#7C4DFF",
		"#536DFE", "#448AFF", "#18FFFF", "#64FFDA",
		"#B2FF59", "#EEFF41", "#FFD740", "#FFAB40"
    };

    private String selectedColor = colors[0];

    public ProfileDialog(@NonNull Context context, ProfileModel existingProfile, OnProfileSaveListener listener) {
        super(context);
        this.existingProfile = existingProfile;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_profile);

        etProfileName = findViewById(R.id.etProfileName);
        switchAlarm = findViewById(R.id.switchAlarm);
        timePicker = findViewById(R.id.timePicker);
        colorContainer = findViewById(R.id.colorContainer);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        timePicker.setIs24HourView(true);

        setupColorPalette();

        switchAlarm.setOnCheckedChangeListener((buttonView, isChecked) -> {
            timePicker.setVisibility(isChecked ? View.VISIBLE : View.GONE);
        });

        if (existingProfile != null) {
            etProfileName.setText(existingProfile.getName());
            selectedColor = existingProfile.getColor();
            switchAlarm.setChecked(existingProfile.isAlarmEnabled());
            timePicker.setVisibility(existingProfile.isAlarmEnabled() ? View.VISIBLE : View.GONE);
            timePicker.setHour(existingProfile.getAlarmHour());
            timePicker.setMinute(existingProfile.getAlarmMinute());
        }

        btnCancel.setOnClickListener(v -> dismiss());

        btnSave.setOnClickListener(v -> {
            String name = etProfileName.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(getContext(), "Введите название профиля", Toast.LENGTH_SHORT).show();
                return;
            }

            String id = (existingProfile != null) ? existingProfile.getId() : UUID.randomUUID().toString();
            boolean alarmEnabled = switchAlarm.isChecked();
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            ProfileModel profile = new ProfileModel(id, name, selectedColor, alarmEnabled, hour, minute);
            if (listener != null) {
                listener.onSave(profile);
            }
            dismiss();
        });
    }

    private void setupColorPalette() {
        colorContainer.removeAllViews();
        int density = (int) getContext().getResources().getDisplayMetrics().density;
        int size = 32 * density;
        int margin = 6 * density;

        for (String hexColor : colors) {
            View circle = new View(getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMargins(margin, 0, margin, 0);
            circle.setLayoutParams(params);

            updateCircleDrawable(circle, hexColor, hexColor.equalsIgnoreCase(selectedColor));

            circle.setOnClickListener(v -> {
                selectedColor = hexColor;
                setupColorPalette(); // обновить выделение кружка
            });

            colorContainer.addView(circle);
        }
    }

    private void updateCircleDrawable(View view, String hexColor, boolean isSelected) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(Color.parseColor(hexColor));
        if (isSelected) {
            drawable.setStroke(6, Color.WHITE);
        }
        view.setBackground(drawable);
    }
}

