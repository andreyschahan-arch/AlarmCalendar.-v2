package com.aicalendar.v2;

import java.util.Date;

public class DayModel {
    private String dayNumber;
    private boolean isCurrentMonth;
    private Date date;

    public DayModel(String dayNumber, boolean isCurrentMonth, Date date) {
        this.dayNumber = dayNumber;
        this.isCurrentMonth = isCurrentMonth;
        this.date = date;
    }

    public String getDayNumber() {
        return dayNumber;
    }

    public boolean isCurrentMonth() {
        return isCurrentMonth;
    }

    public Date getDate() {
        return date;
    }
}

