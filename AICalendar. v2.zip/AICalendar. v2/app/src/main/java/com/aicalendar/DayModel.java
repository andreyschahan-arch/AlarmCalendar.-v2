package com.aicalendar.v2;

public class DayModel {
    private String dayNumber;
    private boolean isCurrentMonth;

    public DayModel(String dayNumber, boolean isCurrentMonth) {
        this.dayNumber = dayNumber;
        this.isCurrentMonth = isCurrentMonth;
    }

    public String getDayNumber() {
        return dayNumber;
    }

    public boolean isCurrentMonth() {
        return isCurrentMonth;
    }
}

