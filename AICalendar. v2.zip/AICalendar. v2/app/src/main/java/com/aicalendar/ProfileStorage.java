package com.aicalendar.v2;

import android.content.Context;
import android.content.SharedPreferences;

public class ProfileStorage {

    private static final String PREF_NAME = "ai_calendar_prefs";
    private static final String KEY_PROFILES_JSON = "profiles_json";

    // Сохранение строки JSON с профилями в постоянную память
    public static void saveProfilesJson(Context context, String json) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_PROFILES_JSON, json).apply();
    }

    // Загрузка сохранённых профилей при запуске приложения
    public static String getProfilesJson(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_PROFILES_JSON, "");
    }
}

