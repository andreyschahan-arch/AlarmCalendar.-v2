package com.aicalendar.v2;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ProfileStorage {

    private static final String PREF_NAME = "ai_calendar_prefs";
    private static final String KEY_PROFILES = "profiles_list";

    // Сохранение списка профилей в SharedPreferences
    public static void saveProfiles(Context context, List<ProfileModel> profiles) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        JSONArray jsonArray = new JSONArray();

        try {
            for (ProfileModel profile : profiles) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", profile.getId());
                jsonObject.put("name", profile.getName());
                jsonObject.put("repeatDays", profile.getRepeatDays());
                jsonObject.put("color", profile.getColor());
                jsonObject.put("startDate", profile.getStartDate());

                // Напоминания/будильники
                JSONArray remindersArray = new JSONArray();
                if (profile.getReminders() != null) {
                    for (ReminderModel reminder : profile.getReminders()) {
                        JSONObject reminderJson = new JSONObject();
                        reminderJson.put("time", reminder.getTime());
                        reminderJson.put("text", reminder.getText());
                        remindersArray.put(reminderJson);
                    }
                }
                jsonObject.put("reminders", remindersArray);

                jsonArray.put(jsonObject);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        prefs.edit().putString(KEY_PROFILES, jsonArray.toString()).apply();
    }

    // Загрузка списка профилей из SharedPreferences
    public static List<ProfileModel> loadProfiles(Context context) {
        List<ProfileModel> profiles = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String jsonString = prefs.getString(KEY_PROFILES, null);

        if (jsonString == null || jsonString.isEmpty()) {
            return profiles;
        }

        try {
            JSONArray jsonArray = new JSONArray(jsonString);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String id = jsonObject.optString("id", "");
                String name = jsonObject.optString("name", "");
                int repeatDays = jsonObject.optInt("repeatDays", 1);
                String color = jsonObject.optString("color", "#FF5252");
                String startDate = jsonObject.optString("startDate", null);

                List<ReminderModel> reminders = new ArrayList<>();
                JSONArray remindersArray = jsonObject.optJSONArray("reminders");
                if (remindersArray != null) {
                    for (int j = 0; j < remindersArray.length(); j++) {
                        JSONObject reminderJson = remindersArray.getJSONObject(j);
                        String time = reminderJson.optString("time", "06:00");
                        String text = reminderJson.optString("text", "");
                        reminders.add(new ReminderModel(time, text));
                    }
                }

                ProfileModel profile = new ProfileModel(id, name, repeatDays, color, reminders);
                if (startDate != null && !startDate.equals("null")) {
                    profile.setStartDate(startDate);
                }
                profiles.add(profile);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return profiles;
    }
}

