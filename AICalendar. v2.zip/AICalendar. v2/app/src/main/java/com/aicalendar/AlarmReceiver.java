package com.aicalendar.v2;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "ai_calendar_alarm_channel";

    @Override
    public void onReceive(Context context, Intent intent) {
        int alarmId = intent.getIntExtra("ALARM_ID", 0);
        String title = intent.getStringExtra("TITLE");
        String message = intent.getStringExtra("MESSAGE");
        boolean isPreAlarm = intent.getBooleanExtra("IS_PRE_ALARM", false);
        String ringtoneUri = intent.getStringExtra("RINGTONE_URI");

        if (title == null) title = "Будильник";
        if (message == null) message = "Пора вставать!";

        createNotificationChannel(context);

        Intent activityIntent = new Intent(context, AlarmActivity.class);
        activityIntent.putExtra("TITLE", title);
        activityIntent.putExtra("MESSAGE", message);
        activityIntent.putExtra("ALARM_ID", alarmId);
        activityIntent.putExtra("IS_PRE_ALARM", isPreAlarm);
        activityIntent.putExtra("RINGTONE_URI", ringtoneUri);

        activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
			context,
			alarmId,
			activityIntent,
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
			.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
			.setContentTitle(title)
			.setContentText(message)
			.setPriority(NotificationCompat.PRIORITY_MAX)
			.setCategory(NotificationCompat.CATEGORY_ALARM)
			.setFullScreenIntent(fullScreenPendingIntent, true)
			.setAutoCancel(true);

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(alarmId, builder.build());
        }
    }

    private void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
				CHANNEL_ID,
				"Сигналы будильника",
				NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Уведомления для срабатывания будильников");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}

