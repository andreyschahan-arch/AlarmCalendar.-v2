package com.aicalendar.v2;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        int alarmId = intent.getIntExtra("ALARM_ID", (int) System.currentTimeMillis());
        String title = intent.getStringExtra("TITLE");
        String message = intent.getStringExtra("MESSAGE");
        boolean isPreAlarm = intent.getBooleanExtra("IS_PRE_ALARM", false);
        String ringtoneUri = intent.getStringExtra("RINGTONE_URI");

        if (title == null) title = "Будильник";
        if (message == null) message = "Пора вставать!";

        // 1. ПРЯМОЙ ЗАПУСК ЭКРАНА (Как в рабочей старой версии)
        Intent alarmIntent = new Intent(context, AlarmActivity.class);
        alarmIntent.putExtra("TITLE", title);
        alarmIntent.putExtra("MESSAGE", message);
        alarmIntent.putExtra("ALARM_ID", alarmId);
        alarmIntent.putExtra("IS_PRE_ALARM", isPreAlarm);
        alarmIntent.putExtra("RINGTONE_URI", ringtoneUri);

        alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK 
                             | Intent.FLAG_ACTIVITY_CLEAR_TOP 
                             | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        try {
            context.startActivity(alarmIntent);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 2. ФОНОВОЕ УВЕДОМЛЕНИЕ ДЛЯ ШТОРКИ И ЧАСОВ
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = isPreAlarm ? "pre_alarm_channel_v3" : "main_alarm_channel_v3";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                channelId, 
                isPreAlarm ? "Пре-будильник" : "Основной будильник", 
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setSound(null, null); 
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 500, 200, 500, 200, 500});

            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT;

        PendingIntent pendingIntent = PendingIntent.getActivity(context, alarmId, alarmIntent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setSound(null)
            .setVibrate(new long[]{0, 500, 200, 500, 200, 500})
            .setContentIntent(pendingIntent)
            .setAutoCancel(true);

        if (notificationManager != null) {
            notificationManager.notify(alarmId, builder.build());
        }
    }
}

