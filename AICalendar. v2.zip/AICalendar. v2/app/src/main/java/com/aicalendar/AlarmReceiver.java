package com.aicalendar.v2;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;

import java.util.Calendar;
import java.util.List;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        int alarmId = intent.getIntExtra("ALARM_ID", (int) System.currentTimeMillis());
        String title = intent.getStringExtra("TITLE");
        String message = intent.getStringExtra("MESSAGE");
        boolean isPreAlarm = intent.getBooleanExtra("IS_PRE_ALARM", false);
        String ringtoneUri = intent.getStringExtra("RINGTONE_URI");

        if (title == null) title = "Будильник";
        if (message == null) message = "Пора вставать!";

        if (ringtoneUri == null || ringtoneUri.isEmpty()) {
            Uri defaultUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (defaultUri != null) {
                ringtoneUri = defaultUri.toString();
            }
        }

        Intent alarmIntent = new Intent(context, AlarmActivity.class);
        alarmIntent.putExtra("TITLE", title);
        alarmIntent.putExtra("MESSAGE", message);
        alarmIntent.putExtra("ALARM_ID", alarmId);
        alarmIntent.putExtra("IS_PRE_ALARM", isPreAlarm);
        alarmIntent.putExtra("RINGTONE_URI", ringtoneUri);

        alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
							 | Intent.FLAG_ACTIVITY_CLEAR_TOP
							 | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        // 1. Сначала пробуем мгновенный запуск (как раньше)
        boolean started = false;
        try {
            context.startActivity(alarmIntent);
            started = true;
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 2. Создаём уведомление ВСЕГДА — как страховку и для случая, когда
        // пользователь свернул будильник, но не выключил
        NotificationManager notificationManager =
			(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = isPreAlarm ? "pre_alarm_channel_v3" : "main_alarm_channel_v3";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
				channelId,
				isPreAlarm ? "Пре-будильник" : "Основной будильник",
				NotificationManager.IMPORTANCE_HIGH
            );
            channel.setSound(null, null);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 500, 200, 500, 200, 500});
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);

            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
			? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
			: PendingIntent.FLAG_UPDATE_CURRENT;

        PendingIntent fullScreenPendingIntent =
			PendingIntent.getActivity(context, alarmId, alarmIntent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
			.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
			.setContentTitle(title)
			.setContentText(message)
			.setPriority(NotificationCompat.PRIORITY_MAX)
			.setCategory(NotificationCompat.CATEGORY_ALARM)
			.setSound(null)
			.setVibrate(new long[]{0, 500, 200, 500, 200, 500})
			.setContentIntent(fullScreenPendingIntent)
			.setFullScreenIntent(fullScreenPendingIntent, true)   // <-- ключевая строка
			.setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
			.setOngoing(true)
			.setAutoCancel(false);

        if (notificationManager != null) {
            notificationManager.notify(alarmId, builder.build());
        }
		
		// Автоперепланирование: после срабатывания ставим следующий слот
        rescheduleNext(context, alarmId);
    }
	
	private void rescheduleNext(Context context, int alarmId) {
        // 1. Загружаем все профили
        List<ProfileModel> profiles = ProfileStorage.loadProfiles(context);
        if (profiles == null || profiles.isEmpty()) return;

        // 2. Ищем профиль и напоминание по alarmId
        ProfileModel foundProfile = null;
        ReminderModel foundReminder = null;
        boolean foundIsPre = false;

        for (ProfileModel profile : profiles) {
            if (profile == null || profile.getReminders() == null) continue;

            for (ReminderModel reminder : profile.getReminders()) {
                if (reminder == null || reminder.getTime() == null) continue;

                int mainId = (profile.getId() + reminder.getTime() + "_main").hashCode();
                int preId = (profile.getId() + reminder.getTime() + "_pre").hashCode();

                if (alarmId == mainId) {
                    foundProfile = profile;
                    foundReminder = reminder;
                    foundIsPre = false;
                    break;
                } else if (alarmId == preId) {
                    foundProfile = profile;
                    foundReminder = reminder;
                    foundIsPre = true;
                    break;
                }
            }
            if (foundProfile != null) break;
        }

        if (foundProfile == null || foundReminder == null) return;

        // 3. Считаем следующий слот
        int repeatDays = foundProfile.getRepeatDays() > 0 ? foundProfile.getRepeatDays() : 1;

        String[] timeParts = foundReminder.getTime().split(":");
        if (timeParts.length < 2) return;

        int hour, minute;
        try {
            hour = Integer.parseInt(timeParts[0]);
            minute = Integer.parseInt(timeParts[1]);
        } catch (Exception e) {
            return;
        }

        Calendar now = Calendar.getInstance();

        Calendar nextMain = Calendar.getInstance();
        nextMain.set(Calendar.HOUR_OF_DAY, hour);
        nextMain.set(Calendar.MINUTE, minute);
        nextMain.set(Calendar.SECOND, 0);
        nextMain.set(Calendar.MILLISECOND, 0);

        // Защита: если слот меньше чем через 60 секунд — сдвигаем на полный цикл
        long minAllowed = now.getTimeInMillis() + 60_000L;
        while (nextMain.getTimeInMillis() <= minAllowed) {
            nextMain.add(Calendar.DAY_OF_YEAR, repeatDays);
        }

        AlarmSettings alarmSettings = AlarmSettings.load(context);

        // 4. Перепланируем основной или пре-будильник
        if (foundIsPre) {
            int preAlarmMinutes = alarmSettings.getPreAlarmMinutesBefore();
            Calendar nextPre = (Calendar) nextMain.clone();
            nextPre.add(Calendar.MINUTE, -preAlarmMinutes);

            // Если пре-будильник уже в прошлом — сдвигаем ещё на цикл
            if (nextPre.getTimeInMillis() <= now.getTimeInMillis() + 60_000L) {
                nextPre.add(Calendar.DAY_OF_YEAR, repeatDays);
            }

            int preAlarmId = (foundProfile.getId() + foundReminder.getTime() + "_pre").hashCode();
            String preTitle = "До " + foundProfile.getName() + " осталось " + preAlarmMinutes + " мин";

            AlarmScheduler.scheduleAlarm(
                context,
                nextPre.getTimeInMillis(),
                preAlarmId,
                preTitle,
                foundReminder.getText(),
                true,
                alarmSettings.getPreRingtoneUri()
            );

            // Основной тоже перепланируем, чтобы он не потерялся
            int mainAlarmId = (foundProfile.getId() + foundReminder.getTime() + "_main").hashCode();
            AlarmScheduler.scheduleAlarm(
                context,
                nextMain.getTimeInMillis(),
                mainAlarmId,
                foundProfile.getName(),
                foundReminder.getText(),
                false,
                alarmSettings.getMainRingtoneUri()
            );
        } else {
            int mainAlarmId = (foundProfile.getId() + foundReminder.getTime() + "_main").hashCode();
            AlarmScheduler.scheduleAlarm(
                context,
                nextMain.getTimeInMillis(),
                mainAlarmId,
                foundProfile.getName(),
                foundReminder.getText(),
                false,
                alarmSettings.getMainRingtoneUri()
            );

            // И пре-будильник, если настроен
            int preAlarmMinutes = alarmSettings.getPreAlarmMinutesBefore();
            if (preAlarmMinutes > 0) {
                Calendar nextPre = (Calendar) nextMain.clone();
                nextPre.add(Calendar.MINUTE, -preAlarmMinutes);

                if (nextPre.getTimeInMillis() > now.getTimeInMillis() + 60_000L) {
                    int preAlarmId = (foundProfile.getId() + foundReminder.getTime() + "_pre").hashCode();
                    String preTitle = "До " + foundProfile.getName() + " осталось " + preAlarmMinutes + " мин";

                    AlarmScheduler.scheduleAlarm(
                        context,
                        nextPre.getTimeInMillis(),
                        preAlarmId,
                        preTitle,
                        foundReminder.getText(),
                        true,
                        alarmSettings.getPreRingtoneUri()
                    );
                }
            }
        }
    }
	
}
