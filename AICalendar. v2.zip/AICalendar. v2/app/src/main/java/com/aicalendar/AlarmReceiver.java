package com.aicalendar.v2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        boolean isPreAlarm = intent.getBooleanExtra("IS_PRE_ALARM", false);

        // Читаем сохраненные настройки
        SharedPreferences prefs = context.getSharedPreferences("AlarmSettings", Context.MODE_PRIVATE);
        String ringtoneUri = isPreAlarm 
			? prefs.getString("PRE_RINGTONE_URI", "") 
			: prefs.getString("MAIN_RINGTONE_URI", "");

        // Запускаем полноэкранную Activity будильника
        Intent alarmIntent = new Intent(context, AlarmActivity.class);
        alarmIntent.putExtra("IS_PRE_ALARM", isPreAlarm);
        alarmIntent.putExtra("RINGTONE_URI", ringtoneUri);
        alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK 
							 | Intent.FLAG_ACTIVITY_CLEAR_TOP 
							 | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        context.startActivity(alarmIntent);
    }
}

