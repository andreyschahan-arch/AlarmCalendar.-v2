package com.aicalendar.v2;

import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AlarmActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private int alarmId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Гарантированное удержание экрана во включенном состоянии
        getWindow().addFlags(
			WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
			| WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
			| WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
			| WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }

        alarmId = getIntent().getIntExtra("ALARM_ID", 0);
        boolean isPreAlarm = getIntent().getBooleanExtra("IS_PRE_ALARM", false);
        String title = getIntent().getStringExtra("TITLE");
        String message = getIntent().getStringExtra("MESSAGE");
        if (message == null) {
            message = getIntent().getStringExtra("TEXT");
        }
        String ringtoneUriStr = getIntent().getStringExtra("RINGTONE_URI");

        if (isPreAlarm) {
            setContentView(R.layout.activity_alarm_pre);

            TextView tvPreTitle = findViewById(R.id.tvPreTitle);
            TextView tvPreMessage = findViewById(R.id.tvPreMessage);
            Button btnPreClose = findViewById(R.id.btnPreClose);

            if (tvPreTitle != null && title != null && !title.isEmpty()) {
                tvPreTitle.setText(title);
            }
            if (tvPreMessage != null && message != null) {
                tvPreMessage.setText(message);
            }
            if (btnPreClose != null) {
                btnPreClose.setOnClickListener(v -> stopAndFinish());
            }

        } else {
            setContentView(R.layout.activity_alarm_main);

            TextView tvAlarmStatus = findViewById(R.id.tvAlarmStatus);
            Button btnDismissAlarm = findViewById(R.id.btnDismissAlarm);
            Button btnSnoozeAlarm = findViewById(R.id.btnSnoozeAlarm);
            Button btnSnooze10 = findViewById(R.id.btnSnooze10);
            Button btnSnooze15 = findViewById(R.id.btnSnooze15);

            if (tvAlarmStatus != null && title != null && !title.isEmpty()) {
                tvAlarmStatus.setText(title);
            }

            if (btnDismissAlarm != null) {
                btnDismissAlarm.setOnClickListener(v -> stopAndFinish());
            }
            if (btnSnoozeAlarm != null) {
                btnSnoozeAlarm.setOnClickListener(v -> stopAndFinish());
            }
            if (btnSnooze10 != null) {
                btnSnooze10.setOnClickListener(v -> stopAndFinish());
            }
            if (btnSnooze15 != null) {
                btnSnooze15.setOnClickListener(v -> stopAndFinish());
            }
        }

        startAlarmSoundAndVibration(ringtoneUriStr);
    }

	private void startAlarmSoundAndVibration(String ringtoneUriStr) {
        try {
            Uri soundUri = null;
            if (ringtoneUriStr != null && !ringtoneUriStr.isEmpty()) {
                soundUri = Uri.parse(ringtoneUriStr);
            }
            if (soundUri == null) {
                soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            }
            if (soundUri == null) {
                soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }

            if (mediaPlayer != null) {
                mediaPlayer.release();
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(getApplicationContext(), soundUri);
            mediaPlayer.setAudioAttributes(
				new AudioAttributes.Builder()
				.setUsage(AudioAttributes.USAGE_ALARM)
				.setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
				.build()
            );
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
            // Фолбэк на стандартный сигнал, если выбранный URI не смог проиграться
            try {
                Uri fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (fallbackUri != null) {
                    mediaPlayer = new MediaPlayer();
                    mediaPlayer.setDataSource(getApplicationContext(), fallbackUri);
                    mediaPlayer.setAudioAttributes(
						new AudioAttributes.Builder()
						.setUsage(AudioAttributes.USAGE_ALARM)
						.setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
						.build()
                    );
                    mediaPlayer.setLooping(true);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            long[] pattern = {0, 500, 500};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
            } else {
                vibrator.vibrate(pattern, 0);
            }
        }
    }
	

    private void stopAndFinish() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception ignored) {}
            mediaPlayer = null;
        }

        if (vibrator != null) {
            vibrator.cancel();
        }

        // Удаляем уведомление из шторки
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(alarmId);
        }

        finish();
    }

    @Override
    protected void onDestroy() {
        stopAndFinish();
        super.onDestroy();
    }
}

