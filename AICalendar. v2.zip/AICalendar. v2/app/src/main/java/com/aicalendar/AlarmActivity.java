package com.aicalendar.v2;

import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class AlarmActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private int alarmId = 0;
    private boolean isFinishing = false;
    private boolean isPreAlarm = false;
    private String ringtoneUriStr = "";
    private String currentTitle = "";
    private String currentMessage = "";

    private final Handler snoozeHandler = new Handler(Looper.getMainLooper());

    // Флаг: играет ли сейчас звук, чтобы не перезапускать вибрацию зря
    private boolean isSoundPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            );
        }

        alarmId = getIntent().getIntExtra("ALARM_ID", 0);
        isPreAlarm = getIntent().getBooleanExtra("IS_PRE_ALARM", false);
        currentTitle = getIntent().getStringExtra("TITLE");
        currentMessage = getIntent().getStringExtra("MESSAGE");
        if (currentMessage == null) {
            currentMessage = getIntent().getStringExtra("TEXT");
        }
        ringtoneUriStr = getIntent().getStringExtra("RINGTONE_URI");

        if (isPreAlarm) {
            setContentView(R.layout.activity_alarm_pre);
            TextView tvPreTitle = findViewById(R.id.tvPreTitle);
            TextView tvPreMessage = findViewById(R.id.tvPreMessage);
            Button btnPreClose = findViewById(R.id.btnPreClose);

            if (tvPreTitle != null && currentTitle != null && !currentTitle.isEmpty()) {
                tvPreTitle.setText(currentTitle);
            }
            if (tvPreMessage != null && currentMessage != null) {
                tvPreMessage.setText(currentMessage);
            }
            if (btnPreClose != null) {
                btnPreClose.setOnClickListener(v -> stopAndFinish());
            }
        } else {
            setContentView(R.layout.activity_alarm_main);
            TextView tvAlarmStatus = findViewById(R.id.tvAlarmStatus);
            Button btnDismissAlarm = findViewById(R.id.btnDismissAlarm);
            Button btnSnoozeAlarm = findViewById(R.id.btnSnoozeAlarm);
            Button btnSnooze10 = findViewById(R.id.btnSnooze10);
            Button btnSnooze15 = findViewById(R.id.btnSnooze15);

            if (tvAlarmStatus != null && currentTitle != null && !currentTitle.isEmpty()) {
                tvAlarmStatus.setText(currentTitle);
            }

            // Удержание 2 секунды для кнопки ВЫКЛ
            if (btnDismissAlarm != null) {
                setupHoldToDismiss(btnDismissAlarm);
            }

            // Snooze-кнопки — реально откладывают
            if (btnSnoozeAlarm != null) {
                btnSnoozeAlarm.setOnClickListener(v -> snooze(5));
            }
            if (btnSnooze10 != null) {
                btnSnooze10.setOnClickListener(v -> snooze(10));
            }
            if (btnSnooze15 != null) {
                btnSnooze15.setOnClickListener(v -> snooze(15));
            }
        }

        startAlarmSoundAndVibration();
    }

    // ================== УДЕРЖАНИЕ "ВЫКЛ" ==================
    private void setupHoldToDismiss(Button button) {
        final long holdDuration = 2000L;
        final Handler handler = new Handler(Looper.getMainLooper());
        final boolean[] dismissed = {false};

        final Runnable dismissRunnable = () -> {
            dismissed[0] = true;
            stopAndFinish();
        };

        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dismissed[0] = false;
                    handler.postDelayed(dismissRunnable, holdDuration);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(dismissRunnable);
                    if (!dismissed[0]) {
                        Toast.makeText(AlarmActivity.this,
									   "Удерживайте 2 секунды, чтобы выключить",
									   Toast.LENGTH_SHORT).show();
                    }
                    return true;
            }
            return false;
        });
    }

    // ================== SNOOZE ==================
    private void snooze(int minutes) {
        try {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MINUTE, minutes);

            AlarmScheduler.scheduleAlarm(
                this,
                cal.getTimeInMillis(),
                alarmId,
                currentTitle,
                currentMessage,
                isPreAlarm,
                ringtoneUriStr
            );

            Toast.makeText(this,
						   "Отложено на " + minutes + " мин",
						   Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        stopAndFinish();
    }

    // ================== ЗВУК + ВИБРАЦИЯ ==================
    private void startAlarmSoundAndVibration() {
        AlarmSettings settings = AlarmSettings.load(this);
        int volumePercent = settings.getVolume();
        float volume = Math.max(0f, Math.min(1f, volumePercent / 100f));

        boolean soundStarted = false;

        if (ringtoneUriStr != null && !ringtoneUriStr.isEmpty()) {
            try {
                Uri soundUri = Uri.parse(ringtoneUriStr);

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(getApplicationContext(), soundUri);
                mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
					.setUsage(AudioAttributes.USAGE_ALARM)
					.setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
					.build()
                );
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(volume, volume);
                mediaPlayer.prepare();
                mediaPlayer.start();
                soundStarted = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (!soundStarted) {
            try {
                Uri fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (fallbackUri == null) {
                    fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                }

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(getApplicationContext(), fallbackUri);
                mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
					.setUsage(AudioAttributes.USAGE_ALARM)
					.setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
					.build()
                );
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(volume, volume);
                mediaPlayer.prepare();
                mediaPlayer.start();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        isSoundPlaying = true;
        restartVibration();
    }

    private void restartVibration() {
        if (vibrator == null) {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
        if (vibrator == null || !vibrator.hasVibrator()) return;

        try {
            long[] pattern = {0, 500, 500};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
            } else {
                vibrator.vibrate(pattern, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================== ONRESUME: возврат вибрации ==================
    @Override
    protected void onResume() {
        super.onResume();
        if (isSoundPlaying && !isFinishing) {
            // Если вибрация отменилась системой — перезапускаем
            restartVibration();
        }
    }

    // ================== ЗАВЕРШЕНИЕ ==================
    private void stopAndFinish() {
        if (isFinishing) return;
        isFinishing = true;
        isSoundPlaying = false;

        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception ignored) {}
            mediaPlayer = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
            vibrator = null;
        }
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(alarmId);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        } else {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (!isFinishing) {
            if (mediaPlayer != null) {
                try {
                    if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                    mediaPlayer.release();
                } catch (Exception ignored) {}
                mediaPlayer = null;
            }
            if (vibrator != null) {
                vibrator.cancel();
                vibrator = null;
            }
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(alarmId);
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (isPreAlarm) {
            stopAndFinish();
        } else {
            Toast.makeText(this,
						   "Нажмите и удерживайте «ВЫКЛ», чтобы отключить",
						   Toast.LENGTH_SHORT).show();
        }
    }
}
