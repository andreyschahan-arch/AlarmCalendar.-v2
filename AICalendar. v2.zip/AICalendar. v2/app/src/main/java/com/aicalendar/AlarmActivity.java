package com.aicalendar.v2;

import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AlarmActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private Handler holdHandler = new Handler(Looper.getMainLooper());
    private Runnable stopAlarmRunnable;
    private static final long HOLD_DURATION_MS = 3000;

    private int alarmId;
    private String title;
    private String message;
    private boolean isPreAlarm;
    private String ringtoneUriStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
				WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
				WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
				WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            );
        }

        alarmId = getIntent().getIntExtra("ALARM_ID", 0);
        title = getIntent().getStringExtra("TITLE");
        message = getIntent().getStringExtra("MESSAGE");
        isPreAlarm = getIntent().getBooleanExtra("IS_PRE_ALARM", false);
        ringtoneUriStr = getIntent().getStringExtra("RINGTONE_URI");

        if (isPreAlarm) {
            setContentView(R.layout.activity_alarm_pre);
            setupPreAlarmUI();
        } else {
            setContentView(R.layout.activity_alarm_main);
            setupMainAlarmUI();
        }

        startRingtoneAndVibration();
    }

    private void setupPreAlarmUI() {
        TextView tvPreTitle = findViewById(R.id.tvPreTitle);
        TextView tvPreMessage = findViewById(R.id.tvPreMessage);
        Button btnPreClose = findViewById(R.id.btnPreClose);

        if (tvPreTitle != null && title != null) tvPreTitle.setText(title);
        if (tvPreMessage != null && message != null) tvPreMessage.setText(message);

        if (btnPreClose != null) {
            btnPreClose.setOnClickListener(v -> stopAndFinish());
        }
    }

    private void setupMainAlarmUI() {
        TextView tvStatus = findViewById(R.id.tvAlarmStatus);
        Button btnDismiss = findViewById(R.id.btnDismissAlarm);

        Button btnSnooze5 = findViewById(R.id.btnSnoozeAlarm);
        Button btnSnooze10 = findViewById(R.id.btnSnooze10);
        Button btnSnooze15 = findViewById(R.id.btnSnooze15);

        if (tvStatus != null) {
            String fullText = (title != null ? title : "ПОДЪЁМ!");
            if (message != null && !message.isEmpty()) {
                fullText += "\n" + message;
            }
            tvStatus.setText(fullText);
        }

        stopAlarmRunnable = () -> {
            Toast.makeText(AlarmActivity.this, "Будильник выключен", Toast.LENGTH_SHORT).show();
            stopAndFinish();
        };

        if (btnDismiss != null) {
            btnDismiss.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        holdHandler.postDelayed(stopAlarmRunnable, HOLD_DURATION_MS);
                        v.setPressed(true);
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        holdHandler.removeCallbacks(stopAlarmRunnable);
                        v.setPressed(false);
                        return true;
                }
                return false;
            });
        }

        if (btnSnooze5 != null) btnSnooze5.setOnClickListener(v -> snoozeAlarm(5));
        if (btnSnooze10 != null) btnSnooze10.setOnClickListener(v -> snoozeAlarm(10));
        if (btnSnooze15 != null) btnSnooze15.setOnClickListener(v -> snoozeAlarm(15));
    }

    private void snoozeAlarm(int minutes) {
        long triggerAtMillis = System.currentTimeMillis() + (minutes * 60 * 1000);
        AlarmScheduler.scheduleAlarm(
			this,
			triggerAtMillis,
			alarmId + 999,
			title,
			message + " (Отложено)",
			false
        );

        Toast.makeText(this, "Отложено на " + minutes + " мин", Toast.LENGTH_SHORT).show();
        stopAndFinish();
    }

    private void startRingtoneAndVibration() {
        try {
            Uri alarmUri = null;
            if (ringtoneUriStr != null && !ringtoneUriStr.isEmpty()) {
                alarmUri = Uri.parse(ringtoneUriStr);
            } else {
                alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(this, alarmUri);
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
										   .setUsage(AudioAttributes.USAGE_ALARM)
										   .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
										   .build());
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            long[] pattern = {0, 500, 500};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
            } else {
                vibrator.vibrate(pattern, 0);
            }
        }
    }

    private void stopAndFinish() {
        holdHandler.removeCallbacksAndMessages(null);

        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
        }

        // Очищаем уведомление из шторки, чтобы не висело и не запускало повторно
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(alarmId);
        }

        finishAndRemoveTask(); // Полностью закрываем экран и убираем из списка недавних
    }

    @Override
    protected void onDestroy() {
        stopAndFinish();
        super.onDestroy();
    }
}

