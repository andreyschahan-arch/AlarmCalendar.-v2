package com.aicalendar.v2;

import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class AlarmActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private int alarmId = 0;
    private boolean isFinishing = false;
    private boolean isPreAlarm = false;
    private String ringtoneUriStr = "";
    private String currentTitle = "";
    private String currentMessage = "";

    // Тайминги
    private static final long PRE_ALARM_DURATION_MS = 15_000L;   // 15 секунд для пре-будильника
    private static final long MAIN_SIGNAL_DURATION_MS = 60_000L; // 60 секунд для основного

    // Логика повторов
    private int repeatCount = 1;            // сколько раз повторить сигнал
    private long repeatIntervalMs = 0;      // пауза между сигналами (мс)
    private int currentRepeatIndex = 0;     // какой цикл сейчас

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable stopSignalRunnable;    // остановить звук+вибрацию (60 сек или 15 сек)
    private Runnable nextSignalRunnable;    // запустить следующий цикл

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            );
        }

        alarmId = getIntent().getIntExtra("ALARM_ID", 0);
        isPreAlarm = getIntent().getBooleanExtra("IS_PRE_ALARM", false);
        currentTitle = getIntent().getStringExtra("TITLE");
        currentMessage = getIntent().getStringExtra("MESSAGE");
        if (currentMessage == null) {
            currentMessage = getIntent().getStringExtra("TEXT");
        }
        ringtoneUriStr = getIntent().getStringExtra("RINGTONE_URI");

        // Загружаем настройки повторов
        AlarmSettings settings = AlarmSettings.load(this);
        repeatCount = Math.max(1, settings.getRepeatCount());
        repeatIntervalMs = Math.max(1, settings.getRepeatIntervalMinutes()) * 60_000L;

        if (isPreAlarm) {
            setContentView(R.layout.activity_alarm_pre);
            TextView tvPreTitle = findViewById(R.id.tvPreTitle);
            TextView tvPreMessage = findViewById(R.id.tvPreMessage);
            Button btnPreClose = findViewById(R.id.btnPreClose);

            if (tvPreTitle != null && currentTitle != null && !currentTitle.isEmpty()) {
                tvPreTitle.setText(currentTitle);
            }
            if (tvPreMessage != null && currentMessage != null) {
                tvPreMessage.setText(currentMessage);
            }
            if (btnPreClose != null) {
                btnPreClose.setOnClickListener(v -> stopAndFinish());
            }
        } else {
            setContentView(R.layout.activity_alarm_main);
            TextView tvAlarmStatus = findViewById(R.id.tvAlarmStatus);
            Button btnDismissAlarm = findViewById(R.id.btnDismissAlarm);
            Button btnSnoozeAlarm = findViewById(R.id.btnSnoozeAlarm);
            Button btnSnooze10 = findViewById(R.id.btnSnooze10);
            Button btnSnooze15 = findViewById(R.id.btnSnooze15);

            if (tvAlarmStatus != null && currentTitle != null && !currentTitle.isEmpty()) {
                tvAlarmStatus.setText(currentTitle);
            }

            if (btnDismissAlarm != null) {
                setupHoldToDismiss(btnDismissAlarm);
            }

            if (btnSnoozeAlarm != null) {
                btnSnoozeAlarm.setOnClickListener(v -> snooze(5));
            }
            if (btnSnooze10 != null) {
                btnSnooze10.setOnClickListener(v -> snooze(10));
            }
            if (btnSnooze15 != null) {
                btnSnooze15.setOnClickListener(v -> snooze(15));
            }
        }

        // Запускаем цикл сигналов
        startSignalCycle();
    }

    // ================== ЦИКЛ СИГНАЛОВ ==================
    private void startSignalCycle() {
        if (isPreAlarm) {
            // Пре-будильник: один раз, 15 секунд, без вибрации
            playPreAlarmSignal();
            return;
        }

        // Основной: цикл repeatCount раз
        currentRepeatIndex = 0;
        playMainSignalOnce();
    }

    private void playPreAlarmSignal() {
        playSound(true);

        stopSignalRunnable = () -> {
            stopSoundAndVibration();
            stopAndFinish();
        };
        handler.postDelayed(stopSignalRunnable, PRE_ALARM_DURATION_MS);
    }

    private void playMainSignalOnce() {
        currentRepeatIndex++;

        // Играем звук + вибрацию
        playSound(false);
        startVibration();

        // Через 60 сек — гасим сигнал
        stopSignalRunnable = () -> {
            stopSoundAndVibration();

            // Если ещё есть циклы — пауза и следующий
            if (currentRepeatIndex < repeatCount) {
                nextSignalRunnable = () -> playMainSignalOnce();
                handler.postDelayed(nextSignalRunnable, repeatIntervalMs);
            } else {
                // Циклы кончились — закрываемся
                stopAndFinish();
            }
        };
        handler.postDelayed(stopSignalRunnable, MAIN_SIGNAL_DURATION_MS);
    }

    // ================== ЗВУК ==================
    private void playSound(boolean isPre) {
        AlarmSettings settings = AlarmSettings.load(this);
        int volumePercent = settings.getVolume();
        float volume = Math.max(0f, Math.min(1f, volumePercent / 100f));

        boolean started = false;

        if (ringtoneUriStr != null && !ringtoneUriStr.isEmpty()) {
            try {
                Uri soundUri = Uri.parse(ringtoneUriStr);

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(getApplicationContext(), soundUri);
                mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
					.setUsage(AudioAttributes.USAGE_ALARM)
					.setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
					.build()
                );
                mediaPlayer.setLooping(true); // играем в цикле до остановки по таймеру
                mediaPlayer.setVolume(volume, volume);
                mediaPlayer.prepare();
                mediaPlayer.start();
                started = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (!started) {
            try {
                Uri fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (fallbackUri == null) {
                    fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                }

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(getApplicationContext(), fallbackUri);
                mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
					.setUsage(AudioAttributes.USAGE_ALARM)
					.setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
					.build()
                );
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(volume, volume);
                mediaPlayer.prepare();
                mediaPlayer.start();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void stopSound() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception ignored) {}
            mediaPlayer = null;
        }
    }

    private void stopSoundAndVibration() {
        stopSound();
        stopVibration();
    }

    // ================== ВИБРАЦИЯ ==================
    private void startVibration() {
        if (vibrator == null) {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
        if (vibrator == null || !vibrator.hasVibrator()) return;

        try {
            long[] pattern = {0, 500, 500};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
            } else {
                vibrator.vibrate(pattern, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopVibration() {
        if (vibrator != null) {
            vibrator.cancel();
        }
    }

    // ================== ONRESUME: перезапуск вибрации ==================
    @Override
    protected void onResume() {
        super.onResume();
        // Возобновляем вибрацию, если идёт активный сигнал основного будильника
        if (!isFinishing && !isPreAlarm && mediaPlayer != null && mediaPlayer.isPlaying()) {
            startVibration();
        }
    }

    // ================== УДЕРЖАНИЕ "ВЫКЛ" ==================
    private void setupHoldToDismiss(Button button) {
        final long holdDuration = 2000L;
        final Handler localHandler = new Handler(Looper.getMainLooper());
        final boolean[] dismissed = {false};

        final Runnable dismissRunnable = () -> {
            dismissed[0] = true;
            stopAndFinish();
        };

        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dismissed[0] = false;
                    localHandler.postDelayed(dismissRunnable, holdDuration);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    localHandler.removeCallbacks(dismissRunnable);
                    if (!dismissed[0]) {
                        Toast.makeText(AlarmActivity.this,
									   "Удерживайте 2 секунды, чтобы выключить",
									   Toast.LENGTH_SHORT).show();
                    }
                    return true;
            }
            return false;
        });
    }

    // ================== SNOOZE ==================
    private void snooze(int minutes) {
        try {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MINUTE, minutes);

            AlarmScheduler.scheduleAlarm(
                this,
                cal.getTimeInMillis(),
                alarmId,
                currentTitle,
                currentMessage,
                isPreAlarm,
                ringtoneUriStr
            );

            Toast.makeText(this,
						   "Отложено на " + minutes + " мин",
						   Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        stopAndFinish();
    }

    // ================== ЗАВЕРШЕНИЕ ==================
    private void stopAndFinish() {
        if (isFinishing) return;
        isFinishing = true;

        handler.removeCallbacksAndMessages(null);
        stopSoundAndVibration();

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(alarmId);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        } else {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (!isFinishing) {
            handler.removeCallbacksAndMessages(null);
            stopSoundAndVibration();
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(alarmId);
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (isPreAlarm) {
            stopAndFinish();
        } else {
            Toast.makeText(this,
						   "Нажмите и удерживайте «ВЫКЛ», чтобы отключить",
						   Toast.LENGTH_SHORT).show();
        }
    }
}
