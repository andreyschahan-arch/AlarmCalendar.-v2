package com.aicalendar.v2;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AlarmActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private int alarmId = 0;
    private boolean isFinishing = false;
    private boolean isPreAlarm = false;
    private String ringtoneUriStr = "";
    private String currentTitle = "";
    private String currentMessage = "";

    // Тайминги
    private static final long PRE_ALARM_DURATION_MS = 15_000L;
    private static final long MAIN_SIGNAL_DURATION_MS = 60_000L;
    private static final long LOCK_FLAGS_REFRESH_MS = 5_000L;
    private static final long HOLD_DURATION_MS = 2_000L;

    // Логика повторов
    private int repeatCount = 1;
    private long repeatIntervalMs = 0;
    private int currentCycleIndex = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable stopSignalRunnable;
    private Runnable lockFlagsRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        applyLockFlags();

        alarmId = getIntent().getIntExtra("ALARM_ID", 0);
        isPreAlarm = getIntent().getBooleanExtra("IS_PRE_ALARM", false);
        currentTitle = getIntent().getStringExtra("TITLE");
        currentMessage = getIntent().getStringExtra("MESSAGE");
        if (currentMessage == null) {
            currentMessage = getIntent().getStringExtra("TEXT");
        }
        ringtoneUriStr = getIntent().getStringExtra("RINGTONE_URI");
        currentCycleIndex = getIntent().getIntExtra("CYCLE_INDEX", 0);

        AlarmSettings settings = AlarmSettings.load(this);
        repeatCount = Math.max(1, settings.getRepeatCount());
        repeatIntervalMs = Math.max(1, settings.getRepeatIntervalMinutes()) * 60_000L;

        if (isPreAlarm) {
            setContentView(R.layout.activity_alarm_pre);
            showPreAlarmContent();
        } else {
            setContentView(R.layout.activity_alarm_main);
            showMainAlarmContent();
        }

        startSignalCycle();
        startLockFlagsRefresh();
    }

    // ================== РАСКЛАДКА ТЕКСТА ДЛЯ ПРЕ-БУДИЛЬНИКА ==================
    private void showPreAlarmContent() {
        TextView tvPreProfileName = findViewById(R.id.tvPreProfileName);
        TextView tvPreMessageTitle = findViewById(R.id.tvPreMessageTitle);
        TextView tvPreMessageCountdown = findViewById(R.id.tvPreMessageCountdown);
        Button btnPreClose = findViewById(R.id.btnPreClose);

        // currentTitle обычно: "До 2 Выходной день осталось 5 мин"
        // currentMessage обычно: "Тест" (текст напоминания)
        // Разбираем currentTitle на две части по слову "осталось"

        String profileNameForTop = "";
        String titleLine = currentTitle != null ? currentTitle : "";
        String countdownLine = "";

        if (titleLine.contains("осталось")) {
            int idx = titleLine.lastIndexOf("осталось");
            String before = titleLine.substring(0, idx).trim(); // "До 2 Выходной день"
            String after = titleLine.substring(idx).trim();    // "осталось 5 мин"

            // Отрезаем ведущее "До ", чтобы получить название профиля
            if (before.startsWith("До ")) {
                profileNameForTop = before.substring(3).trim();
            } else {
                profileNameForTop = before;
            }
            countdownLine = after;
        } else {
            // Если формат другой — просто показываем как есть
            profileNameForTop = "";
            countdownLine = titleLine;
        }

        if (tvPreProfileName != null) {
            tvPreProfileName.setText(profileNameForTop);
        }

        if (tvPreMessageTitle != null) {
            String msg = (currentMessage != null && !currentMessage.isEmpty())
                ? currentMessage
                : "Напоминание";
            tvPreMessageTitle.setText("До " + msg);
        }

        if (tvPreMessageCountdown != null) {
            tvPreMessageCountdown.setText(countdownLine);
        }

        if (btnPreClose != null) {
            btnPreClose.setOnClickListener(v -> stopAndFinish());
        }
    }

    // ================== РАСКЛАДКА ТЕКСТА ДЛЯ ОСНОВНОГО БУДИЛЬНИКА ==================
    private void showMainAlarmContent() {
        TextView tvAlarmStatus = findViewById(R.id.tvAlarmStatus);
        Button btnDismissAlarm = findViewById(R.id.btnDismissAlarm);
        Button btnSnoozeAlarm = findViewById(R.id.btnSnoozeAlarm);
        Button btnSnooze10 = findViewById(R.id.btnSnooze10);
        Button btnSnooze15 = findViewById(R.id.btnSnooze15);

        if (tvAlarmStatus != null && currentTitle != null && !currentTitle.isEmpty()) {
            tvAlarmStatus.setText(currentTitle);
        }

        if (btnDismissAlarm != null) {
            setupHoldToDismiss(btnDismissAlarm);
        }

        if (btnSnoozeAlarm != null) {
            btnSnoozeAlarm.setOnClickListener(v -> snooze(5));
        }
        if (btnSnooze10 != null) {
            btnSnooze10.setOnClickListener(v -> snooze(10));
        }
        if (btnSnooze15 != null) {
            btnSnooze15.setOnClickListener(v -> snooze(15));
        }
    }

    // ================== УДЕРЖАНИЕ ОКНА ПОВЕРХ БЛОКИРОВКИ ==================
    private void applyLockFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            );
        }
    }

    private void startLockFlagsRefresh() {
        lockFlagsRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing) return;
                applyLockFlags();
                handler.postDelayed(this, LOCK_FLAGS_REFRESH_MS);
            }
        };
        handler.postDelayed(lockFlagsRunnable, LOCK_FLAGS_REFRESH_MS);
    }

    // ================== ЦИКЛ СИГНАЛОВ ==================
    private void startSignalCycle() {
        if (isPreAlarm) {
            playPreAlarmSignal();
            return;
        }
        playMainSignalOnce();
    }

    private void playPreAlarmSignal() {
        playSound();
        stopSignalRunnable = () -> {
            stopSoundAndVibration();
            stopAndFinish();
        };
        handler.postDelayed(stopSignalRunnable, PRE_ALARM_DURATION_MS);
    }

    private void playMainSignalOnce() {
        playSound();
        startVibration();

        stopSignalRunnable = () -> {
            stopSoundAndVibration();

            if (currentCycleIndex + 1 < repeatCount) {
                scheduleNextCycle();
                stopAndFinish();
            } else {
                scheduleNextRegularAlarm();
                stopAndFinish();
            }
        };
        handler.postDelayed(stopSignalRunnable, MAIN_SIGNAL_DURATION_MS);
    }

    private void scheduleNextCycle() {
        try {
            Calendar next = Calendar.getInstance();
            next.add(Calendar.MINUTE, (int)(repeatIntervalMs / 60_000L));

            Intent intent = new Intent(this, AlarmActivity.class);
            intent.putExtra("TITLE", currentTitle);
            intent.putExtra("MESSAGE", currentMessage);
            intent.putExtra("ALARM_ID", alarmId);
            intent.putExtra("IS_PRE_ALARM", isPreAlarm);
            intent.putExtra("RINGTONE_URI", ringtoneUriStr);
            intent.putExtra("CYCLE_INDEX", currentCycleIndex + 1);

            AlarmScheduler.scheduleAlarm(
                this,
                next.getTimeInMillis(),
                alarmId,
                currentTitle,
                currentMessage,
                isPreAlarm,
                ringtoneUriStr
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void scheduleNextRegularAlarm() {
        try {
            List<ProfileModel> profiles = ProfileStorage.loadProfiles(this);
            if (profiles == null || profiles.isEmpty()) return;

            ProfileModel foundProfile = null;
            ReminderModel foundReminder = null;

            for (ProfileModel profile : profiles) {
                if (profile == null || profile.getReminders() == null) continue;
                for (ReminderModel reminder : profile.getReminders()) {
                    if (reminder == null || reminder.getTime() == null) continue;

                    int mainId = (profile.getId() + reminder.getTime() + "_main").hashCode();
                    int preId = (profile.getId() + reminder.getTime() + "_pre").hashCode();

                    if (alarmId == mainId || alarmId == preId) {
                        foundProfile = profile;
                        foundReminder = reminder;
                        break;
                    }
                }
                if (foundProfile != null) break;
            }

            if (foundProfile == null || foundReminder == null) return;

            int repeatDays = foundProfile.getRepeatDays() > 0 ? foundProfile.getRepeatDays() : 1;

            String[] timeParts = foundReminder.getTime().split(":");
            if (timeParts.length < 2) return;

            int hour, minute;
            try {
                hour = Integer.parseInt(timeParts[0]);
                minute = Integer.parseInt(timeParts[1]);
            } catch (Exception e) {
                return;
            }

            Calendar now = Calendar.getInstance();
            Calendar nextMain = Calendar.getInstance();
            nextMain.set(Calendar.HOUR_OF_DAY, hour);
            nextMain.set(Calendar.MINUTE, minute);
            nextMain.set(Calendar.SECOND, 0);
            nextMain.set(Calendar.MILLISECOND, 0);

            long minAllowed = now.getTimeInMillis() + 60_000L;
            while (nextMain.getTimeInMillis() <= minAllowed) {
                nextMain.add(Calendar.DAY_OF_YEAR, repeatDays);
            }

            AlarmSettings alarmSettings = AlarmSettings.load(this);

            int mainAlarmId = (foundProfile.getId() + foundReminder.getTime() + "_main").hashCode();
            AlarmScheduler.scheduleAlarm(
                this,
                nextMain.getTimeInMillis(),
                mainAlarmId,
                foundProfile.getName(),
                foundReminder.getText(),
                false,
                alarmSettings.getMainRingtoneUri()
            );

            int preAlarmMinutes = alarmSettings.getPreAlarmMinutesBefore();
            if (preAlarmMinutes > 0) {
                Calendar nextPre = (Calendar) nextMain.clone();
                nextPre.add(Calendar.MINUTE, -preAlarmMinutes);

                if (nextPre.getTimeInMillis() > now.getTimeInMillis() + 60_000L) {
                    int preAlarmId = (foundProfile.getId() + foundReminder.getTime() + "_pre").hashCode();
                    String preTitle = "До " + foundProfile.getName() + " осталось " + preAlarmMinutes + " мин";

                    AlarmScheduler.scheduleAlarm(
                        this,
                        nextPre.getTimeInMillis(),
                        preAlarmId,
                        preTitle,
                        foundReminder.getText(),
                        true,
                        alarmSettings.getPreRingtoneUri()
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================== ЗВУК ==================
    private void playSound() {
        AlarmSettings settings = AlarmSettings.load(this);
        int volumePercent = settings.getVolume();
        float volume = Math.max(0f, Math.min(1f, volumePercent / 100f));

        boolean started = false;

        if (ringtoneUriStr != null && !ringtoneUriStr.isEmpty()) {
            try {
                Uri soundUri = Uri.parse(ringtoneUriStr);

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(getApplicationContext(), soundUri);
                mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                );
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(volume, volume);
                mediaPlayer.prepare();
                mediaPlayer.start();
                started = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (!started) {
            try {
                Uri fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (fallbackUri == null) {
                    fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                }

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(getApplicationContext(), fallbackUri);
                mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                );
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(volume, volume);
                mediaPlayer.prepare();
                mediaPlayer.start();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void stopSound() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception ignored) {}
            mediaPlayer = null;
        }
    }

    private void stopSoundAndVibration() {
        stopSound();
        stopVibration();
    }

    // ================== ВИБРАЦИЯ ==================
    private void startVibration() {
        if (isPreAlarm) return;

        if (vibrator == null) {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
        if (vibrator == null || !vibrator.hasVibrator()) return;

        try {
            long[] pattern = {0, 500, 500};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
            } else {
                vibrator.vibrate(pattern, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopVibration() {
        if (vibrator != null) {
            vibrator.cancel();
        }
    }

    // ================== ONRESUME ==================
    @Override
    protected void onResume() {
        super.onResume();
        if (!isFinishing && !isPreAlarm && mediaPlayer != null && mediaPlayer.isPlaying()) {
            startVibration();
        }
    }

    // ================== УДЕРЖАНИЕ "ВЫКЛ" (без анимации) ==================
    private void setupHoldToDismiss(Button button) {
        final Handler localHandler = new Handler(Looper.getMainLooper());
        final boolean[] dismissed = {false};

        final Runnable dismissRunnable = () -> {
            dismissed[0] = true;
            stopAndFinish();
        };

        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dismissed[0] = false;
                    localHandler.postDelayed(dismissRunnable, HOLD_DURATION_MS);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    localHandler.removeCallbacks(dismissRunnable);
                    if (!dismissed[0]) {
                        Toast.makeText(AlarmActivity.this,
                                       "Удерживайте 2 секунды, чтобы выключить",
                                       Toast.LENGTH_SHORT).show();
                    }
                    return true;
            }
            return false;
        });
    }

    // ================== SNOOZE ==================
    private void snooze(int minutes) {
        try {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MINUTE, minutes);

            AlarmScheduler.scheduleAlarm(
                this,
                cal.getTimeInMillis(),
                alarmId,
                currentTitle,
                currentMessage,
                isPreAlarm,
                ringtoneUriStr
            );

            Toast.makeText(this,
                           "Отложено на " + minutes + " мин",
                           Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        stopAndFinish();
    }

    // ================== ЗАВЕРШЕНИЕ ==================
    private void stopAndFinish() {
        if (isFinishing) return;
        isFinishing = true;

        handler.removeCallbacksAndMessages(null);
        stopSoundAndVibration();
        WidgetProvider.refreshAll(this);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(alarmId);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        } else {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (!isFinishing) {
            handler.removeCallbacksAndMessages(null);
            stopSoundAndVibration();
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(alarmId);
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (isPreAlarm) {
            stopAndFinish();
        } else {
            Toast.makeText(this,
                           "Нажмите и удерживайте «ВЫКЛ», чтобы отключить",
                           Toast.LENGTH_SHORT).show();
        }
    }
}
