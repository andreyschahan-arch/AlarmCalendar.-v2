package com.aicalendar.v2;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;

import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AlarmActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Разрешаем отображение поверх замка экрана
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            );
        }

        setContentView(R.layout.activity_alarm);

        boolean isPreAlarm = getIntent().getBooleanExtra("IS_PRE_ALARM", false);
        String ringtoneUriStr = getIntent().getStringExtra("RINGTONE_URI");

        TextView tvStatus = findViewById(R.id.tvAlarmStatus);
        tvStatus.setText(isPreAlarm ? "ПРЕ-БУДИЛЬНИК" : "ПОДЪЁМ!");

        Button btnDismiss = findViewById(R.id.btnDismissAlarm);
        Button btnSnooze = findViewById(R.id.btnSnoozeAlarm);

        btnDismiss.setOnClickListener(v -> stopAndFinish());
        btnSnooze.setOnClickListener(v -> {
            // Логика «Отложить» (перезапуск через N минут из SharedPreferences)
            stopAndFinish();
        });

        startRingtoneAndVibration(ringtoneUriStr);
    }

    private void startRingtoneAndVibration(String uriStr) {
        try {
            if (uriStr != null && !uriStr.isEmpty()) {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(this, Uri.parse(uriStr));
                mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
											   .setUsage(AudioAttributes.USAGE_ALARM)
											   .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
											   .build());
                mediaPlayer.setLooping(true);
                mediaPlayer.prepare();
                mediaPlayer.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            long[] pattern = {0, 500, 500};
            vibrator.vibrate(pattern, 0);
        }
    }

    private void stopAndFinish() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        stopAndFinish();
        super.onDestroy();
    }
}

