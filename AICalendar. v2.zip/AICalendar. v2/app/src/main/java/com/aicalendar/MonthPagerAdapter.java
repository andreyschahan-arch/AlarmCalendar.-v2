package com.aicalendar.v2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MonthPagerAdapter extends RecyclerView.Adapter<MonthPagerAdapter.MonthViewHolder> {

    public static final int START_POSITION = 1000; // Стартовая позиция (центр)

    @NonNull
    @Override
    public MonthViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.page_month, parent, false);
        return new MonthViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MonthViewHolder holder, int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - START_POSITION);

        List<DayModel> days = generateDaysForMonth(cal);

        holder.recyclerView.setLayoutManager(new GridLayoutManager(holder.itemView.getContext(), 7));
        holder.recyclerView.setAdapter(new DayAdapter(days));
    }

    @Override
    public int getItemCount() {
        return START_POSITION * 2; // Достаточно большое число для виртуально бесконечной прокрутки
    }

    private List<DayModel> generateDaysForMonth(Calendar targetCal) {
        List<DayModel> daysList = new ArrayList<>();
        Calendar cal = (Calendar) targetCal.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
        if (firstDayOfWeek < 0) firstDayOfWeek += 7;

        // 1. Дни предыдущего месяца
        Calendar prevCal = (Calendar) cal.clone();
        prevCal.add(Calendar.MONTH, -1);
        int maxDaysInPrevMonth = prevCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = firstDayOfWeek - 1; i >= 0; i--) {
            daysList.add(new DayModel(String.valueOf(maxDaysInPrevMonth - i), false));
        }

        // 2. Дни текущего месяца
        int maxDayInCurrent = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDayInCurrent; i++) {
            daysList.add(new DayModel(String.valueOf(i), true));
        }

        // 3. Дни следующего месяца (всегда 42 ячейки)
        int nextDaysNeed = 42 - daysList.size();
        for (int i = 1; i <= nextDaysNeed; i++) {
            daysList.add(new DayModel(String.valueOf(i), false));
        }

        return daysList;
    }

    static class MonthViewHolder extends RecyclerView.ViewHolder {
        RecyclerView recyclerView;

        public MonthViewHolder(@NonNull View itemView) {
            super(itemView);
            recyclerView = itemView.findViewById(R.id.monthRecyclerView);
        }
    }
}

