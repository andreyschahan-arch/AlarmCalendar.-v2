package com.aicalendar.v2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MonthPagerAdapter extends RecyclerView.Adapter<MonthPagerAdapter.MonthViewHolder> {

    public static final int START_POSITION = 1000;
    private List<ProfileModel> profileList;

    public MonthPagerAdapter(List<ProfileModel> profileList) {
        this.profileList = profileList;
    }

    public void updateProfiles(List<ProfileModel> profileList) {
        this.profileList = profileList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MonthViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.page_month, parent, false);
        return new MonthViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MonthViewHolder holder, int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - START_POSITION);

        List<DayModel> days = generateDaysForMonth(cal);

        holder.recyclerView.setLayoutManager(new GridLayoutManager(holder.itemView.getContext(), 7));

        // Передаем profileList в DayAdapter
        holder.recyclerView.setAdapter(new DayAdapter(days, profileList, day -> {
            Context context = holder.itemView.getContext();
            if (day.getDate() != null && context instanceof MainActivity) {
                ((MainActivity) context).openDayDetails(day.getDate());
            }
        }));
    }

    @Override
    public int getItemCount() {
        return START_POSITION * 2;
    }

    private List<DayModel> generateDaysForMonth(Calendar targetCal) {
        List<DayModel> daysList = new ArrayList<>();
        Calendar cal = (Calendar) targetCal.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
        if (firstDayOfWeek < 0) firstDayOfWeek += 7;

        // 1. Дни предыдущего месяца
        Calendar prevCal = (Calendar) cal.clone();
        prevCal.add(Calendar.MONTH, -1);
        int maxDaysInPrevMonth = prevCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = firstDayOfWeek - 1; i >= 0; i--) {
            Calendar dayCal = (Calendar) prevCal.clone();
            int dayNum = maxDaysInPrevMonth - i;
            dayCal.set(Calendar.DAY_OF_MONTH, dayNum);
            daysList.add(new DayModel(String.valueOf(dayNum), false, dayCal.getTime()));
        }

        // 2. Дни текущего месяца
        int maxDayInCurrent = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDayInCurrent; i++) {
            Calendar dayCal = (Calendar) cal.clone();
            dayCal.set(Calendar.DAY_OF_MONTH, i);
            daysList.add(new DayModel(String.valueOf(i), true, dayCal.getTime()));
        }

        // 3. Дни следующего месяца
        Calendar nextCal = (Calendar) cal.clone();
        nextCal.add(Calendar.MONTH, 1);
        int nextDaysNeed = 42 - daysList.size();
        for (int i = 1; i <= nextDaysNeed; i++) {
            Calendar dayCal = (Calendar) nextCal.clone();
            dayCal.set(Calendar.DAY_OF_MONTH, i);
            daysList.add(new DayModel(String.valueOf(i), false, dayCal.getTime()));
        }

        return daysList;
    }

    static class MonthViewHolder extends RecyclerView.ViewHolder {
        RecyclerView recyclerView;

        public MonthViewHolder(@NonNull View itemView) {
            super(itemView);
            recyclerView = itemView.findViewById(R.id.monthRecyclerView);
        }
    }
}

