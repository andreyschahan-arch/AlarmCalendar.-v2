package com.aicalendar.v2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MonthPagerAdapter extends RecyclerView.Adapter<MonthPagerAdapter.MonthViewHolder> {

    public static final int START_POSITION = 1000;
    private List<ProfileModel> profileList;

    public MonthPagerAdapter(List<ProfileModel> profileList) {
        this.profileList = profileList;
    }

    public void updateProfiles(List<ProfileModel> profileList) {
        this.profileList = profileList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MonthViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.page_month, parent, false);
        return new MonthViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MonthViewHolder holder, int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - START_POSITION);

        List<DayModel> days = generateDaysForMonth(cal);

        if (holder.recyclerView.getLayoutManager() == null) {
            holder.recyclerView.setLayoutManager(new GridLayoutManager(holder.itemView.getContext(), 7));
        }

        if (!holder.listenerAttached) {
            holder.listenerAttached = true;

            holder.recyclerView.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
                recalcCellHeight(holder);
            });

            holder.recyclerView.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        recalcCellHeight(holder);
                    }
                }
            );

            holder.recyclerView.post(() -> recalcCellHeight(holder));
        }

        if (holder.dayAdapter == null) {
            holder.dayAdapter = new DayAdapter(days, profileList, holder.cellHeight, day -> {
                Context context = holder.itemView.getContext();
                if (day.getDate() != null && context instanceof MainActivity) {
                    ((MainActivity) context).openDayDetails(day.getDate());
                }
            });
            holder.recyclerView.setAdapter(holder.dayAdapter);
        } else {
            holder.dayAdapter.updateData(days, profileList);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull MonthViewHolder holder, int position, @NonNull List<Object> payloads) {
        if (!payloads.isEmpty()) {
            if (holder.dayAdapter != null) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.MONTH, position - START_POSITION);
                List<DayModel> days = generateDaysForMonth(cal);
                holder.dayAdapter.updateData(days, profileList);
            }
        } else {
            super.onBindViewHolder(holder, position, payloads);
        }
    }

    private void recalcCellHeight(MonthViewHolder holder) {
        int h = holder.recyclerView.getHeight();
        if (h > 0 && h != holder.lastKnownHeight) {
            holder.lastKnownHeight = h;
            int density = (int) holder.itemView.getContext().getResources().getDisplayMetrics().density;
            int bottomMargin = 16 * density;
            holder.cellHeight = (h - bottomMargin) / 6;

            if (holder.dayAdapter != null) {
                holder.dayAdapter.setCellHeight(holder.cellHeight);
            }
        }
    }

    @Override
    public int getItemCount() {
        return START_POSITION * 2;
    }

    private List<DayModel> generateDaysForMonth(Calendar targetCal) {
        List<DayModel> daysList = new ArrayList<>();
        Calendar cal = (Calendar) targetCal.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
        if (firstDayOfWeek < 0) firstDayOfWeek += 7;

        Calendar prevCal = (Calendar) cal.clone();
        prevCal.add(Calendar.MONTH, -1);
        int maxDaysInPrevMonth = prevCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = firstDayOfWeek - 1; i >= 0; i--) {
            Calendar dayCal = (Calendar) prevCal.clone();
            int dayNum = maxDaysInPrevMonth - i;
            dayCal.set(Calendar.DAY_OF_MONTH, dayNum);
            daysList.add(new DayModel(String.valueOf(dayNum), false, dayCal.getTime()));
        }

        int maxDayInCurrent = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDayInCurrent; i++) {
            Calendar dayCal = (Calendar) cal.clone();
            dayCal.set(Calendar.DAY_OF_MONTH, i);
            daysList.add(new DayModel(String.valueOf(i), true, dayCal.getTime()));
        }

        Calendar nextCal = (Calendar) cal.clone();
        nextCal.add(Calendar.MONTH, 1);
        int nextDaysNeed = 42 - daysList.size();
        for (int i = 1; i <= nextDaysNeed; i++) {
            Calendar dayCal = (Calendar) nextCal.clone();
            dayCal.set(Calendar.DAY_OF_MONTH, i);
            daysList.add(new DayModel(String.valueOf(i), false, dayCal.getTime()));
        }

        return daysList;
    }

    static class MonthViewHolder extends RecyclerView.ViewHolder {
        RecyclerView recyclerView;
        DayAdapter dayAdapter;
        int cellHeight = 0;
        int lastKnownHeight = 0;
        boolean listenerAttached = false;

        public MonthViewHolder(@NonNull View itemView) {
            super(itemView);
            recyclerView = itemView.findViewById(R.id.monthRecyclerView);
        }
    }
}
