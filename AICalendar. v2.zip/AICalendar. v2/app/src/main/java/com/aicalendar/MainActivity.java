package com.aicalendar.v2;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.viewpager2.widget.ViewPager2;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TextView tvMonthYear;

    // Список всех профилей (типов дней)
    private List<ProfileModel> profileList = new ArrayList<>();
    private ProfilesListDialog profilesListDialog;
    private MonthPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvMonthYear = findViewById(R.id.tvMonthYear);
        viewPager = findViewById(R.id.viewPager);

        // Подключаем кнопку меню "⋮"
        TextView btnMenu = findViewById(R.id.btnMenu);
        if (btnMenu != null) {
            btnMenu.setOnClickListener(this::showPopupMenu);
        }

        // Инициализируем адаптер с передачей списка профилей
        adapter = new MonthPagerAdapter(profileList);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(MonthPagerAdapter.START_POSITION, false);

        // Обновление заголовка при свайпе пальцем
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
				@Override
				public void onPageSelected(int position) {
					super.onPageSelected(position);
					updateTitle(position);
				}
			});

        // Кнопки-стрелки
        findViewById(R.id.btnPrevMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true)
        );

        findViewById(R.id.btnNextMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true)
        );

        updateTitle(MonthPagerAdapter.START_POSITION);
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);

        popup.getMenu().add("Управление профилями");
        popup.getMenu().add("Настройки будильника");
        popup.getMenu().add("🏖️ Режим отпуска");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.contains("Управление профилями")) {
                // Открываем список профилей
                showProfilesListDialog();
                return true;
            }
            return false;
        });

        popup.show();
    }

    // Отображение диалога со списком профилей
    private void showProfilesListDialog() {
        profilesListDialog = new ProfilesListDialog(this, profileList, new ProfilesListDialog.OnProfileListActionListener() {
				@Override
				public void onCreateNewProfile() {
					// Нажали "+ СОЗДАТЬ НОВЫЙ ТИП ДНЯ" — открываем пустую форму
					showProfileEditDialog(null);
				}

				@Override
				public void onEditProfile(ProfileModel profile) {
					// Нажали на карандаш — открываем форму с данными профиля
					showProfileEditDialog(profile);
				}

				@Override
				public void onDeleteProfile(ProfileModel profile) {
					// Удаляем профиль из списка
					profileList.remove(profile);
					if (profilesListDialog != null) {
						profilesListDialog.updateProfiles(profileList);
					}
					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}
					Toast.makeText(MainActivity.this, "Профиль удалён", Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onSelectProfile(ProfileModel profile) {
					// При выборе профиля из списка
					Toast.makeText(MainActivity.this, "Выбран профиль: " + profile.getName(), Toast.LENGTH_SHORT).show();
				}
			});

        profilesListDialog.show();
    }

    // Отображение диалога создания / редактирования профиля
    private void showProfileEditDialog(ProfileModel profileToEdit) {
        ProfileDialog dialog = new ProfileDialog(this, profileToEdit, new ProfileDialog.OnProfileSaveListener() {
				@Override
				public void onSave(ProfileModel savedProfile) {
					boolean found = false;
					for (int i = 0; i < profileList.size(); i++) {
						if (profileList.get(i).getId().equals(savedProfile.getId())) {
							profileList.set(i, savedProfile);
							found = true;
							break;
						}
					}
					if (!found) {
						profileList.add(savedProfile);
					}

					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}

					Toast.makeText(MainActivity.this, "Сохранено: " + savedProfile.getName(), Toast.LENGTH_SHORT).show();
					showProfilesListDialog();
				}

				@Override
				public void onDelete(ProfileModel profileToDelete) {
					profileList.removeIf(p -> p.getId().equals(profileToDelete.getId()));
					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}
					Toast.makeText(MainActivity.this, "Удалено: " + profileToDelete.getName(), Toast.LENGTH_SHORT).show();
					showProfilesListDialog();
				}
			});
        dialog.show();
    }

    // Вызывается при нажатии на день в календаре
	public void openDayDetails(Date date) {
        DayDetailsDialog dialog = new DayDetailsDialog(this, date, profileList, new DayDetailsDialog.OnStartCycleSelectListener() {
				@Override
				public void onSetStartCycle(ProfileModel profile, String dateStr) {
					profile.setStartDate(dateStr);

					// Перерисовываем страницы месяца с передачей payload "REFRESH"
					if (adapter != null) {
						adapter.notifyItemRangeChanged(0, adapter.getItemCount(), "REFRESH");
					}

					Toast.makeText(MainActivity.this, 
								   "Профиль \"" + profile.getName() + "\" установлен стартом для " + dateStr, 
								   Toast.LENGTH_SHORT).show();
				}
			});
        dialog.show();
    }
	

    private void updateTitle(int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - MonthPagerAdapter.START_POSITION);

        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(cal.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);
    }
}

