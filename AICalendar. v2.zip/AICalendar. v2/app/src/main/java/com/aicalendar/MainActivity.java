package com.aicalendar.v2;

import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Calendar currentCalendar;
    private TextView tvMonthYear;
    private GridView calendarGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentCalendar = Calendar.getInstance();
        tvMonthYear = findViewById(R.id.tvMonthYear);
        calendarGrid = findViewById(R.id.calendarGrid);

        TextView btnPrev = findViewById(R.id.btnPrevMonth);
        TextView btnNext = findViewById(R.id.btnNextMonth);

        updateCalendar();

        btnPrev.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					currentCalendar.add(Calendar.MONTH, -1);
					updateCalendar();
				}
			});

        btnNext.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					currentCalendar.add(Calendar.MONTH, 1);
					updateCalendar();
				}
			});
    }

    private void updateCalendar() {
        // Обновляем заголовок с месяцем
        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(currentCalendar.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);

        // Генерируем дни месяца
        List<String> daysList = new ArrayList<>();
        Calendar cal = (Calendar) currentCalendar.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);

        // Определяем день недели для 1-го числа (понедельник = 1)
        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
        if (firstDayOfWeek < 0) firstDayOfWeek += 7;

        // Заполняем пустые ячейки в начале месяца
        for (int i = 0; i < firstDayOfWeek; i++) {
            daysList.add("");
        }

        // Заполняем числа месяца
        int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDay; i++) {
            daysList.add(String.valueOf(i));
        }

        // Передаем данные в адаптер сетки
        CalendarAdapter adapter = new CalendarAdapter(this, daysList);
        calendarGrid.setAdapter(adapter);
    }
}

