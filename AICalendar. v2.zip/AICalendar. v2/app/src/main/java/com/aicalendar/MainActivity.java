package com.aicalendar.v2;

import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.viewpager2.widget.ViewPager2;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_RINGTONE_MAIN = 1001;
    private static final int REQUEST_CODE_RINGTONE_PRE = 1002;

    private ViewPager2 viewPager;
    private TextView tvMonthYear;

    private List<ProfileModel> profileList = new ArrayList<>();
    private ProfilesListDialog profilesListDialog;
    private MonthPagerAdapter adapter;

    private AlarmSettingsDialog settingsDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Загружаем сохранённые профили из памяти устройства
        List<ProfileModel> loadedProfiles = ProfileStorage.loadProfiles(this);
        if (loadedProfiles != null && !loadedProfiles.isEmpty()) {
            profileList.clear();
            profileList.addAll(loadedProfiles);

            // 2. Взводим будильники для всех загруженных профилей
            for (ProfileModel p : profileList) {
                updateAlarmsForProfile(p);
            }
        }

        tvMonthYear = findViewById(R.id.tvMonthYear);
        viewPager = findViewById(R.id.viewPager);

        TextView btnMenu = findViewById(R.id.btnMenu);
        if (btnMenu != null) {
            btnMenu.setOnClickListener(this::showPopupMenu);
        }

        adapter = new MonthPagerAdapter(profileList);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(MonthPagerAdapter.START_POSITION, false);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
				@Override
				public void onPageSelected(int position) {
					super.onPageSelected(position);
					updateTitle(position);
				}
			});

        findViewById(R.id.btnPrevMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true)
        );

        findViewById(R.id.btnNextMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true)
        );

        updateTitle(MonthPagerAdapter.START_POSITION);
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);

        popup.getMenu().add("Управление профилями");
        popup.getMenu().add("Настройки будильника");
        popup.getMenu().add("🏖️ Режим отпуска");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.contains("Управление профилями")) {
                showProfilesListDialog();
                return true;
            } else if (title.contains("Настройки будильника")) {
                showAlarmSettingsDialog();
                return true;
            }
            return false;
        });

        popup.show();
    }

    private void showAlarmSettingsDialog() {
        settingsDialog = new AlarmSettingsDialog(this, isPreAlarm -> {
            Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, 
                            isPreAlarm ? "Выбор пре-будильника" : "Выбор основного будильника");
            startActivityForResult(intent, isPreAlarm ? REQUEST_CODE_RINGTONE_PRE : REQUEST_CODE_RINGTONE_MAIN);
        });
        settingsDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null && settingsDialog != null) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (uri != null) {
                Ringtone ringtone = RingtoneManager.getRingtone(this, uri);
                String title = ringtone.getTitle(this);
                boolean isPre = (requestCode == REQUEST_CODE_RINGTONE_PRE);
                settingsDialog.updateRingtone(isPre, title, uri.toString());
            }
        }
    }

    private void showProfilesListDialog() {
        profilesListDialog = new ProfilesListDialog(this, profileList, new ProfilesListDialog.OnProfileListActionListener() {
				@Override
				public void onCreateNewProfile() {
					showProfileEditDialog(null);
				}

				@Override
				public void onEditProfile(ProfileModel profile) {
					showProfileEditDialog(profile);
				}

				@Override
				public void onDeleteProfile(ProfileModel profile) {
					profileList.remove(profile);

					// Сохраняем измененный список
					ProfileStorage.saveProfiles(MainActivity.this, profileList);

					if (profilesListDialog != null) {
						profilesListDialog.updateProfiles(profileList);
					}
					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}
					Toast.makeText(MainActivity.this, "Профиль удалён", Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onSelectProfile(ProfileModel profile) {
					Toast.makeText(MainActivity.this, "Выбран профиль: " + profile.getName(), Toast.LENGTH_SHORT).show();
				}
			});

        profilesListDialog.show();
    }

    public void showProfileEditDialog(ProfileModel profileToEdit) {
        ProfileDialog dialog = new ProfileDialog(this, profileToEdit, new ProfileDialog.OnProfileSaveListener() {
				@Override
				public void onSave(ProfileModel savedProfile) {
					boolean found = false;
					for (int i = 0; i < profileList.size(); i++) {
						ProfileModel old = profileList.get(i);
						if (old.getId().equals(savedProfile.getId())) {
							if (savedProfile.getStartDate() == null) {
								savedProfile.setStartDate(old.getStartDate());
							}
							profileList.set(i, savedProfile);
							found = true;
							break;
						}
					}
					if (!found) {
						profileList.add(savedProfile);
					}

					// Сохраняем и взводим будильник
					ProfileStorage.saveProfiles(MainActivity.this, profileList);
					updateAlarmsForProfile(savedProfile);

					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}

					Toast.makeText(MainActivity.this, "Сохранено: " + savedProfile.getName(), Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onDelete(ProfileModel profileToDelete) {
					profileList.removeIf(p -> p.getId().equals(profileToDelete.getId()));

					// Сохраняем в SharedPreferences
					ProfileStorage.saveProfiles(MainActivity.this, profileList);

					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}
					Toast.makeText(MainActivity.this, "Удалено: " + profileToDelete.getName(), Toast.LENGTH_SHORT).show();
				}
			});
        dialog.show();
    }

    public void openDayDetails(Date date) {
        DayDetailsDialog dialog = new DayDetailsDialog(this, date, profileList, new DayDetailsDialog.OnStartCycleSelectListener() {
				@Override
				public void onSetStartCycle(ProfileModel profile, String dateStr) {
					profile.setStartDate(dateStr);

					// Сохраняем обновленный профиль и пересчитываем будильник
					ProfileStorage.saveProfiles(MainActivity.this, profileList);
					updateAlarmsForProfile(profile);

					if (adapter != null) {
						adapter.notifyItemRangeChanged(0, adapter.getItemCount(), "REFRESH");
					}

					Toast.makeText(MainActivity.this, 
								   "Профиль \"" + profile.getName() + "\" установлен стартом для " + dateStr, 
								   Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onEditProfileRequested(ProfileModel profile) {
					showProfileEditDialog(profile);
				}
			});
        dialog.show();
    }

    private void updateTitle(int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - MonthPagerAdapter.START_POSITION);

        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(cal.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);
    }

    private void updateAlarmsForProfile(ProfileModel profile) {
        if (profile == null || profile.getStartDate() == null || profile.getReminders() == null) {
            return;
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date startDate = sdf.parse(profile.getStartDate());
            if (startDate == null) return;

            Calendar now = Calendar.getInstance();
            Calendar startCal = Calendar.getInstance();
            startCal.setTime(startDate);

            startCal.set(Calendar.HOUR_OF_DAY, 0);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
            startCal.set(Calendar.MILLISECOND, 0);

            Calendar todayCal = (Calendar) now.clone();
            todayCal.set(Calendar.HOUR_OF_DAY, 0);
            todayCal.set(Calendar.MINUTE, 0);
            todayCal.set(Calendar.SECOND, 0);
            todayCal.set(Calendar.MILLISECOND, 0);

            long diffDays = (todayCal.getTimeInMillis() - startCal.getTimeInMillis()) / (24 * 60 * 60 * 1000);

            int repeatDays = profile.getRepeatDays() > 0 ? profile.getRepeatDays() : 1;
            if (diffDays >= 0 && (diffDays % repeatDays == 0)) {
                for (ReminderModel reminder : profile.getReminders()) {
                    String[] timeParts = reminder.getTime().split(":");
                    int hour = Integer.parseInt(timeParts[0]);
                    int minute = Integer.parseInt(timeParts[1]);

                    Calendar alarmCal = Calendar.getInstance();
                    alarmCal.set(Calendar.HOUR_OF_DAY, hour);
                    alarmCal.set(Calendar.MINUTE, minute);
                    alarmCal.set(Calendar.SECOND, 0);

                    if (alarmCal.before(now)) {
                        alarmCal.add(Calendar.DAY_OF_YEAR, repeatDays);
                    }

                    int alarmId = (profile.getId() + reminder.getTime()).hashCode();

                    AlarmScheduler.scheduleAlarm(
                        this,
                        alarmCal.getTimeInMillis(),
                        alarmId,
                        profile.getName(),
                        reminder.getText().isEmpty() ? "Пора вставать!" : reminder.getText(),
                        false
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

