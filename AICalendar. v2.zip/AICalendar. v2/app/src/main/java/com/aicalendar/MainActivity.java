    private void updateCalendar() {
        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(currentCalendar.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);

        List<DayModel> daysList = new ArrayList<>();

        Calendar cal = (Calendar) currentCalendar.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
        if (firstDayOfWeek < 0) firstDayOfWeek += 7;

        // 1. Дни предыдущего месяца
        Calendar prevMonthCal = (Calendar) cal.clone();
        prevMonthCal.add(Calendar.MONTH, -1);
        int maxDaysInPrevMonth = prevMonthCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = firstDayOfWeek - 1; i >= 0; i--) {
            int dayNum = maxDaysInPrevMonth - i;
            daysList.add(new DayModel(String.valueOf(dayNum), false));
        }

        // 2. Дни текущего месяца
        int maxDayInCurrentMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDayInCurrentMonth; i++) {
            daysList.add(new DayModel(String.valueOf(i), true));
        }

        // 3. Дни следующего месяца (всегда дополняем до 42 ячеек / 6 недель)
        int nextDaysNeed = 42 - daysList.size();
        for (int i = 1; i <= nextDaysNeed; i++) {
            daysList.add(new DayModel(String.valueOf(i), false));
        }

        CalendarAdapter adapter = new CalendarAdapter(this, daysList);
        calendarGrid.setAdapter(adapter);
    }

