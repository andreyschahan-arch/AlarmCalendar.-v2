package com.aicalendar.v2;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Calendar currentCalendar;
    private TextView tvMonthYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentCalendar = Calendar.getInstance();
        tvMonthYear = findViewById(R.id.tvMonthYear);

        TextView btnPrev = findViewById(R.id.btnPrevMonth);
        TextView btnNext = findViewById(R.id.btnNextMonth);

        updateMonthLabel();

        btnPrev.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					currentCalendar.add(Calendar.MONTH, -1);
					updateMonthLabel();
				}
			});

        btnNext.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					currentCalendar.add(Calendar.MONTH, 1);
					updateMonthLabel();
				}
			});
    }

    private void updateMonthLabel() {
        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(currentCalendar.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);
    }
}

