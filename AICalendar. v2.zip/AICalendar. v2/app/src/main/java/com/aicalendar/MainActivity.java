package com.aicalendar.v2;

import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.viewpager2.widget.ViewPager2;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_RINGTONE_MAIN = 1001;
    private static final int REQUEST_CODE_RINGTONE_PRE = 1002;

    private ViewPager2 viewPager;
    private TextView tvMonthYear;

    private List<ProfileModel> profileList = new ArrayList<>();
    private ProfilesListDialog profilesListDialog;
    private MonthPagerAdapter adapter;

    // Переменная для хранения диалога настроек будильника
    private AlarmSettingsDialog settingsDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvMonthYear = findViewById(R.id.tvMonthYear);
        viewPager = findViewById(R.id.viewPager);

        TextView btnMenu = findViewById(R.id.btnMenu);
        if (btnMenu != null) {
            btnMenu.setOnClickListener(this::showPopupMenu);
        }

        adapter = new MonthPagerAdapter(profileList);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(MonthPagerAdapter.START_POSITION, false);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
				@Override
				public void onPageSelected(int position) {
					super.onPageSelected(position);
					updateTitle(position);
				}
			});

        findViewById(R.id.btnPrevMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true)
        );

        findViewById(R.id.btnNextMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true)
        );

        updateTitle(MonthPagerAdapter.START_POSITION);
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);

        popup.getMenu().add("Управление профилями");
        popup.getMenu().add("Настройки будильника");
        popup.getMenu().add("🏖️ Режим отпуска");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.contains("Управление профилями")) {
                showProfilesListDialog();
                return true;
            } else if (title.contains("Настройки будильника")) {
                showAlarmSettingsDialog();
                return true;
            }
            return false;
        });

        popup.show();
    }

    // Открытие диалога настроек будильника
    private void showAlarmSettingsDialog() {
        settingsDialog = new AlarmSettingsDialog(this, isPreAlarm -> {
            Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, 
							isPreAlarm ? "Выбор пре-будильника" : "Выбор основного будильника");
            startActivityForResult(intent, isPreAlarm ? REQUEST_CODE_RINGTONE_PRE : REQUEST_CODE_RINGTONE_MAIN);
        });
        settingsDialog.show();
    }

    // Прием результата из системного выбора мелодии
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null && settingsDialog != null) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (uri != null) {
                Ringtone ringtone = RingtoneManager.getRingtone(this, uri);
                String title = ringtone.getTitle(this);
                boolean isPre = (requestCode == REQUEST_CODE_RINGTONE_PRE);
                settingsDialog.updateRingtone(isPre, title, uri.toString());
            }
        }
    }

    private void showProfilesListDialog() {
        profilesListDialog = new ProfilesListDialog(this, profileList, new ProfilesListDialog.OnProfileListActionListener() {
				@Override
				public void onCreateNewProfile() {
					showProfileEditDialog(null);
				}

				@Override
				public void onEditProfile(ProfileModel profile) {
					showProfileEditDialog(profile);
				}

				@Override
				public void onDeleteProfile(ProfileModel profile) {
					profileList.remove(profile);
					if (profilesListDialog != null) {
						profilesListDialog.updateProfiles(profileList);
					}
					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}
					Toast.makeText(MainActivity.this, "Профиль удалён", Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onSelectProfile(ProfileModel profile) {
					Toast.makeText(MainActivity.this, "Выбран профиль: " + profile.getName(), Toast.LENGTH_SHORT).show();
				}
			});

        profilesListDialog.show();
    }

    // Сделан PUBLIC, чтобы DayDetailsDialog мог его вызывать
    public void showProfileEditDialog(ProfileModel profileToEdit) {
		ProfileDialog dialog = new ProfileDialog(this, profileToEdit, new ProfileDialog.OnProfileSaveListener() {
				@Override
				public void onSave(ProfileModel savedProfile) {
					boolean found = false;
					for (int i = 0; i < profileList.size(); i++) {
						ProfileModel old = profileList.get(i);
						if (old.getId().equals(savedProfile.getId())) {
							// Сохраняем дату старта цикла, если она не была задана в самом диалоге
							if (savedProfile.getStartDate() == null) {
								savedProfile.setStartDate(old.getStartDate());
							}
							profileList.set(i, savedProfile);
							found = true;
							break;
						}
					}
					if (!found) {
						profileList.add(savedProfile);
					}

					// Перерисовываем календарь
					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}

					Toast.makeText(MainActivity.this, "Сохранено: " + savedProfile.getName(), Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onDelete(ProfileModel profileToDelete) {
					profileList.removeIf(p -> p.getId().equals(profileToDelete.getId()));
					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}
					Toast.makeText(MainActivity.this, "Удалено: " + profileToDelete.getName(), Toast.LENGTH_SHORT).show();
				}
			});
		dialog.show();
	}
	

	public void openDayDetails(Date date) {
        DayDetailsDialog dialog = new DayDetailsDialog(this, date, profileList, new DayDetailsDialog.OnStartCycleSelectListener() {
				@Override
				public void onSetStartCycle(ProfileModel profile, String dateStr) {
					profile.setStartDate(dateStr);

					if (adapter != null) {
						adapter.notifyItemRangeChanged(0, adapter.getItemCount(), "REFRESH");
					}

					Toast.makeText(MainActivity.this, 
								   "Профиль \"" + profile.getName() + "\" установлен стартом для " + dateStr, 
								   Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onEditProfileRequested(ProfileModel profile) {
					// Прямой и чистый вызов окна редактирования
					showProfileEditDialog(profile);
				}
			});
        dialog.show();
    }
	

    private void updateTitle(int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - MonthPagerAdapter.START_POSITION);

        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(cal.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);
    }
}

