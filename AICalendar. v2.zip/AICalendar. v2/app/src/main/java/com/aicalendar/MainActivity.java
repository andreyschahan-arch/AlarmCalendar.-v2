package com.aicalendar.v2;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.viewpager2.widget.ViewPager2;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TextView tvMonthYear;

    // Список всех профилей (типов дней)
    private List<ProfileModel> profileList = new ArrayList<>();
    private ProfilesListDialog profilesListDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvMonthYear = findViewById(R.id.tvMonthYear);
        viewPager = findViewById(R.id.viewPager);

        // Подключаем кнопку меню "⋮"
        TextView btnMenu = findViewById(R.id.btnMenu);
        if (btnMenu != null) {
            btnMenu.setOnClickListener(this::showPopupMenu);
        }

        MonthPagerAdapter adapter = new MonthPagerAdapter();
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(MonthPagerAdapter.START_POSITION, false);

        // Обновление заголовка при свайпе пальцем
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
				@Override
				public void onPageSelected(int position) {
					super.onPageSelected(position);
					updateTitle(position);
				}
			});

        // Кнопки-стрелки
        findViewById(R.id.btnPrevMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true)
        );

        findViewById(R.id.btnNextMonth).setOnClickListener(v -> 
            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true)
        );

        updateTitle(MonthPagerAdapter.START_POSITION);
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);

        popup.getMenu().add("Управление профилями");
        popup.getMenu().add("Настройки будильника");
        popup.getMenu().add("🏖️ Режим отпуска");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.contains("Управление профилями")) {
                // Открываем список профилей
                showProfilesListDialog();
                return true;
            }
            return false;
        });

        popup.show();
    }

    // Отображение диалога со списком профилей
    private void showProfilesListDialog() {
        profilesListDialog = new ProfilesListDialog(this, profileList, new ProfilesListDialog.OnProfileListActionListener() {
				@Override
				public void onCreateNewProfile() {
					// Нажали "+ СОЗДАТЬ НОВЫЙ ТИП ДНЯ" — открываем пустую форму
					showProfileEditDialog(null);
				}

				@Override
				public void onEditProfile(ProfileModel profile) {
					// Нажали на карандаш — открываем форму с данными профиля
					showProfileEditDialog(profile);
				}

				@Override
				public void onDeleteProfile(ProfileModel profile) {
					// Удаляем профиль из списка
					profileList.remove(profile);
					if (profilesListDialog != null) {
						profilesListDialog.updateProfiles(profileList);
					}
					Toast.makeText(MainActivity.this, "Профиль удалён", Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onSelectProfile(ProfileModel profile) {
					// При выборе профиля из списка
					Toast.makeText(MainActivity.this, "Выбран профиль: " + profile.getName(), Toast.LENGTH_SHORT).show();
				}
			});

        profilesListDialog.show();
    }

    // Отображение диалога создания / редактирования профиля
	// Отображение диалога создания / редактирования профиля
	// Отображение диалога создания / редактирования профиля
    private void showProfileEditDialog(ProfileModel profileToEdit) {
        ProfileDialog dialog = new ProfileDialog(this, profileToEdit, new ProfileDialog.OnProfileSaveListener() {
				@Override
				public void onSave(ProfileModel savedProfile) {
					if (profileToEdit == null) {
						// Новый профиль
						profileList.add(savedProfile);
						Toast.makeText(MainActivity.this, "Профиль \"" + savedProfile.getName() + "\" создан", Toast.LENGTH_SHORT).show();
					} else {
						// Обновляем имеющийся профиль в списке по его ID
						for (int i = 0; i < profileList.size(); i++) {
							if (profileList.get(i).getId().equals(savedProfile.getId())) {
								profileList.set(i, savedProfile);
								break;
							}
						}
						Toast.makeText(MainActivity.this, "Профиль \"" + savedProfile.getName() + "\" обновлён", Toast.LENGTH_SHORT).show();
					}

					// После сохранения заново открываем список профилей
					showProfilesListDialog();
				}
			});
        dialog.show();
    }
	
	

    private void updateTitle(int position) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, position - MonthPagerAdapter.START_POSITION);

        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = sdf.format(cal.getTime());
        if (monthName.length() > 0) {
            monthName = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
        }
        tvMonthYear.setText(monthName);
    }
}

