package com.aicalendar.v2;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class WidgetSettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int widgetId = getIntent().getIntExtra("WIDGET_ID", -1);
        if (widgetId == -1) {
            finish();
            return;
        }

        WidgetSettingsDialog dialog = new WidgetSettingsDialog(this, widgetId);
        dialog.setOnDismissListener(d -> finish());
        dialog.show();
    }
}
