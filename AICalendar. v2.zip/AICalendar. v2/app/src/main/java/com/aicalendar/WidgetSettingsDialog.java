package com.aicalendar.v2;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class WidgetSettingsDialog extends Dialog {

    private final int widgetId;

    private FrameLayout previewContainer;
    private LinearLayout bgCirclesContainer;
    private LinearLayout previewDaysRow;
    private TextView previewDate, previewProfile, previewReminderText, previewReminderTime;
    private TextView btnTextWhite, btnTextBlack;
    private SeekBar sbAlpha;
    private Button btnApply;

    private int selectedBgIndex;
    private int selectedTextColor;
    private int selectedAlpha;

    public WidgetSettingsDialog(@NonNull Context context, int widgetId) {
        super(context);
        this.widgetId = widgetId;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_widget_settings);

        Window window = getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        }

        previewContainer = findViewById(R.id.previewContainer);
        bgCirclesContainer = findViewById(R.id.bgCirclesContainer);
        previewDaysRow = findViewById(R.id.previewDaysRow);
        previewDate = findViewById(R.id.previewDate);
        previewProfile = findViewById(R.id.previewProfile);
        previewReminderText = findViewById(R.id.previewReminderText);
        previewReminderTime = findViewById(R.id.previewReminderTime);
        btnTextWhite = findViewById(R.id.btnTextWhite);
        btnTextBlack = findViewById(R.id.btnTextBlack);
        sbAlpha = findViewById(R.id.sbWidgetAlpha);
        btnApply = findViewById(R.id.btnWidgetApply);

        // Загружаем текущие значения
        selectedBgIndex = WidgetStorage.getBgIndex(getContext(), widgetId);
        selectedTextColor = WidgetStorage.getTextColor(getContext(), widgetId);
        selectedAlpha = WidgetStorage.getAlpha(getContext(), widgetId);

        // Превью
        buildPreview();
        applyPreviewBackground();

        // Кружки фона
        buildBgCircles();

        // Чипы цвета текста
        updateTextColorChips();
        btnTextWhite.setOnClickListener(v -> {
            selectedTextColor = WidgetStorage.TEXT_COLOR_WHITE;
            updateTextColorChips();
            applyPreviewTextColors();
        });
        btnTextBlack.setOnClickListener(v -> {
            selectedTextColor = WidgetStorage.TEXT_COLOR_BLACK;
            updateTextColorChips();
            applyPreviewTextColors();
        });

        // Ползунок прозрачности
        sbAlpha.setProgress(selectedAlpha);
        sbAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					selectedAlpha = progress;
					applyPreviewBackground();
				}

				@Override public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        // Кнопки
        findViewById(R.id.btnWidgetSettingsBack).setOnClickListener(v -> dismiss());
        btnApply.setOnClickListener(v -> {
            WidgetStorage.saveBgIndex(getContext(), widgetId, selectedBgIndex);
            WidgetStorage.saveTextColor(getContext(), widgetId, selectedTextColor);
            WidgetStorage.saveAlpha(getContext(), widgetId, selectedAlpha);
            WidgetProvider.refreshAll(getContext());
            dismiss();
        });
    }

    // ============ ПРЕВЬЮ ============

    private void buildPreview() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("d MMMM", new Locale("ru"));
        previewDate.setText("Сегодня, " + sdf.format(cal.getTime()));

        previewProfile.setText("Рабочий");
        previewReminderText.setText("Зарядка");
        previewReminderTime.setText("через 41м");

        previewDaysRow.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(getContext());
        int todayNum = cal.get(Calendar.DAY_OF_MONTH);

        for (int offset = -2; offset <= 2; offset++) {
            Calendar dayCal = (Calendar) cal.clone();
            dayCal.add(Calendar.DAY_OF_YEAR, offset);

            View cell = inflater.inflate(R.layout.item_preview_day_cell, previewDaysRow, false);

            TextView tvNum = cell.findViewById(R.id.previewDayNumber);
            TextView tvWd = cell.findViewById(R.id.previewDayWeekday);

            int dayOfMonth = dayCal.get(Calendar.DAY_OF_MONTH);
            tvNum.setText(String.valueOf(dayOfMonth));

            SimpleDateFormat wdSdf = new SimpleDateFormat("EE", new Locale("ru"));
            String wd = wdSdf.format(dayCal.getTime());
            if (wd.length() > 0) {
                wd = wd.substring(0, 1).toUpperCase() + wd.substring(1).toLowerCase();
            }
            wd = wd.replace(".", "");
            tvWd.setText(wd);

            if (offset == 0) {
                tvNum.setTextColor(0xFFFFFFFF);
                tvWd.setTextColor(0xFFFF9500);
            } else {
                tvNum.setTextColor(0xFFE0E0E0);
                tvWd.setTextColor(0xFFAAAAAA);
            }

            // подсветка сегодняшнего — рамка
            if (offset == 0) {
                GradientDrawable gd = new GradientDrawable();
                gd.setShape(GradientDrawable.RECTANGLE);
                float d = getContext().getResources().getDisplayMetrics().density;
                gd.setCornerRadius(6f * d);
                gd.setColor(0x00000000);
                gd.setStroke((int)(2 * d), 0xFFFF9500);
                cell.setBackground(gd);
            }

            previewDaysRow.addView(cell);
        }
    }

    private void applyPreviewBackground() {
        int bgRes = WidgetStorage.getBgDrawableRes(selectedBgIndex);
        previewContainer.setBackgroundResource(bgRes);

        float alpha = Math.max(0f, Math.min(1f, selectedAlpha / 255f));
        previewContainer.setAlpha(alpha);

        applyPreviewTextColors();
    }

    private void applyPreviewTextColors() {
        int primary, secondary, accent;

        if (selectedTextColor == WidgetStorage.TEXT_COLOR_BLACK) {
            primary = 0xFF111111;
            secondary = 0xFF555555;
            accent = 0xFFB34A00;
        } else {
            primary = 0xFFFFFFFF;
            secondary = 0xFFAAAAAA;
            accent = 0xFFFF9500;
        }

        previewDate.setTextColor(secondary);
        previewProfile.setTextColor(primary);
        previewReminderText.setTextColor(primary);
        previewReminderTime.setTextColor(accent);
    }

    // ============ КРУЖКИ ФОНА ============

	private void buildBgCircles() {
        bgCirclesContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(getContext());

        android.graphics.drawable.Drawable selectedRing =
            androidx.core.content.ContextCompat.getDrawable(getContext(), R.drawable.bg_circle_selected_ring);

        for (int i = 0; i < 13; i++) {
            final int itemIndex = (i == 0) ? WidgetStorage.BG_NONE : (i - 1);

            View circleRoot = inflater.inflate(R.layout.item_widget_bg_circle, bgCirclesContainer, false);
            View circle = circleRoot.findViewById(R.id.bgCircle);

            int drawableRes = WidgetStorage.getBgDrawableRes(itemIndex);
            if (drawableRes != 0) {
                circle.setBackgroundResource(drawableRes);
            }

            if (itemIndex == selectedBgIndex && selectedRing != null) {
                circleRoot.setForeground(selectedRing.getConstantState() != null
										 ? selectedRing.getConstantState().newDrawable()
										 : selectedRing);
            } else {
                circleRoot.setForeground(null);
            }

            circleRoot.setOnClickListener(v -> {
                selectedBgIndex = itemIndex;
                buildBgCircles();
                applyPreviewBackground();
            });

            bgCirclesContainer.addView(circleRoot);
        }
    }

    // ============ ЧИПЫ ЦВЕТА ТЕКСТА ============

    private void updateTextColorChips() {
        if (selectedTextColor == WidgetStorage.TEXT_COLOR_WHITE) {
            btnTextWhite.setBackgroundResource(R.drawable.bg_text_color_chip_selected);
            btnTextWhite.setTextColor(0xFFFFFFFF);

            btnTextBlack.setBackgroundResource(R.drawable.bg_text_color_chip);
            btnTextBlack.setTextColor(0xFF111111);
        } else {
            btnTextBlack.setBackgroundResource(R.drawable.bg_text_color_chip_selected);
            btnTextBlack.setTextColor(0xFFFFFFFF);

            btnTextWhite.setBackgroundResource(R.drawable.bg_text_color_chip);
            btnTextWhite.setTextColor(0xFF111111);
        }
    }
}
