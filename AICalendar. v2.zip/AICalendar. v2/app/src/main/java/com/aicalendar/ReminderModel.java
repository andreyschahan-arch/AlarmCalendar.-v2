package com.aicalendar;

public class ReminderModel {
    private String time; // Формат "HH:mm", например "06:00"
    private String text; // Текст напоминания

    public ReminderModel() {
    }

    public ReminderModel(String time, String text) {
        this.time = time;
        this.text = text;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}

