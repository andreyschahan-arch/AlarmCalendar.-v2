package com.aicalendar.v2;

public class ReminderModel {
    private String time;
    private String text;

    public ReminderModel() {
    }

    public ReminderModel(String time, String text) {
        this.time = time;
        this.text = text;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}

